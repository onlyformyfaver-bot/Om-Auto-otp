# OM SMS OTP

1. Upload this whole folder to a new private GitHub repo (keep the folder structure, including `.github`).
2. Actions tab → "Build OM SMS OTP APK" → Run workflow → download the `OM-SMS-OTP-apk` artifact.
3. Install the APK, open it → Settings tab → grant every permission.
   If Accessibility / Notification access is greyed out: App info → ⋮ → Allow restricted settings.
4. Tap "Send test OTP" to check copy, bubble and notification.
5. Senders tab → set any SMS sender or app to "Stop / Ignore" or "Save only".
