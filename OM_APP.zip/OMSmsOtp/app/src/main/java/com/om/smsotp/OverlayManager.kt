package com.om.smsotp

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** Floating, draggable OTP bubble shown on top of any app. Tap = copy, Fill = put into OTP box. */
object OverlayManager {
    private var root: LinearLayout? = null
    private var codeTv: TextView? = null
    private var srcTv: TextView? = null
    private var current = ""
    private var hiddenForGoogle = false
    private var waiting: Triple<String, String, Long>? = null
    private val h = Handler(Looper.getMainLooper())
    private val hideTask = Runnable { remove() }

    fun show(ctx: Context, code: String, src: String) {
        val app = ctx.applicationContext
        if (!Settings.canDrawOverlays(app)) return
        val prefs = Prefs(app)
        if (prefs.googleSafe && AppState.isGoogleScan(AppState.foregroundPkg)) {
            waiting = Triple(code, src, System.currentTimeMillis())   // show after leaving Google
            return
        }
        if (root == null) build(app, prefs)
        current = code
        codeTv?.text = code
        srcTv?.text = src
        root?.visibility = View.VISIBLE
        hiddenForGoogle = false
        scheduleHide(prefs)
    }

    private fun scheduleHide(prefs: Prefs) {
        h.removeCallbacks(hideTask)
        if (prefs.overlaySeconds > 0) h.postDelayed(hideTask, prefs.overlaySeconds * 1000L)
    }

    /** Called by the accessibility service whenever the foreground app changes. */
    fun onForeground(ctx: Context, pkg: String) {
        val prefs = Prefs(ctx)
        if (!prefs.googleSafe) return
        if (AppState.isGoogleScan(pkg)) {
            if (root?.visibility == View.VISIBLE) { root?.visibility = View.GONE; hiddenForGoogle = true }
        } else {
            if (hiddenForGoogle) { root?.visibility = View.VISIBLE; hiddenForGoogle = false }
            waiting?.let { (c, s, t) ->
                waiting = null
                if (System.currentTimeMillis() - t < prefs.fillWindowMin * 60_000L) show(ctx, c, s)
            }
        }
    }

    fun remove() {
        h.removeCallbacks(hideTask)
        root?.let { v ->
            try { v.context.getSystemService(WindowManager::class.java).removeViewImmediate(v) } catch (_: Exception) {}
        }
        root = null; codeTv = null; srcTv = null; hiddenForGoogle = false
    }

    private fun copyNow(ctx: Context) {
        OtpProcessor.copy(ctx, current)
        Toast.makeText(ctx, "OTP copied", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun build(ctx: Context, prefs: Prefs) {
        val wm = ctx.getSystemService(WindowManager::class.java)
        fun dp(v: Int) = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics
        ).toInt()

        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(4), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#EE1F1F1F"))
                setStroke(dp(1), Color.parseColor("#FFFF9800"))
            }
            elevation = dp(6).toFloat()
        }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val code = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 22f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.08f
        }
        val src = TextView(ctx).apply {
            setTextColor(Color.parseColor("#FFBDBDBD")); textSize = 11f; maxLines = 1
        }
        col.addView(code); col.addView(src)

        fun btn(label: String, onClick: () -> Unit) = TextView(ctx).apply {
            text = label; setTextColor(Color.parseColor("#FFFFB74D")); textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(11), dp(10), dp(11), dp(10))
            setOnClickListener { onClick() }
        }
        box.addView(col)
        box.addView(btn("Copy") { copyNow(ctx) })
        box.addView(btn("Fill") {
            val s = AppState.a11y
            val ok = s?.tryFill(auto = false, forced = current) ?: false
            if (!ok) Toast.makeText(
                ctx, if (s == null) "Turn on Accessibility for Fill" else "Tap the OTP box first",
                Toast.LENGTH_SHORT
            ).show()
        })
        box.addView(btn("✕") { remove() })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.overlayX; y = prefs.overlayY
        }

        // Drag anywhere on the code area; position is remembered
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    h.removeCallbacks(hideTask); true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (moved) { prefs.overlayX = lp.x; prefs.overlayY = lp.y }
                    else if (e.actionMasked == MotionEvent.ACTION_UP) copyNow(ctx)
                    scheduleHide(prefs); true
                }
                else -> false
            }
        }
        wm.addView(box, lp)
        root = box; codeTv = code; srcTv = src
    }
}
