package com.om.smsotp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager

/** Sends only the OTP code by SMS to your other mobile, for matching senders (e.g. TTD). */
object Forwarder {
    private const val TAG = "OM OTP"

    fun clean(n: String) = n.filter { it.isDigit() || it == '+' }

    fun maybeForward(ctx: Context, code: String, sName: String, text: String, channel: String) {
        val p = Prefs(ctx)
        if (!p.forwardOn || channel == "share") return
        if (text.trimStart().startsWith(TAG)) return            // never re-forward a forwarded OTP
        val to = clean(p.forwardTo)
        if (to.length < 10) return
        val words = p.forwardMatch.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (words.isEmpty()) return                              // never forward every OTP (bank safety)
        val hay = "$sName $text".lowercase()
        if (words.none { hay.contains(it) }) return
        send(ctx, to, "$TAG $code from $sName")
    }

    fun send(ctx: Context, to: String, msg: String): Boolean {
        if (to.length < 10) return false
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            @Suppress("DEPRECATION")
            val sm: SmsManager =
                if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendTextMessage(to, null, msg, null, null)
            true
        } catch (e: Exception) { false }
    }
}
