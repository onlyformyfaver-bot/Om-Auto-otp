package com.om.smsotp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Keeps the app alive with a small permanent notification so SMS/OTPs are caught
 *  even when the app is closed. Needed on Vivo / Xiaomi / Oppo that kill background apps. */
class KeepAliveService : Service() {
    private var receiver: SmsReceiver? = null
    private val CH = "om_keepalive"

    override fun onCreate() {
        super.onCreate()
        goForeground()
        if (receiver == null) {
            receiver = SmsReceiver()
            val f = IntentFilter("android.provider.Telephony.SMS_RECEIVED").apply { priority = 999 }
            try {
                if (Build.VERSION.SDK_INT >= 33)
                    registerReceiver(receiver, f, android.content.Context.RECEIVER_EXPORTED)
                else
                    @Suppress("UnspecifiedRegisterReceiverFlag") registerReceiver(receiver, f)
            } catch (_: Exception) {}
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "OTP watch", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                }
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_otp)
            .setContentTitle("OM SMS OTP is on")
            .setContentText("Watching for OTPs")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34)
                startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else
                startForeground(7, n)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(ctx: android.content.Context) {
            val i = Intent(ctx, KeepAliveService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Exception) {}
        }
        fun stop(ctx: android.content.Context) {
            try { ctx.stopService(Intent(ctx, KeepAliveService::class.java)) } catch (_: Exception) {}
        }
    }
}
