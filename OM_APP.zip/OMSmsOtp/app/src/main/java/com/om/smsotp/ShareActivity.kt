package com.om.smsotp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Google Lens / Circle to Search / any app -> Share or Select text -> "OM OTP". */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            ?: intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val code = OtpExtractor.extract(text, requireKeyword = true)
            ?: OtpExtractor.extract(text, requireKeyword = false)
        if (code == null) {
            Toast.makeText(this, "No OTP found in the text", Toast.LENGTH_SHORT).show()
        } else {
            OtpProcessor.copy(this, code)
            OtpProcessor.handle(this, text, "", "share", "share", preCode = code)
            Toast.makeText(this, "OTP $code copied", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
