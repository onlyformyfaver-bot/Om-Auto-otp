package com.om.smsotp

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast

class ActionReceiver : BroadcastReceiver() {
    companion object {
        const val COPY = "com.om.smsotp.COPY"
        const val FILL = "com.om.smsotp.FILL"
        const val BUBBLE = "com.om.smsotp.BUBBLE"
    }

    override fun onReceive(ctx: Context, i: Intent) {
        val app = ctx.applicationContext
        val code = i.getStringExtra("code") ?: return
        val src = i.getStringExtra("src") ?: ""
        fun toast(t: String) = Toast.makeText(app, t, Toast.LENGTH_SHORT).show()
        when (i.action) {
            COPY -> { OtpProcessor.copy(app, code); toast("OTP $code copied") }
            BUBBLE -> OverlayManager.show(app, code, src)
            FILL -> {
                val s = AppState.a11y
                if (s == null) { toast("Turn on Accessibility for OM SMS OTP"); return }
                if (Build.VERSION.SDK_INT >= 31)
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
                Handler(Looper.getMainLooper()).postDelayed({
                    if (!s.tryFill(auto = false, forced = code)) toast("Tap the OTP box first, then Fill")
                }, 600)
            }
        }
    }
}
