package com.om.smsotp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class OtpRecord(
    val id: Long, val code: String, val message: String,
    val sourceKey: String, val sourceName: String,
    val appPkg: String, val appLabel: String, val channel: String, val time: Long
)

class OtpDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "otp.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE otp(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, msg TEXT, skey TEXT, " +
                "sname TEXT, pkg TEXT, alabel TEXT, ch TEXT, ts INTEGER)"
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun insert(r: OtpRecord) {
        writableDatabase.insert("otp", null, ContentValues().apply {
            put("code", Crypto.enc(r.code)); put("msg", Crypto.enc(r.message))
            put("skey", r.sourceKey); put("sname", r.sourceName)
            put("pkg", r.appPkg); put("alabel", r.appLabel); put("ch", r.channel); put("ts", r.time)
        })
    }

    fun all(): List<OtpRecord> =
        readableDatabase.rawQuery("SELECT id,code,msg,skey,sname,pkg,alabel,ch,ts FROM otp ORDER BY ts DESC", null).use { c ->
            buildList {
                while (c.moveToNext()) add(
                    OtpRecord(
                        c.getLong(0), Crypto.dec(c.getString(1)), Crypto.dec(c.getString(2)),
                        c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getString(7), c.getLong(8)
                    )
                )
            }
        }

    fun delete(id: Long) { writableDatabase.delete("otp", "id=?", arrayOf(id.toString())) }
    fun clear() { writableDatabase.delete("otp", null, null) }
    fun purge(days: Int) {
        if (days > 0) writableDatabase.delete(
            "otp", "ts < ?", arrayOf((System.currentTimeMillis() - days * 86_400_000L).toString())
        )
    }

    companion object {
        @Volatile private var inst: OtpDb? = null
        fun get(ctx: Context): OtpDb =
            inst ?: synchronized(this) { inst ?: OtpDb(ctx.applicationContext).also { inst = it } }
    }
}
