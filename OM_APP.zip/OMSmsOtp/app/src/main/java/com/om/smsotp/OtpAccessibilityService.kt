package com.om.smsotp

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class OtpAccessibilityService : AccessibilityService() {

    private val OTP_WORDS = listOf(
        "otp", "one time", "one-time", "verification", "verify", "passcode", "security code",
        "enter code", "sms code", "2fa", "booking portal", "access code", "enter otp",
        "ओटीपी", "सत्यापन", "कोड"
    )
    private val PHONE_WORDS = listOf(
        "mobile", "phone", "mobile number", "mobile no", "phone number", "contact number",
        "मोबाइल", "फोन", "मोबाइल नंबर", "number", "registered mobile"
    )
    private val NOT_PHONE = listOf("otp", "code", "pincode", "pin code", "amount", "aadhaar", "aadhar", "account", "card", "cvv", "email", "password")
    private val NOT_OTP = listOf(
        "pincode", "pin code", "postal", "zip", "coupon", "promo", "referral", "captcha",
        "mobile", "phone", "aadhaar", "aadhar", "amount", "cvv", "card number", "search"
    )

    override fun onServiceConnected() { AppState.a11y = this }
    override fun onDestroy() { if (AppState.a11y === this) AppState.a11y = null; super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (AppState.a11y !== this) AppState.a11y = this   // keep the reference fresh after rebind
        val pkg = e.packageName?.toString() ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            pkg != packageName && pkg != "com.android.systemui" && !isKeyboard(pkg)
        ) {
            AppState.foregroundPkg = pkg
            OverlayManager.onForeground(this, pkg)
        }
        val prefs = Prefs(this)
        if (!prefs.autoFill || pkg == packageName) return
        if (prefs.googleSafe && AppState.isGoogleScan(pkg)) return   // never touch Google Lens / Circle to Search
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
            e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) { tryFillPhone(auto = true); tryFill(auto = true) }
    }

    private fun isKeyboard(pkg: String): Boolean {
        val ime = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return ime.startsWith("$pkg/")
    }

    /**
     * auto = true: only fills a field that looks like an OTP box, once per OTP.
     * auto = false (Fill button): fills the focused box with the given code.
     */
    fun tryFill(auto: Boolean = true, forced: String? = null): Boolean {
        val prefs = Prefs(this)
        val code = forced ?: AppState.freshCode(prefs.fillWindowMin) ?: return false
        if (prefs.googleSafe && AppState.isGoogleScan(AppState.foregroundPkg)) return false
        val root = rootInActiveWindow ?: return false

        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
        if (target == null) target = findOtpField(root, 0)
        if (target == null) return false
        if (auto) {
            val okField = looksLikeOtp(target) || isBareOtpBox(target)
            if (!okField) return false
            val existing = target.text?.toString().orEmpty().filter { it.isDigit() }
            if (existing.isNotEmpty()) return false
        }
        val ok = fill(target, code)
        if (ok && auto) AppState.pendingCode = null
        return ok
    }

    private fun describe(n: AccessibilityNodeInfo): String = listOfNotNull(
        n.hintText, n.viewIdResourceName, n.contentDescription, n.text
    ).joinToString(" ").lowercase()

    private fun nearbyText(n: AccessibilityNodeInfo?, depth: Int, budget: IntArray = intArrayOf(40)): String {
        if (n == null || depth < 0 || budget[0]-- <= 0) return ""
        val sb = StringBuilder(describe(n))
        for (i in 0 until n.childCount) sb.append(' ').append(nearbyText(n.getChild(i), depth - 1, budget))
        return sb.toString()
    }

    private fun looksLikeOtp(n: AccessibilityNodeInfo): Boolean {
        val own = describe(n)
        if (NOT_OTP.any { own.contains(it) }) return false
        if (OTP_WORDS.any { own.contains(it) } || own.contains("code")) return true
        val numeric = (n.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER
        val shortBox = n.maxTextLength == 1 || n.maxTextLength in 4..8
        if (!numeric && !shortBox) return false
        val around = nearbyText(n.parent?.parent ?: n.parent, 3)
        return OTP_WORDS.any { around.contains(it) } && NOT_OTP.none { around.contains(it) }
    }

    private fun looksLikePhone(n: AccessibilityNodeInfo): Boolean {
        val own = describe(n)
        if (NOT_PHONE.any { own.contains(it) }) return false
        val numeric = (n.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER
        val phoneType = (n.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_PHONE
        if (PHONE_WORDS.any { own.contains(it) } && (numeric || phoneType || n.maxTextLength == 10 || n.maxTextLength <= 0)) return true
        if (phoneType) return true
        if (numeric && n.maxTextLength == 10) {
            val around = nearbyText(n.parent?.parent ?: n.parent, 3)
            return PHONE_WORDS.any { around.contains(it) } && NOT_PHONE.none { around.contains(it) }
        }
        return false
    }

    /** Fills a focused mobile-number field with the armed number (for the login step before OTP). */
    fun tryFillPhone(auto: Boolean = true, forced: String? = null): Boolean {
        val prefs = Prefs(this)
        val phone = forced ?: AppState.freshPhone(prefs.fillWindowMin) ?: return false
        if (prefs.googleSafe && AppState.isGoogleScan(AppState.foregroundPkg)) return false
        val root = rootInActiveWindow ?: return false
        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
        if (target == null || (auto && !looksLikePhone(target))) {
            target = findPhoneField(root, 0) ?: return false
        }
        if (auto) {
            val existing = target.text?.toString().orEmpty().filter { it.isDigit() }
            if (existing.length >= 10) return false
        }
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, phone)
        }
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        if (ok && auto) AppState.pendingPhone = null
        return ok
    }

    private fun findPhoneField(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        if (n.isEditable && looksLikePhone(n)) return n
        for (i in 0 until n.childCount) findPhoneField(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    /** A short numeric box with no label, used right after we already have a waiting OTP (TTD bare input). */
    private fun isBareOtpBox(n: AccessibilityNodeInfo): Boolean {
        val own = describe(n)
        if (NOT_OTP.any { own.contains(it) } || NOT_PHONE.any { own.contains(it) }) return false
        val numeric = (n.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER
        return (numeric || own.isBlank()) && (n.maxTextLength == 1 || n.maxTextLength in 4..8 || n.maxTextLength <= 0)
    }

    private fun findOtpField(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        if (n.isEditable && looksLikeOtp(n)) return n
        for (i in 0 until n.childCount) findOtpField(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    private fun collectEditable(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth < 0) return
        if (n.isEditable) out += n
        for (i in 0 until n.childCount) collectEditable(n.getChild(i), out, depth - 1)
    }

    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun fill(target: AccessibilityNodeInfo, code: String): Boolean {
        // Split boxes: one digit per box (common in banking / UPI apps and websites)
        val boxes = ArrayList<AccessibilityNodeInfo>()
        collectEditable(target.parent?.parent ?: target.parent, boxes, 3)
        val singles = boxes.filter { it.maxTextLength == 1 }
        val split = when {
            target.maxTextLength == 1 && singles.size >= 4 -> singles
            boxes.size == code.length && boxes.size >= 4 && target.maxTextLength !in 4..8 -> boxes
            else -> null
        }
        if (split != null) {
            code.forEachIndexed { i, ch -> if (i < split.size) setText(split[i], ch.toString()) }
            return true
        }
        if (setText(target, code)) return true
        // Fallback: clipboard paste
        OtpProcessor.copy(this, code)
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }
}
