package com.om.smsotp

import java.util.concurrent.CopyOnWriteArrayList

object AppState {
    @Volatile var pendingCode: String? = null
    @Volatile var pendingTime = 0L
    @Volatile var pendingPhone: String? = null
    @Volatile var pendingPhoneTime = 0L
    @Volatile var foregroundPkg = ""
    @Volatile var a11y: OtpAccessibilityService? = null
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    /** Google Lens, Circle to Search, Google app, Camera, Photos: bubble hides + auto-fill pauses here. */
    private val GOOGLE_SCAN = setOf(
        "com.google.android.googlequicksearchbox",
        "com.google.ar.lens",
        "com.google.android.apps.lens",
        "com.google.android.GoogleCamera",
        "com.google.android.apps.photos"
    )
    fun isGoogleScan(pkg: String) = pkg in GOOGLE_SCAN

    fun freshCode(windowMin: Int): String? =
        pendingCode?.takeIf { System.currentTimeMillis() - pendingTime < windowMin * 60_000L }

    fun freshPhone(windowMin: Int): String? =
        pendingPhone?.takeIf { System.currentTimeMillis() - pendingPhoneTime < windowMin * 60_000L }

    fun notifyChanged() = listeners.forEach { it() }
}
