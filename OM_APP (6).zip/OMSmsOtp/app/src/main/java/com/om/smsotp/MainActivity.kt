@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.om.smsotp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val listener: () -> Unit = { runOnUiThread { tick.intValue++ } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.listeners += listener
        if (Prefs(this).keepAlive) KeepAliveService.start(this)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(tick.intValue) }
            }
        }
    }
    override fun onResume() { super.onResume(); tick.intValue++ }
    override fun onDestroy() { AppState.listeners -= listener; super.onDestroy() }
}

private fun toast(ctx: Context, t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()

@Composable
fun App(tick: Int) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            listOf("History", "Senders", "Settings", "Make Link").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        when (tab) {
            0 -> HistoryScreen(tick)
            1 -> SendersScreen(tick)
            2 -> SettingsScreen(tick)
            else -> MakeLinkScreen()
        }
    }
}

// ---------------- History ----------------
@Composable
fun HistoryScreen(tick: Int) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val all = remember(tick, refresh) { OtpDb.get(ctx).all() }
    val list = all.filter { r ->
        q.isBlank() || listOf(r.code, r.sourceName, r.appLabel, r.message).any { it.contains(q, true) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text("Search code, sender or app") },
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        )
        if (list.isEmpty()) Text("No OTPs yet. Grant permissions in Settings, then tap 'Send test OTP'.", Modifier.padding(16.dp))
        LazyColumn {
            items(list, key = { it.id }) { r ->
                OtpCard(r) { OtpDb.get(ctx).delete(r.id); refresh++ }
            }
        }
    }
}

@Composable
fun OtpCard(r: OtpRecord, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()) }
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
            .clickable {
                OtpProcessor.copy(ctx, r.code)
                if (OverlayManager.isVisible()) {
                    OverlayManager.remove()                      // tap again -> hide the bubble
                } else {
                    AppState.pendingCode = r.code
                    AppState.pendingTime = System.currentTimeMillis()
                    OverlayManager.show(ctx, r.code, r.sourceName)  // tap -> show bubble (floats over the page)
                }
            }
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    r.code, fontSize = 26.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { open = !open }) { Text(if (open) "Hide" else "Message") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
            Text("From: ${r.sourceName}", style = MaterialTheme.typography.bodyMedium)
            Text("Via: ${r.appLabel}  •  ${fmt.format(Date(r.time))}", style = MaterialTheme.typography.bodySmall)
            if (open) Text(r.message, Modifier.padding(top = 6.dp), style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ---------------- Senders: choose which SMS service / app to stop ----------------
@Composable
fun SendersScreen(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var refresh by remember { mutableIntStateOf(0) }
    val known = remember(tick, refresh) { prefs.known() }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        item {
            Text(
                "Choose what happens for each SMS sender or app. 'Stop / Ignore' = no copy, no bubble, not saved.",
                Modifier.padding(vertical = 10.dp), style = MaterialTheme.typography.bodyMedium
            )
            Text("Default for new senders", fontWeight = FontWeight.Bold)
            ChoiceRow(Mode.options, prefs.defaultMode) { prefs.defaultMode = it; refresh++ }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            if (known.isEmpty()) Text("Senders appear here after the first OTP arrives.")
        }
        items(known, key = { it.first }) { (key, name) ->
            Column(Modifier.padding(vertical = 6.dp)) {
                Text(name, fontWeight = FontWeight.Bold)
                Text(
                    when {
                        key.startsWith("sms:") -> "SMS sender"
                        key == "share" -> "Google Lens / shared text"
                        else -> "App: " + key.removePrefix("app:")
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                ChoiceRow(Mode.options, prefs.getMode(key)) { prefs.setMode(key, it); refresh++ }
            }
        }
    }
}

@Composable
fun ChoiceRow(options: List<Pair<String, Int>>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (label, v) ->
            FilterChip(selected = v == selected, onClick = { onSelect(v) }, label = { Text(label) })
        }
    }
}

// ---------------- Settings ----------------
private class Status(ctx: Context) {
    val pkg: String = ctx.packageName
    val listener = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(pkg)
    val sms = ctx.checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
        ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
    val notif = Build.VERSION.SDK_INT < 33 ||
        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val overlay = Settings.canDrawOverlays(ctx)
    val a11y = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains("$pkg/") == true
    val battery = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg)
}

@Composable
fun SettingsScreen(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var r by remember { mutableIntStateOf(0) }
    val st = remember(tick, r) { Status(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r++ }
    val runtimePerms = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    fun open(i: Intent) = try { ctx.startActivity(i) } catch (e: Exception) { toast(ctx, "Open it from phone Settings") }
    val pkgUri = Uri.parse("package:${ctx.packageName}")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Permissions", style = MaterialTheme.typography.titleMedium)
        PermRow("Notification access", "Reads OTPs from SMS and all apps", st.listener) {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        PermRow("SMS + notifications", "Exact SMS sender ID and OTP alert", st.sms && st.notif) { launcher.launch(runtimePerms) }
        PermRow("Display over other apps", "Floating draggable OTP bubble", st.overlay) {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri))
        }
        PermRow("Accessibility", "Auto-fill OTP boxes + Google Lens detection", st.a11y) {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        PermRow("Battery unrestricted", "Keeps OTP catching alive", st.battery) {
            open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri))
        }
        Text(
            "If Accessibility or Notification access is greyed out: App info → ⋮ (top right) → Allow restricted settings.",
            style = MaterialTheme.typography.bodySmall
        )

        // Quick Accessibility switch for banking apps: turn OFF before banking, ON for TTD.
        Button(onClick = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text(if (st.a11y) "Accessibility is ON — tap to turn OFF (for banking apps)"
                 else "Accessibility is OFF — tap to turn ON (for TTD auto-fill)")
        }
        Text(
            "Banking/UPI apps dislike Accessibility. Turn it OFF here before opening a bank app, and ON again when doing TTD bookings.",
            style = MaterialTheme.typography.bodySmall
        )
        HorizontalDivider()

        Text("Actions", style = MaterialTheme.typography.titleMedium)
        Toggle("Auto-copy OTP", "Ready to paste instantly", prefs.autoCopy) { prefs.autoCopy = it }
        Toggle(
            "Keep running in background",
            "Small permanent notification so OTPs are caught when the app is closed (needed on Vivo/Xiaomi)",
            prefs.keepAlive
        ) { prefs.keepAlive = it; if (it) KeepAliveService.start(ctx) else KeepAliveService.stop(ctx) }

        var importantOnly by remember { mutableStateOf(prefs.importantOnly) }
        Toggle(
            "Popup only for important senders",
            "Only senders listed below pop up and copy. Others are still saved in History.",
            prefs.importantOnly
        ) { prefs.importantOnly = it; importantOnly = it }
        if (importantOnly) {
            var hdrs by remember { mutableStateOf(prefs.importantHeaders) }
            OutlinedTextField(
                value = hdrs, onValueChange = { hdrs = it; prefs.importantHeaders = it }, singleLine = true,
                label = { Text("Important headers (comma separated)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Toggle("Floating bubble", "Shows on top of any app, drag to move, tap to copy", prefs.overlay) { prefs.overlay = it }
        Toggle("Auto-fill OTP box", "Fills the OTP field when it is found", prefs.autoFill) { prefs.autoFill = it }
        Toggle("Notification with buttons", "Copy / Fill / Bubble", prefs.notify) { prefs.notify = it }
        Toggle(
            "Google scan safe mode",
            "Hides bubble and pauses auto-fill in Google Lens, Circle to Search, Camera, Photos",
            prefs.googleSafe
        ) { prefs.googleSafe = it }

        HorizontalDivider()
        Text("Forward OTP to another mobile", style = MaterialTheme.typography.titleMedium)
        Text(
            "Turn this on in the phone that receives the OTP. Only the code is sent by SMS, and only for OTPs whose sender or message contains your words below.",
            style = MaterialTheme.typography.bodySmall
        )
        Toggle("Forward matching OTPs", "Normal SMS charges apply if you have no SMS pack", prefs.forwardOn) { prefs.forwardOn = it }
        var fwdTo by remember { mutableStateOf(prefs.forwardTo) }
        OutlinedTextField(
            value = fwdTo, onValueChange = { fwdTo = it; prefs.forwardTo = it }, singleLine = true,
            label = { Text("Send to mobile number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )
        var fwdMatch by remember { mutableStateOf(prefs.forwardMatch) }
        OutlinedTextField(
            value = fwdMatch, onValueChange = { fwdMatch = it; prefs.forwardMatch = it }, singleLine = true,
            label = { Text("Only when it contains (comma separated)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = {
            val ok = Forwarder.send(ctx, Forwarder.clean(fwdTo), "OM OTP 123456 test from OM SMS OTP")
            toast(ctx, if (ok) "Test SMS sent" else "Check number and grant SMS permission")
        }, Modifier.fillMaxWidth()) { Text("Send test forward") }
        HorizontalDivider()

        Choice("Bubble hides after", listOf("15 s" to 15, "30 s" to 30, "1 min" to 60, "2 min" to 120, "Never" to 0), prefs.overlaySeconds) { prefs.overlaySeconds = it }
        Choice("Auto-fill only within", listOf("2 min" to 2, "5 min" to 5, "10 min" to 10), prefs.fillWindowMin) { prefs.fillWindowMin = it }
        Choice("Keep history for", listOf("1 day" to 1, "7 days" to 7, "30 days" to 30, "90 days" to 90, "Forever" to 0), prefs.retentionDays) { prefs.retentionDays = it }
        HorizontalDivider()

        Button(onClick = {
            val c = (100000..999999).random().toString()
            OtpProcessor.handle(ctx, "$c is your OTP to log in to OM Test. Valid for 5 minutes. Do not share.", "AX-OMTEST-S", "sms", "sms")
            toast(ctx, "Test OTP $c sent")
        }, Modifier.fillMaxWidth()) { Text("Send test OTP") }
        OutlinedButton(onClick = {
            prefs.overlayX = 24; prefs.overlayY = 140; OverlayManager.remove(); toast(ctx, "Bubble moved to top")
        }, Modifier.fillMaxWidth()) { Text("Reset bubble position") }
        OutlinedButton(onClick = {
            OtpDb.get(ctx).clear(); AppState.notifyChanged(); toast(ctx, "History cleared")
        }, Modifier.fillMaxWidth()) { Text("Clear history") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun PermRow(title: String, desc: String, ok: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        if (ok) Text("✓ On", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        else Button(onClick = onGrant) { Text("Grant") }
    }
}

@Composable
fun Toggle(title: String, desc: String, initial: Boolean, onChange: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = v, onCheckedChange = { v = it; onChange(it) })
    }
}

@Composable
fun Choice(title: String, options: List<Pair<String, Int>>, initial: Int, onChange: (Int) -> Unit) {
    var v by remember { mutableIntStateOf(initial) }
    Column {
        Text(title)
        ChoiceRow(options, v) { v = it; onChange(it) }
    }
}

// ---------------- Make Link (admin only: build + share a helper link) ----------------
data class SavedLink(var name: String, var phone: String, var exp: Long, var key: String)

private fun loadLinks(prefs: Prefs): MutableList<SavedLink> {
    val out = mutableListOf<SavedLink>()
    try {
        val arr = org.json.JSONArray(prefs.savedLinks)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += SavedLink(o.optString("name"), o.optString("phone"), o.optLong("exp"), o.optString("key"))
        }
    } catch (_: Exception) {}
    return out
}
private fun storeLinks(prefs: Prefs, list: List<SavedLink>) {
    val arr = org.json.JSONArray()
    list.forEach { l ->
        arr.put(org.json.JSONObject().put("name", l.name).put("phone", l.phone).put("exp", l.exp).put("key", l.key))
    }
    prefs.savedLinks = arr.toString()
}
private fun randKey(existing: List<SavedLink>): String {
    val c = "abcdefghijklmnopqrstuvwxyz0123456789"
    while (true) {
        val sb = StringBuilder("k"); repeat(6) { sb.append(c[(Math.random() * c.length).toInt()]) }
        val k = sb.toString()
        if (existing.none { it.key == k }) return k
    }
}
private fun fmtTime(ms: Long): String =
    java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(ms))

@Composable
fun MakeLinkScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var links by remember { mutableStateOf(loadLinks(prefs)) }
    var refresh by remember { mutableIntStateOf(0) }
    var editing by remember { mutableIntStateOf(-1) }

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var durMin by remember { mutableIntStateOf(30) }
    var base by remember { mutableStateOf(prefs.shareBaseUrl) }
    val durs = listOf("30 min" to 30, "1 hr" to 60, "3 hr" to 180, "6 hr" to 360, "1 day" to 1440, "7 day" to 10080)

    fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    fun save() { storeLinks(prefs, links); refresh++ }
    fun linkUrl(l: SavedLink): String {
        val q = buildList {
            if (l.name.isNotBlank()) add("name=" + enc(l.name))
            add("key=" + enc(l.key)); add("exp=" + l.exp)
            if (l.phone.isNotBlank()) add("phone=" + enc(l.phone))
        }
        return base.trim() + "?" + q.joinToString("&")
    }
    fun workerKeys(): String {
        val active = links.filter { System.currentTimeMillis() <= it.exp }
        val body = active.joinToString(",\n") { "  \"" + it.key + "\": " + it.exp + "  // " +
            (if (it.name.isNotBlank()) it.name else "helper") + " — " + fmtTime(it.exp) }
        return "const KEYS = {\n" + body + (if (active.isNotEmpty()) "\n" else "") + "};"
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Make a helper link", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(name, { name = it }, singleLine = true,
            label = { Text("Helper name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() }.take(10) }, singleLine = true,
            label = { Text("Helper mobile (10 digits)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth())
        Text("Link lasts for", style = MaterialTheme.typography.bodySmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            durs.forEach { (label, m) ->
                FilterChip(selected = durMin == m, onClick = { durMin = m }, label = { Text(label) })
            }
        }
        Button(onClick = {
            if (name.isBlank()) { toast(ctx, "Enter a name"); return@Button }
            val l = SavedLink(name.trim(), phone.filter { it.isDigit() }.take(10),
                System.currentTimeMillis() + durMin * 60000L, randKey(links))
            links = (mutableListOf(l) + links).toMutableList()
            save(); OtpProcessor.copy(ctx, linkUrl(l))
            name = ""; phone = ""
            toast(ctx, "Link created & copied")
        }, Modifier.fillMaxWidth()) { Text("Create link") }

        Button(onClick = {
            OtpProcessor.copy(ctx, workerKeys())
            toast(ctx, "Worker keys copied - paste in Cloudflare & Deploy")
        }, Modifier.fillMaxWidth()) { Text("Copy Worker keys (for Cloudflare)") }

        HorizontalDivider()
        Text("Your links", style = MaterialTheme.typography.titleMedium)
        if (links.isEmpty()) Text("No links yet.", style = MaterialTheme.typography.bodySmall)

        links.forEachIndexed { i, l ->
            val expired = System.currentTimeMillis() > l.exp
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    if (editing == i) {
                        var en by remember(l.key) { mutableStateOf(l.name) }
                        var ep by remember(l.key) { mutableStateOf(l.phone) }
                        var ek by remember(l.key) { mutableStateOf(l.key) }
                        var ed by remember(l.key) { mutableIntStateOf(30) }
                        OutlinedTextField(en, { en = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(ep, { ep = it.filter { c -> c.isDigit() }.take(10) }, singleLine = true,
                            label = { Text("Mobile") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(ek, { ek = it.filter { c -> c.isLetterOrDigit() || c=='-' || c=='_' } }, singleLine = true,
                            label = { Text("Key") }, modifier = Modifier.fillMaxWidth())
                        Text("New expiry from now:", style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            durs.forEach { (label, m) -> FilterChip(selected = ed == m, onClick = { ed = m }, label = { Text(label) }) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (ek.isBlank()) { toast(ctx, "Key cannot be empty"); return@Button }
                                if (links.filterIndexed { j, o -> j != i && o.key == ek }.isNotEmpty()) { toast(ctx, "Key already used"); return@Button }
                                l.name = en.trim(); l.phone = ep; l.key = ek; l.exp = System.currentTimeMillis() + ed * 60000L
                                editing = -1; save()
                            }, Modifier.weight(1f)) { Text("Save") }
                            OutlinedButton(onClick = { editing = -1 }, Modifier.weight(1f)) { Text("Cancel") }
                        }
                    } else {
                        Text((if (l.name.isNotBlank()) l.name else "Helper") +
                            (if (expired) "  (expired)" else "  (active)"), fontWeight = FontWeight.Bold)
                        Text((if (l.phone.isNotBlank()) l.phone + " • " else "") + "ends " + fmtTime(l.exp) + " • key " + l.key,
                            style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = { OtpProcessor.copy(ctx, linkUrl(l)); toast(ctx, "Link copied") }, Modifier.weight(1f)) { Text("Copy") }
                            Button(onClick = {
                                val msg = (if (l.name.isNotBlank()) l.name + ", " else "") + "please share your TTD OTP here: " + linkUrl(l)
                                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(
                                    "https://wa.me/" + (if (l.phone.length==10) "91"+l.phone else "") + "?text=" + enc(msg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                catch (e: Exception) { toast(ctx, "WhatsApp not found") }
                            }, Modifier.weight(1f)) { Text("WhatsApp") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { editing = i }, Modifier.weight(1f)) { Text("Edit") }
                            OutlinedButton(onClick = {
                                links = links.toMutableList().also { it.removeAt(i) }
                                save(); toast(ctx, "Removed - update Worker keys")
                            }, Modifier.weight(1f)) { Text("Remove") }
                        }
                    }
                }
            }
        }

        HorizontalDivider()
        OutlinedButton(onClick = {
            val p = phone.filter { it.isDigit() }.take(10)
            if (p.length < 10) { toast(ctx, "Enter a 10-digit number first"); return@OutlinedButton }
            AppState.pendingPhone = p; AppState.pendingPhoneTime = System.currentTimeMillis()
            val filled = AppState.a11y?.tryFillPhone(auto = false, forced = p) ?: false
            OtpProcessor.copy(ctx, p)
            toast(ctx, if (filled) "Number filled" else "Number ready - tap the mobile box to fill, or paste")
        }, Modifier.fillMaxWidth()) { Text("Auto-fill this mobile number") }

        Text("Share page address (change only if different)", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(base, { base = it; prefs.shareBaseUrl = it }, singleLine = true,
            label = { Text("otp-share.html URL") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
    }
}
