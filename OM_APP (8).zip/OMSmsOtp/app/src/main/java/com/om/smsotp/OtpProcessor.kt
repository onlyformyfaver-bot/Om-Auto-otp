package com.om.smsotp

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle

object OtpProcessor {
    private val main = Handler(Looper.getMainLooper())

    private val SMS_APPS = setOf(
        "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms",
        "com.android.messaging", "com.truecaller", "com.oneplus.mms", "com.miui.smsextra",
        "com.xiaomi.mms", "com.coloros.mms", "com.vivo.message", "com.motorola.messaging"
    )
    private val DLT = Regex("^[A-Z]{2}-([A-Z0-9]{3,9})(?:-[A-Z])?$", RegexOption.IGNORE_CASE)

    /** Returns true when an OTP was found and handled. */
    fun handle(
        ctx: Context, text: String, sender: String, pkg: String, channel: String, preCode: String? = null
    ): Boolean {
        val code = preCode ?: OtpExtractor.extract(text) ?: return false
        val prefs = Prefs(ctx)
        val isSms = channel == "sms" || pkg in SMS_APPS
        val (sKey, sName) = when {
            channel == "share" -> "share" to "Scanned / Shared text"
            isSms -> normalizeSender(sender).let { "sms:${it.uppercase()}" to it }
            else -> "app:$pkg" to appLabel(ctx, pkg)
        }
        prefs.addKnown(sKey, sName)
        var mode = if (channel == "share") Mode.FULL else prefs.getMode(sKey)
        if (mode == Mode.IGNORE) return false
        if (channel != "share" && prefs.importantOnly && mode == Mode.FULL) {
            val words = prefs.importantHeaders.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (words.isNotEmpty()) {
                val hay = "$sName $text".lowercase()
                if (words.none { hay.contains(it) }) mode = Mode.SAVE_ONLY   // not important: save, no popup
            }
        }

        val now = System.currentTimeMillis()
        // No duplicate guard: every OTP (new or resent) is processed and re-arms the fill.
        val db = OtpDb.get(ctx)
        db.purge(prefs.retentionDays)
        db.insert(OtpRecord(0, code, text, sKey, sName, pkg, appLabel(ctx, pkg), channel, now))
        AppState.notifyChanged()
        Forwarder.maybeForward(ctx, code, sName, text, channel)
        if (mode == Mode.SAVE_ONLY) return true

        AppState.pendingCode = code
        AppState.pendingTime = now
        OtpExtractor.extractPhone(text)?.let {
            AppState.pendingPhone = it; AppState.pendingPhoneTime = now
        }
        val app = ctx.applicationContext
        main.post {
            if (prefs.autoCopy) copy(app, code)
            if (prefs.notify) Notifier.show(app, code, sName)
            if (prefs.overlay) OverlayManager.show(app, code, sName)
            if (prefs.autoFill) {
                val h = main
                for (d in longArrayOf(0, 400, 900, 1600, 2600, 4000, 6000, 8500, 11000)) {
                    h.postDelayed({
                        if (AppState.freshCode(prefs.fillWindowMin) != null) AppState.a11y?.tryFill(auto = true)
                    }, d)
                }
            }
        }
        return true
    }

    fun normalizeSender(s: String): String {
        val t = s.trim()
        DLT.find(t)?.let { return it.groupValues[1].uppercase() }   // AX-HDFCBK-S -> HDFCBK
        return t.ifBlank { "Unknown" }
    }

    fun appLabel(ctx: Context, pkg: String): String = when (pkg) {
        "sms" -> "SMS"
        "share" -> "Google Lens / Share"
        else -> try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
    }

    fun copy(ctx: Context, code: String) {
        val cm = ctx.getSystemService(ClipboardManager::class.java) ?: return
        val clip = ClipData.newPlainText("OTP", code)
        if (Build.VERSION.SDK_INT >= 33) {   // hides OTP in Android's clipboard preview
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        cm.setPrimaryClip(clip)
    }
}
