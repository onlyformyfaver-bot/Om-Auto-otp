package com.om.smsotp

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build

object Notifier {
    private const val CH = "otp"

    fun show(ctx: Context, code: String, src: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "OTP", NotificationManager.IMPORTANCE_HIGH))

        fun pi(action: String, req: Int) = PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, ActionReceiver::class.java).setAction(action).putExtra("code", code).putExtra("src", src),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun action(label: String, a: String, req: Int) =
            Notification.Action.Builder(null as Icon?, label, pi(a, req)).build()

        val n = Notification.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_otp)
            .setContentTitle("OTP $code")
            .setContentText("From $src")
            .setAutoCancel(true)
            .setTimeoutAfter(10 * 60_000L)
            .setContentIntent(pi(ActionReceiver.BUBBLE, 5))   // tap body -> show bubble, stay on the page
            .addAction(action("Copy", ActionReceiver.COPY, 1))
            .addAction(action("Fill", ActionReceiver.FILL, 2))
            .addAction(action("Bubble", ActionReceiver.BUBBLE, 3))
            .build()
        nm.notify(4242, n)
    }
}
