// ── Search ──────────────────────────────────────────────────────────────
const searchBox = document.getElementById("searchBox");
const allSections = [...document.querySelectorAll(".section-title, .subsection-title, p, pre, td, li")];
searchBox.addEventListener("input", () => {
  const q = searchBox.value.trim().toLowerCase();
  if (!q) { allSections.forEach(el => el.style.background = ""); return; }
  allSections.forEach(el => {
    el.style.background = el.textContent.toLowerCase().includes(q) ? "rgba(108,99,255,0.12)" : "";
  });
  const first = allSections.find(el => el.textContent.toLowerCase().includes(q));
  if (first) first.scrollIntoView({ behavior: "smooth", block: "center" });
});

// ── Command Sidebar ──────────────────────────────────────────────────────
const COMMANDS = [
  { name: "fill", desc: "Fill all form fields from data below ---", example: "fill
click Continue
---
Name, Ravi Kumar
Age, 57
Gender, Male" },
  { name: "date DD/MM/YYYY", desc: "Click a calendar date", example: "date 21/10/2026" },
  { name: "date available", desc: "Click first available (green) date", example: "date available" },
  { name: "pickslot between X and Y", desc: "Pick a time slot inside a time window", example: "pickslot between 10:00 AM and 12:00 PM" },
  { name: "click <text>", desc: "Click any button, card or link by its text", example: "click Continue
click Pay Now
click Confirm" },
  { name: "click .className", desc: "Click element by exact CSS class", example: "click .instruction_continue-btn___TZEU
click .DialogBox_btn__Kq0LL" },
  { name: "click <text> 2nd", desc: "Click the Nth matching button", example: "click Continue 2nd
click saved 2nd" },
  { name: "add <text>", desc: "Click button and wait 600ms (for Add Member etc)", example: "add Add Pilgrim" },
  { name: "next", desc: "Click Next or Continue automatically", example: "fill
next" },
  { name: "submit", desc: "Click Submit or Save button", example: "fill
submit" },
  { name: "back", desc: "Click Back or Previous button", example: "back" },
  { name: "select <text>", desc: "Select radio button, tab or card by text. Already selected → skipped.", example: "select UPI
select Male
select Andhra Pradesh" },
  { name: "section <text>", desc: "Switch to a specific tab by exact text", example: "section Personal Details
fill
section Address
fill" },
  { name: "checkall", desc: "Tick all visible unchecked checkboxes. Already checked → skipped.", example: "checkall" },
  { name: "checkall with ok", desc: "Tick one checkbox → click OK dialog → repeat for all users (10-15). Handles variable count automatically.", example: "checkall with ok
click Continue" },
  { name: "checkall <n>", desc: "Tick at most n checkboxes", example: "checkall 5" },
  { name: "if <condition> → <action>", desc: "Conditional — run action only if condition is true", example: "if checkbox unchecked → checkall
if checkbox checked → skip
if button enabled Continue → click Continue
if button disabled Continue → skip
if field empty Email → fill
if field filled Email → skip" },
  { name: "wait <ms>", desc: "Pause for milliseconds before next command", example: "wait 2000
wait 500" },
  { name: "waitpage", desc: "Wait up to 20s for page fields to appear", example: "waitpage
waitpage 30000" },
  { name: "waitcalendar", desc: "Wait for calendar dates to become available (green/yellow)", example: "waitcalendar
waitcalendar 30000" },
  { name: "upload <file>", desc: "Upload a file from the Image Library", example: "upload photo.jpg
upload Aadhaar = aadhaar.jpg" },
  { name: "icon <name>", desc: "Click an icon by aria-label, alt or class", example: "icon edit
icon delete[2]" },
  { name: "scroll top/bottom/<px>", desc: "Scroll the page", example: "scroll top
scroll bottom
scroll 500" },
  { name: "press <key>", desc: "Press a keyboard key", example: "press enter
press tab
press escape" },
  { name: "hover <text>", desc: "Hover mouse over element by text", example: "hover Menu" },
  { name: "goto <url>", desc: "Navigate to a URL", example: "goto https://ttdevasthanams.ap.gov.in" },
  { name: "type <text>", desc: "Type text character by character into focused field", example: "type Hello World" },
  { name: "row <n>", desc: "Table mode: target specific row", example: "row 1
row 3
row 1-5" },
  { name: "anysite", desc: "Allow next === block to run on a different domain (payment gateway)", example: "click Pay Now
---
===
anysite
click Generate" },
  { name: "---", desc: "Separates commands (above) from field data (below)", example: "fill
click Continue
---
Name, Ravi Kumar
Age, 57" },
  { name: "===", desc: "Separates pages in a multi-page workflow", example: "fill
click Continue
---
Name, Ravi Kumar
===
click Pay Now
---
===
click Confirm" },
];

const cmdList = document.getElementById("cmdList");
const cmdSearch = document.getElementById("cmdSearchInput");

function renderCmds(filter) {
  const q = (filter || "").toLowerCase();
  cmdList.innerHTML = "";
  COMMANDS.filter(c => !q || c.name.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q)).forEach((c, i) => {
    const item = document.createElement("div");
    item.className = "cmd-item";
    item.textContent = c.name;
    item.dataset.i = i;
    const detail = document.createElement("div");
    detail.className = "cmd-detail";
    detail.innerHTML = `<div class="label">${c.name}</div><div>${c.desc}</div><pre>${c.example}</pre>`;
    item.addEventListener("click", () => {
      document.querySelectorAll(".cmd-item").forEach(x => x.classList.remove("active"));
      document.querySelectorAll(".cmd-detail").forEach(x => x.classList.remove("show"));
      item.classList.add("active");
      detail.classList.add("show");
    });
    cmdList.appendChild(item);
    cmdList.appendChild(detail);
  });
}

renderCmds("");
cmdSearch.addEventListener("input", () => renderCmds(cmdSearch.value));
document.getElementById("cmdOpenBtn").addEventListener("click", () => {
  document.getElementById("cmdSidebar").classList.toggle("open");
});
document.getElementById("cmdClose").addEventListener("click", () => {
  document.getElementById("cmdSidebar").classList.remove("open");
});