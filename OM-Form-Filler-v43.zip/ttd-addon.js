/* =========================================================
   OM TTD ADD-ON  (loaded by background.js via importScripts)
   1. Keeps a "⏰ Start at" schedule alive when the page reloads
      (TTD's curtain page, a fresh reload before the start…):
      it re-arms the page after every load and never arms on the curtain.
   2. Starts on TTD's clock, not the PC's (reads TTD's Date header).
   3. Curtain page: never refreshed BEFORE the start time. From the start
      time on, if it is still showing, the booking page is opened again every
      3 s (like pressing refresh) until the real page appears — then the fill
      starts. Stops after 10 minutes.
   4. 45 s before start: one fresh reload of the booking page.
   5. Keeps TTD logins alive: every 3 min, same request as the Python
      version (authtoken + user_id cookies → get_master_sevaks).
   Needs manifest permissions: "alarms", "cookies" and
   host_permissions ["https://ttdevasthanams.ap.gov.in/*"].
   ========================================================= */
(() => {
  const TTD_HOST = "ttdevasthanams.ap.gov.in";
  const isTtd = (url) => { try { const h = new URL(url).hostname; return h === TTD_HOST || h.endsWith("." + TTD_HOST); } catch (e) { return false; } };
  const isCurtain = (url) => /curtain/i.test(url || "");
  const key = (tabId) => `omTtdSched_${tabId}`;
  const S = chrome.storage.session || chrome.storage.local;
  const get = async (k) => (await S.get(k))[k];
  const set = (k, v) => S.set({ [k]: v });
  const del = (k) => S.remove(k);
  const hasAlarms = !!(chrome.alarms && chrome.alarms.onAlarm && chrome.alarms.onAlarm.addListener);

  /* ---------- TTD clock ---------- */
  async function ttdOffset(tabId) {
    const cached = await get("omTtdClock");
    if (cached && Date.now() - cached.at < 10 * 60 * 1000) return cached.offset;
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        func: async () => {
          const t0 = Date.now();
          const r = await fetch(location.origin + "/", { method: "HEAD", cache: "no-store" });
          return { d: Date.parse(r.headers.get("date") || ""), t0, t1: Date.now() };
        }
      });
      const v = res && res.result;
      if (v && !isNaN(v.d)) {
        const offset = (v.d + 500) - (v.t0 + v.t1) / 2;          // Date header has 1 s resolution
        await set("omTtdClock", { offset, at: Date.now() });
        console.log(`🕒 TTD clock: PC is ${offset >= 0 ? "behind" : "ahead"} by ${Math.abs(offset) / 1000}s`);
        return offset;
      }
    } catch (e) { console.warn("TTD clock check failed:", e.message); }
    return 0;
  }

  /* ---------- (re)arm the page's own scheduler ---------- */
  /* curtain after the start time: open the booking page again every 3 s */
  const retryTimers = {};
  async function curtainRetry(tabId) {
    delete retryTimers[tabId];
    const rec = await get(key(tabId));
    if (!rec || rec.fired) return;
    let tab; try { tab = await chrome.tabs.get(tabId); } catch (e) { return; }
    if (!isCurtain(tab.url)) return;                           // real page is back — onUpdated will arm it
    if (tab.status !== "complete") { retryTimers[tabId] = setTimeout(() => curtainRetry(tabId), 500); return; }
    const offset = (await get("omTtdClock"))?.offset || 0;
    if (Date.now() - (rec.runAt - offset) > 10 * 60 * 1000) { console.log("⚠ curtain still up after 10 min — stopped"); return; }
    rec.tries = (rec.tries || 0) + 1; await set(key(tabId), rec);
    console.log(`⏳ TTD curtain after start time — refresh try ${rec.tries}`);
    if (rec.target) chrome.tabs.update(tabId, { url: rec.target }); else chrome.tabs.reload(tabId);
  }
  function scheduleCurtainRetry(tabId, delay) {
    if (retryTimers[tabId]) return;
    retryTimers[tabId] = setTimeout(() => curtainRetry(tabId), Math.max(0, delay));
    if (hasAlarms && delay > 25000) chrome.alarms.create(`omTtdCurtain_${tabId}`, { when: Date.now() + delay });  // survives worker sleep
  }

  async function arm(tabId, url) {
    const rec = await get(key(tabId));
    if (!rec || rec.fired) return;
    if (isCurtain(url)) {                                     // never start on the curtain
      chrome.tabs.sendMessage(tabId, { type: "SCHEDULE_CANCEL" }, () => void chrome.runtime.lastError);
      const offset = isTtd(url) ? await ttdOffset(tabId) : 0;
      const due = rec.runAt - offset - Date.now();
      console.log(due > 0 ? "⏳ TTD curtain — will refresh from the start time" : "⏳ TTD curtain after start time — refreshing");
      scheduleCurtainRetry(tabId, due > 0 ? due : 3000);
      return;
    }
    if (!rec.target && isTtd(url)) { rec.target = url; await set(key(tabId), rec); }   // remember the real booking page
    const offset = isTtd(url) ? await ttdOffset(tabId) : 0;
    const at = Math.max(rec.runAt - offset, Date.now() + 50);   // already past (curtain lifted late) → start now
    const payload = { ...rec.payload, _id: Date.now() + "_ttd_" + Math.random().toString(36).slice(2, 6) };
    const send = (n) => chrome.tabs.sendMessage(tabId, { type: "SCHEDULE_RUN", runAt: at, payload }, () => {
      if (chrome.runtime.lastError && n < 10) setTimeout(() => send(n + 1), 300);
    });
    send(1);
    if (hasAlarms && !rec.reloadSet && rec.runAt - offset - Date.now() > 50000) {
      chrome.alarms.create(`omTtdReload_${tabId}`, { when: rec.runAt - offset - 45000 });
      rec.reloadSet = true; await set(key(tabId), rec);
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "OM_TTD_REMEMBER_SCHEDULE") {
      const tabId = msg.tabId ?? sender?.tab?.id;
      chrome.tabs.get(tabId).then(async t => (t && !isCurtain(t.url)) ? t.url : ((await get(`omTtdLast_${tabId}`)) || "")).catch(() => "")
        .then(target => set(key(tabId), { runAt: msg.runAt, payload: msg.payload, fired: false, target }))
        .then(() => chrome.tabs.get(tabId)).then(tab => arm(tabId, tab.url)).catch(() => {});
      sendResponse({ ok: true }); return true;
    }
    if (msg && msg.type === "OM_TTD_FORGET_SCHEDULE") {
      const tabId = msg.tabId ?? sender?.tab?.id;
      del(key(tabId)); if (hasAlarms) chrome.alarms.clear(`omTtdReload_${tabId}`);
      sendResponse({ ok: true }); return true;
    }
    if (msg && msg.type === "OM_TTD_SCHEDULE_FIRED" && sender?.tab) {
      const tabId = sender.tab.id;
      get(key(tabId)).then(rec => { if (rec) { rec.fired = true; set(key(tabId), rec); } });
      sendResponse({ ok: true }); return true;
    }
  });

  chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status !== "complete" || !tab || !tab.url) return;
    if (/^https?:/.test(tab.url) && !isCurtain(tab.url)) set(`omTtdLast_${tabId}`, tab.url);   // last real page of this tab
    arm(tabId, tab.url);
  });
  chrome.tabs.onRemoved && chrome.tabs.onRemoved.addListener((tabId) => { del(key(tabId)); del(`omTtdLast_${tabId}`); });

  /* ---------- 45 s before: one fresh reload (not on the curtain) + keep-alive ---------- */
  if (hasAlarms) {
    chrome.alarms.onAlarm.addListener(async (alarm) => {
      if (alarm.name.startsWith("omTtdReload_")) {
        const tabId = Number(alarm.name.split("_")[1]);
        try { const tab = await chrome.tabs.get(tabId); if (!isCurtain(tab.url)) chrome.tabs.reload(tabId); } catch (e) {}
      }
      if (alarm.name === "omTtdKeepAlive") keepAliveAll();
      if (alarm.name.startsWith("omTtdCurtain_")) curtainRetry(Number(alarm.name.split("_")[1]));
    });
    chrome.alarms.create("omTtdKeepAlive", { periodInMinutes: 3 });
  }

  async function keepAliveAll() {
    if (!chrome.cookies) return;
    const tabs = await chrome.tabs.query({ url: `https://${TTD_HOST}/*` });
    for (const tab of tabs) {
      try {
        const token = (await chrome.cookies.get({ url: tab.url, name: "authtoken" }))?.value;
        const uid = (await chrome.cookies.get({ url: tab.url, name: "user_id" }))?.value || "";
        if (!token) continue;
        const [res] = await chrome.scripting.executeScript({
          target: { tabId: tab.id }, world: "MAIN", args: [token, uid],
          func: (t, u) => fetch("/api/sed/v1/seva/get_master_sevaks", {
            method: "GET", credentials: "include",
            headers: { "Accept": "application/json, text/plain, */*", "authtoken": t, "userid": u }
          }).then(r => r.status).catch(() => "network error")
        });
        const status = res && res.result;
        console.log(`💓 TTD keep-alive tab ${tab.id}: ${status}`);
        if (status === 401 || status === 403) {
          chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#d93025" });
          chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
          chrome.action.setTitle({ tabId: tab.id, title: `TTD session ended (${status}) — log in again` });
        } else {
          chrome.action.setBadgeText({ tabId: tab.id, text: "" });
        }
      } catch (e) {}
    }
  }
})();
