/* =========================================================
   ARJITHA SEVA — direct booking (new module, separate from Srivari Seva)
   Verified from the site's own calls (api log, 03 Oct 2026):
     GET  /api/arjitha-seva/v1/slot/get_availability?templeId=<id>&sevaName=all
          → result.seva[name] = { personsAllowed, sevaAmount }
          → result.totalDateSlots[YYYYMMDD].slots[name] = { slots, sevaTime, maxTicketAllowedToBook }
     POST /api/arjitha-seva/v1/ticket/save   headers: Content-Type + authtoken
          body: { sevaTemple, sevaType, sevaDate, noOfTickets, noOfPilgrims, gothram,
                  pilgrimCity, pilgrimEmail, pilgrimState, pilgrimCountry, pilgrimPincode, pilgrims[] }
   NOT yet seen: the success reply of ticket/save and how the site moves on to payment.
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  const $ = (id) => document.getElementById(id);
  const HOST = "ttdevasthanams.ap.gov.in";
  const API = "https://" + HOST + "/api/arjitha-seva/v1";
  const KNOWN_TEMPLES = { 3: "Sri Govindarajaswamy Temple" };   // verified pair (templeId → sevaTemple)
  const STORE = "omArjitha";
  let avail = null;          // last availability result
  let picked = { seva: null, date: null };

  // ── TTD tab (Kiwi: popup is its own tab, so look the TTD tab up directly) ──
  async function ttdTab() {
    const tabs = await chrome.tabs.query({ url: ["https://" + HOST + "/*", "http://" + HOST + "/*"] });
    if (!tabs.length) throw new Error("Open the TTD website first and log in");
    const tab = tabs.find(t => t.active) || tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
    if (/curtain/i.test(tab.url)) throw new Error("Still on the curtain / queue page — wait until it lets you through");
    if (tab.discarded) throw new Error("The browser unloaded the TTD tab — open it, let the page load, then come back");
    return tab;
  }
  async function inPage(func, args) {
    const tab = await ttdTab();
    const run = () => chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func, args });
    try { return (await run())[0]?.result; }
    catch (e) {
      if (!/cannot access|no frame|frame with id|error page|not ready/i.test(e.message)) throw e;
      await new Promise(r => setTimeout(r, 800));
      try { return (await run())[0]?.result; }
      catch (_) { throw new Error("TTD tab not reachable — open it, wait until the page shows, then try again"); }
    }
  }

  // Runs inside the TTD page: same headers the site uses for arjitha calls
  async function pageFetch(url, method, bodyText) {
    const ck = {};
    document.cookie.split(";").forEach(c => { const i = c.indexOf("="); if (i > 0) ck[c.slice(0, i).trim()] = c.slice(i + 1); });
    if (!ck.authtoken) return { err: "🔒 Not logged in to TTD — log in on the TTD tab first, then try again" };
    const headers = { "Content-Type": "application/json", authtoken: ck.authtoken };
    const site = (window.__OM_API_LOG || []).filter(x => /\/api\/arjitha-seva\//.test(x.url) && x.reqHeaders && x.reqHeaders.authtoken).pop();
    if (site) Object.assign(headers, site.reqHeaders);
    const t0 = performance.now();
    try {
      const res = await fetch(url, { method, headers, body: bodyText || undefined, credentials: "include" });
      const text = await res.text();
      return { status: res.status, ms: Math.round(performance.now() - t0), text };
    } catch (e) { return { err: e.message }; }
  }

  // Runs inside the TTD page: last ticket/save body + the temple it was for
  function pageLastAttempt() {
    const log = window.__OM_API_LOG || [];
    let last = null, templeId = null;
    log.forEach(x => {
      const m = /[?&]templeId=(\d+)/.exec(x.url || "");
      if (m && /get_availability/.test(x.url)) templeId = m[1];
      if (/\/arjitha-seva\/v1\/ticket\/save/.test(x.url || "") && x.body) last = { body: x.body, templeId };
    });
    return last;
  }

  const status = (text, color) => { const el = $("aj_status"); el.style.display = "block"; el.style.color = color || "#cba6f7"; el.textContent = text; };
  const fmtDate = (d) => new Date(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6, 8)).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });

  // ── Temple name follows the ID when known ──
  async function templeMap() { return { ...KNOWN_TEMPLES, ...((await chrome.storage.local.get(STORE))?.[STORE]?.temples || {}) }; }
  $("aj_templeId")?.addEventListener("input", async () => {
    const n = (await templeMap())[$("aj_templeId").value.trim()];
    if (n) $("aj_templeName").value = n;
  });

  // ── Sevas + dates ──
  async function loadAvailability() {
    const id = $("aj_templeId").value.trim();
    if (!/^\d+$/.test(id)) { status("❌ Enter the temple ID (number)", "#f38ba8"); return; }
    $("aj_seva").innerHTML = '<option value="">Loading…</option>';
    $("aj_dates").innerHTML = "";
    try {
      const r = await inPage(pageFetch, [`${API}/slot/get_availability?templeId=${id}&sevaName=all`, "GET", null]);
      if (r.err) throw new Error(r.err);
      let j; try { j = JSON.parse(r.text); } catch (e) { throw new Error(`HTTP ${r.status} — not JSON`); }
      if (j.status !== "success") throw new Error(j.reason?.reason_eng || `HTTP ${r.status}`);
      avail = j.result || {};
      const sevas = Object.entries(avail.seva || {});
      $("aj_seva").innerHTML = "";
      $("aj_seva").add(new Option(sevas.length ? `— pick a seva (${sevas.length}) —` : "— no sevas returned —", ""));
      sevas.forEach(([name, v]) => $("aj_seva").add(new Option(`${name} · ₹${v.sevaAmount} · up to ${v.personsAllowed} persons`, name)));
      if (picked.seva && avail.seva?.[picked.seva]) { $("aj_seva").value = picked.seva; renderDates(); }
      $("aj_status").style.display = "none";
    } catch (e) { $("aj_seva").innerHTML = '<option value="">—</option>'; status("❌ Sevas: " + e.message, "#f38ba8"); }
  }

  function renderDates() {
    const seva = $("aj_seva").value, box = $("aj_dates");
    picked.seva = seva || null;
    box.innerHTML = "";
    if (!seva || !avail) return;
    const days = Object.entries(avail.totalDateSlots || {}).filter(([, v]) => v?.slots?.[seva]).sort(([a], [b]) => a.localeCompare(b));
    if (!days.length) { box.innerHTML = '<span style="color:#f9e2af;">No dates for this seva</span>'; return; }
    days.forEach(([d, v]) => {
      const s = v.slots[seva], full = !(s.slots > 0);
      const b = document.createElement("button");
      b.textContent = `${fmtDate(d)} · ${s.slots} · ${s.sevaTime || ""}`;
      b.disabled = full;
      b.style.cssText = `padding:5px 8px;border:none;border-radius:999px;cursor:${full ? "default" : "pointer"};background:${full ? "#45475a" : "#313244"};color:${full ? "#6c7086" : "#a6e3a1"};`;
      if (picked.date === d) b.style.outline = "2px solid #a6e3a1";
      b.addEventListener("click", () => { picked.date = d; box.querySelectorAll("button").forEach(x => x.style.outline = ""); b.style.outline = "2px solid #a6e3a1"; });
      box.appendChild(b);
    });
  }
  $("aj_load")?.addEventListener("click", loadAvailability);
  $("aj_seva")?.addEventListener("change", () => { picked.date = null; renderDates(); });

  // ── Pilgrims: one per line → "Name, age, F/M, aadhaar, 123412341234" ──
  function parsePilgrims() {
    const lines = $("aj_pilgrims").value.split("\n").map(l => l.trim()).filter(Boolean);
    return lines.map((l, i) => {
      const [name, age, g, idType, idNumber] = l.split(",").map(x => (x || "").trim());
      const gender = /^f/i.test(g) ? "Female" : /^m/i.test(g) ? "Male" : g;
      return { id: i, name, age: Number(age), gender, idType: (idType || "aadhaar").toLowerCase(), idNumber: (idNumber || "").replace(/\s/g, ""),
               country: "", visaNumber: "", visaType: "", visaValidityDate: "Invalid Date", visaNo: "" };   // same as the site sends for Indian pilgrims
    });
  }
  const pilgrimsToText = (arr) => arr.map(p => [p.name, p.age, p.gender, p.idType, p.idNumber].join(", ")).join("\n");

  function buildBody() {
    const pilgrims = parsePilgrims();
    return {
      sevaTemple: $("aj_templeName").value.trim(),
      sevaType: picked.seva,
      sevaDate: picked.date,
      noOfTickets: 1,
      noOfPilgrims: pilgrims.length,
      gothram: $("aj_gothram").value.trim() || null,
      pilgrimCity: $("aj_city").value.trim(),
      pilgrimEmail: $("aj_email").value.trim(),
      pilgrimState: $("aj_state").value.trim(),
      pilgrimCountry: "india",
      pilgrimPincode: $("aj_pincode").value.trim(),
      pilgrims
    };
  }

  function check(body) {
    if (!body.sevaTemple) return "Enter the temple name (exactly as TTD uses it)";
    if (!body.sevaType) return "Load sevas and pick one";
    if (!body.sevaDate) return "Tap a date";
    const allowed = avail?.seva?.[body.sevaType]?.personsAllowed;
    if (!body.pilgrims.length) return "Add at least one pilgrim";
    if (allowed && body.pilgrims.length > allowed) return `${body.sevaType} allows up to ${allowed} persons — you have ${body.pilgrims.length}`;
    for (const p of body.pilgrims) {
      if (!p.name || !(p.age > 0) || !/^(Male|Female)$/.test(p.gender)) return `Check pilgrim line: ${p.name || "(blank)"}`;
      if (p.idType === "aadhaar" && !/^\d{12}$/.test(p.idNumber)) return `Aadhaar must be 12 digits for ${p.name}`;
    }
    if (!/^\S+@\S+\.\S+$/.test(body.pilgrimEmail)) return "Check the email";
    if (!/^\d{6}$/.test(body.pilgrimPincode)) return "Pincode must be 6 digits";
    if (!body.pilgrimCity || !body.pilgrimState) return "Enter city and state";
    return null;
  }

  // ── Fill from the last attempt on the site (this tab's api log) ──
  $("aj_fillLast")?.addEventListener("click", async () => {
    try {
      const last = await inPage(pageLastAttempt, []);
      if (!last) { status("No earlier Arjitha attempt in this tab's log. Fill the form once on the TTD site, or type the details.", "#f9e2af"); return; }
      const b = JSON.parse(last.body);
      if (last.templeId) $("aj_templeId").value = last.templeId;
      $("aj_templeName").value = b.sevaTemple || "";
      $("aj_city").value = b.pilgrimCity || ""; $("aj_email").value = b.pilgrimEmail || "";
      $("aj_state").value = b.pilgrimState || ""; $("aj_pincode").value = b.pilgrimPincode || "";
      $("aj_gothram").value = b.gothram || "";
      $("aj_pilgrims").value = pilgrimsToText(b.pilgrims || []);
      picked = { seva: b.sevaType || null, date: b.sevaDate || null };
      if (last.templeId && b.sevaTemple) await saveTemple(last.templeId, b.sevaTemple);
      status(`Filled from last attempt: ${b.sevaType} · ${b.sevaDate}. Loading dates…`, "#a6e3a1");
      await loadAvailability();
    } catch (e) { status("❌ " + e.message, "#f38ba8"); }
  });

  async function saveTemple(id, name) {
    const all = (await chrome.storage.local.get(STORE))?.[STORE] || {};
    all.temples = { ...(all.temples || {}), [id]: name };
    await chrome.storage.local.set({ [STORE]: all });
  }

  // ── Remember details on this device (opt-in: includes ID numbers) ──
  const FIELDS = ["aj_templeId", "aj_templeName", "aj_city", "aj_email", "aj_state", "aj_pincode", "aj_gothram", "aj_pilgrims"];
  async function saveForm() {
    const all = (await chrome.storage.local.get(STORE))?.[STORE] || {};
    all.form = $("aj_remember").checked ? Object.fromEntries(FIELDS.map(f => [f, $(f).value])) : null;
    all.remember = $("aj_remember").checked;
    await chrome.storage.local.set({ [STORE]: all });
  }
  $("aj_remember")?.addEventListener("change", saveForm);

  // ── Book ──
  $("aj_book")?.addEventListener("click", async () => {
    const body = buildBody(), problem = check(body);
    if (problem) { status("❌ " + problem, "#f38ba8"); return; }
    if ($("aj_remember").checked) saveForm();
    const show = JSON.stringify({ ...body, pilgrims: body.pilgrims.map(p => ({ ...p, idNumber: p.idNumber.replace(/\d(?=\d{4})/g, "•") })) }, null, 1);
    if ($("aj_dryRun").checked) { status("🧪 DRY RUN — this is what would be sent (not sent):\n" + show, "#f9e2af"); return; }
    $("aj_book").disabled = true;
    status("⏳ Saving ticket…");
    try {
      const r = await inPage(pageFetch, [`${API}/ticket/save`, "POST", JSON.stringify(body)]);
      if (r.err) throw new Error(r.err);
      let j = null; try { j = JSON.parse(r.text); } catch (e) {}
      if (!j || j.status !== "success") {
        const why = j?.reason?.reason_eng || `HTTP ${r.status}`;
        const tip = /already in progress/i.test(why) ? "\nAn earlier booking for these pilgrims is still waiting for payment. Finish or let it lapse on the TTD site, then try again." : "";
        status(`❌ ticket/save (${r.ms} ms) — ${why}${tip}`, "#f38ba8");
        return;
      }
      // Success reply not seen yet: show it, and open a payment link if it contains one
      const link = JSON.stringify(j).match(/https?:\/\/[^"\s]+/);
      status(`✅ Ticket saved (${r.ms} ms).\n${link ? "Opening payment…" : "Complete payment on the TTD tab. Please send me this reply so the payment step can be wired up:"}\n${JSON.stringify(j, null, 1).slice(0, 3000)}`, "#a6e3a1");
      if (link) { const tab = await ttdTab(); chrome.tabs.update(tab.id, { url: link[0], active: true }); }
    } catch (e) { status("❌ " + e.message, "#f38ba8"); }
    finally { $("aj_book").disabled = false; }
  });

  // ── Open / close ──
  $("arjithaBtn")?.addEventListener("click", async () => {
    $("arjithaPanel").style.display = "block";
    document.body.classList.add("db-open");
    const all = (await chrome.storage.local.get(STORE))?.[STORE] || {};
    $("aj_remember").checked = !!all.remember;
    if (all.remember && all.form) FIELDS.forEach(f => { if (all.form[f] != null && !$(f).value) $(f).value = all.form[f]; });
    if (!$("aj_templeName").value) { const n = (await templeMap())[$("aj_templeId").value.trim()]; if (n) $("aj_templeName").value = n; }
    $("aj_book").textContent = $("aj_dryRun").checked ? "🧪 Book (dry run)" : "🚀 Book (REAL)";
  });
  $("aj_dryRun")?.addEventListener("change", () => { $("aj_book").textContent = $("aj_dryRun").checked ? "🧪 Book (dry run)" : "🚀 Book (REAL)"; });
  $("aj_close")?.addEventListener("click", () => { $("arjithaPanel").style.display = "none"; document.body.classList.remove("db-open"); });
});
