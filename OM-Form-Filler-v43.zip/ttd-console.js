// TTD Direct Booking Console Script v10
// Add: GROUP mode (10-15 members), auto sevaTypeId from date's slots, dryRun (stops before confirm), TTD.members()
// (v9)
// Add: session-expiry detection; watch skips overlapping checks; book() can't run twice
// (v8)
// Add: skip attach if sevak already on ticket; final GET /confirm?regId=
// Fix: add_sevak_to_master_list payload matches captured site request
//      (top-level masterSevakId, no ticketId, sevakDetail.id)
// Fix: availability uses /slot/get_availability like the site

(async function TTD() {

  const CONFIG = {
    sevaTypeId: 47,
    sevaName: 'Srivari Seva',
    remarks: 'S.V.Temple-Bangalore-Batch B',
    sevaDate: '20261013',
    bookingType: 'INDIVIDUAL',
    noOfPilgrim: 1,
    autoBook: false,
    watchInterval: 2000,
    dryRun: true,      // true = stop before confirm (safe test); false = real booking
    members: [],       // GROUP: sevakIds or names from TTD.members(); [] = all master sevaks
    leader: null,      // GROUP: sevakId or name of group leader; null = current master leader
  };

  function getCookies() {
    const c = {};
    document.cookie.split(';').forEach(x => {
      const [k,v] = x.trim().split('=');
      if (k) c[k.trim()] = decodeURIComponent(v||'');
    });
    return c;
  }

  function hdrs() {
    const c = getCookies();
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authtoken': c.authtoken || '',
      'Userid': c.user_id || '',
    };
  }

  async function post(path, body, query='') {
    const url = `https://ttdevasthanams.ap.gov.in/api/sed/v1/seva${path}${query?'?'+query:''}`;
    const r = await fetch(url, {method:'POST', headers:hdrs(),
      body:JSON.stringify(body), credentials:'include'});
    return checkSession(await r.json());
  }

  async function gget(path) {
    const url = `https://ttdevasthanams.ap.gov.in/api/sed/v1/seva${path}`;
    const r = await fetch(url, {headers:hdrs(), credentials:'include'});
    return checkSession(await r.json());
  }

  // TTD returns reason_code UNAUTHORIZED when the session expired / logged in elsewhere
  function checkSession(j) {
    if (j?.reason?.reason_code === 'UNAUTHORIZED') {
      console.error('%c 🔒 SESSION EXPIRED — log in again, then re-paste the script ',
        'background:#dc2626;color:white;font-size:14px;padding:4px');
      throw new Error('SESSION_EXPIRED');
    }
    return j;
  }

  let booking = false;
  async function book() {
    if (booking) { console.warn('⏳ book() already running — skipped'); return; }
    booking = true;
    try { await bookInner(); }
    catch (e) {
      if (e.message === 'SESSION_EXPIRED') alert('🔒 TTD session expired — log in again');
      else console.error('❌ book() error:', e);
    }
    finally { booking = false; }
  }

  async function bookInner() {
    console.log('🚀 Booking v10...');
    const t0 = Date.now();

    // Step 0: Get master sevaks
    const mRes = await gget('/get_master_sevaks');
    const mList = Array.isArray(mRes?.result) ? mRes.result : [];
    if (!mList.length) { console.error('❌ No master sevaks'); return; }
    const ms = mList.find(s => s.isGroupLeader) || mList[0];
    console.log('✅ sevakId:', ms.sevakId, '| masterSevakId:', ms.masterSevakId);

    // GROUP: pick members + leader, validate 10-15
    let group = null;
    if (CONFIG.bookingType === 'GROUP') {
      group = pickGroup(mList);
      if (!group) return;
      CONFIG.noOfPilgrim = group.members.length;
    }

    // seva type ID differs per date (e.g. Tirumala group: Tue=1, Wed=27, Thu=2)
    const sevaTypeId = await sevaTypeFor(CONFIG.sevaDate);
    console.log('🎫 Creating ticket | date:', CONFIG.sevaDate, '| sevaTypeId:', sevaTypeId, '| pilgrims:', CONFIG.noOfPilgrim);
    const tRes = await post('/ticket', {
      bookingType: CONFIG.bookingType,
      userSelectedSevaDate: CONFIG.sevaDate,
      userSelectedSevaType: sevaTypeId,
      noOfPilgrim: CONFIG.noOfPilgrim
    });
    if (tRes?.status !== 'success') { console.error('❌ Ticket failed:', tRes); return; }
    const ticketId = tRes.result?.id;
    console.log('✅ ticketId:', ticketId, '| date:', tRes.result?.userSelectedSevaDate);

    if (group) {
      const ok = await attachGroup(ticketId, group);
      if (!ok) return;
      return finish(ticketId, t0);
    }

    // Read masterSevakId from ticket masterSevaList
    const mSevaList = tRes.result?.masterSevaList || tRes.result?.masterSevakList || [];
    const masterSevakIdFromTicket = mSevaList[0]?.masterSevakId || mSevaList[0]?.masterSevaId;
    const masterSevakId = masterSevakIdFromTicket || ms.masterSevakId || ms.sevakId;
    console.log('masterSevakId to use:', masterSevakId, '| from ticket list:', masterSevakIdFromTicket);

    // Step 2: is the master sevak already on this ticket? (site pre-ticks her)
    const tk = await gget('/get_by_user_id');
    const onTicket = (tk?.result?.sevaksList || []).some(s => s.masterSevakId === masterSevakId);
    console.log('👤 already on ticket:', onTicket);

    if (!onTicket) {
      // Step 2a: add_sevak_to_master_list (shape matches captured site request)
      const sevakDetail = {
        ...ms,
        masterSevakId: masterSevakId,
        isMaster: true,
        isSecondaryLeader: false,
        isGroupLeader: true,
        id: ms.sevakId
      };
      const p2 = { isGroupLeader: true, isSecondaryLeader: false, sevakDetail, masterSevakId };
      const r2 = await post('/add_sevak_to_master_list', p2, 'registration_type=GROUP');
      if (r2?.status !== 'success') { console.error('❌ add_sevak failed:', r2?.reason?.reason_eng); return; }
      console.log('✅ master sevak ok:', r2.result?.sevakId);

      // Step 2b: attach to ticket (verified 27 Oct booking)
      const p3 = {
        ticketId,
        isGroupLeader: true,
        isSecondaryLeader: false,
        registeredSevakId: null,
        sevakDetail: { ...sevakDetail, id: r2.result?.sevakId }
      };
      const r3 = await post('/add_sevaks', p3);
      if (r3?.status !== 'success') { console.error('❌ add_sevaks failed:', JSON.stringify(r3)); return; }
      console.log('✅ attached to ticket');
    }

    return finish(ticketId, t0);
  }

  // Step 3: confirm (captured: GET /confirm?regId=<ticketId>) — skipped in dryRun
  async function finish(ticketId, t0) {
    if (CONFIG.dryRun) {
      const tk = await gget('/get_by_user_id');
      const n = (tk?.result?.sevaksList || []).length;
      console.log(`🧪 DRY RUN done — ticket ${ticketId} has ${n} sevak(s). NOT confirmed.`);
      console.log('Clean up: await TTD.remove()   |   Real booking: TTD.config({dryRun:false})');
      return;
    }
    const rc = await gget(`/confirm?regId=${ticketId}`);
    if (rc?.status === 'success') {
      const elapsed = ((Date.now()-t0)/1000).toFixed(2);
      console.log(`🎉 BOOKED in ${elapsed}s! Ref: ${rc.result?.bRefNo} | ticket: ${ticketId}`);
      alert(`✅ BOOKED! Ref: ${rc.result?.bRefNo}`);
    } else {
      console.error('❌ confirm failed:', JSON.stringify(rc));
    }
  }

  // ---------- GROUP helpers ----------
  const matchSevak = (s, key) => s.sevakId == key || (s.sevakName || '').trim().toLowerCase() === String(key).trim().toLowerCase();

  function pickGroup(mList) {
    const members = CONFIG.members.length
      ? CONFIG.members.map(k => mList.find(s => matchSevak(s, k)) || (console.error('❌ Not in master list:', k), null))
      : mList.slice();
    if (members.includes(null)) return null;
    if (members.length < 10 || members.length > 15) {
      console.error(`❌ GROUP needs 10-15 members, got ${members.length}`); return null;
    }
    const leader = CONFIG.leader != null
      ? members.find(s => matchSevak(s, CONFIG.leader))
      : (members.find(s => s.isGroupLeader) || members[0]);
    if (!leader) { console.error('❌ Leader not among members:', CONFIG.leader); return null; }
    console.log(`👥 Group: ${members.length} | leader: ${leader.sevakName} (${leader.sevakId})`);
    return { members, leader };
  }

  // ⚠️ GROUP attach shape is a best guess from the individual flow — dryRun first
  async function attachGroup(ticketId, { members, leader }) {
    const tk = await gget('/get_by_user_id');
    const norm = n => (n || '').trim().toLowerCase();
    const already = new Set((tk?.result?.sevaksList || []).map(s => norm(s.sevakName)));
    const leaderId = leader.sevakId;
    for (const m of [leader, ...members.filter(x => x !== leader)]) {
      const isLeader = m === leader;
      if (already.has(norm(m.sevakName))) { console.log('↪ already on ticket:', m.sevakName); continue; }
      const sevakDetail = {
        ...m,
        masterSevakId: m.masterSevakId || leaderId,
        isMaster: isLeader,
        isSecondaryLeader: false,
        isGroupLeader: isLeader,
        id: m.sevakId
      };
      const r2 = await post('/add_sevak_to_master_list',
        { isGroupLeader: isLeader, isSecondaryLeader: false, sevakDetail, masterSevakId: sevakDetail.masterSevakId },
        'registration_type=GROUP');
      if (r2?.status !== 'success') { console.error('❌ add_sevak failed:', m.sevakName, JSON.stringify(r2)); return false; }
      const r3 = await post('/add_sevaks', {
        ticketId, isGroupLeader: isLeader, isSecondaryLeader: false, registeredSevakId: null,
        sevakDetail: { ...sevakDetail, id: r2.result?.sevakId ?? m.sevakId }
      });
      if (r3?.status !== 'success') { console.error('❌ add_sevaks failed:', m.sevakName, JSON.stringify(r3)); return false; }
      console.log(`✅ attached ${isLeader ? '(leader) ' : ''}${m.sevakName}`);
    }
    return true;
  }

  async function sevaTypeFor(date) {
    try {
      const q = `sevaType=${CONFIG.bookingType}&sevaName=${encodeURIComponent(CONFIG.sevaName)}&remarks=${encodeURIComponent(CONFIG.remarks)}`;
      const r = await gget(`/slot/get_availability?${q}`);
      const key = Object.keys(r?.result?.totalDateSlots?.[date]?.slots || {})[0];
      if (key) return Number(key);
    } catch (e) { if (e.message === 'SESSION_EXPIRED') throw e; }
    console.warn('⚠️ No slot type for', date, '— using CONFIG.sevaTypeId', CONFIG.sevaTypeId);
    return CONFIG.sevaTypeId;
  }

  async function listMembers() {
    const r = await gget('/get_master_sevaks');
    (r?.result || []).forEach((s, i) => console.log(`${i + 1}. ${s.sevakId} | ${s.sevakName} | ${s.gender} | ${s.age}${s.isGroupLeader ? ' | LEADER' : ''}`));
  }

  // Remove sevak(s) from the OPEN ticket (same call the site makes on untick)
  async function removeSevaks() {
    const tk = await gget('/get_by_user_id');
    const t = tk?.result;
    if (!t) { console.error('❌ No ticket:', JSON.stringify(tk)); return; }
    if (t.bookingStatus !== 'OPEN') {
      console.warn(`⛔ Ticket ${t.id} is ${t.bookingStatus} — not touching a confirmed booking`);
      return;
    }
    const list = t.sevaksList || [];
    if (!list.length) { console.log('ℹ️ Ticket', t.id, 'has no sevaks'); return; }
    for (const s of list) {
      const r = await gget(`/delete/${s.registeredSevakId}?regId=${t.id}`);
      console.log(r?.status === 'success' ? '🗑 removed' : '❌ remove failed', s.sevakName, s.registeredSevakId, r?.reason?.reason_eng || '');
    }
  }

  async function checkAvailability() {
    console.log('🔍 Checking...');
    const q = `sevaType=${CONFIG.bookingType}&sevaName=${encodeURIComponent(CONFIG.sevaName)}&remarks=${encodeURIComponent(CONFIG.remarks)}`;
    const r = await gget(`/slot/get_availability?${q}`);
    if (r?.result?.totalDateSlots) {
      const avail = Object.entries(r.result.totalDateSlots).filter(([,v])=>v.avl>0);
      avail.forEach(([d,v])=>console.log(`✅ ${d}: ${v.avl} slots`));
      return avail.map(([d,v])=>({date:d,avl:v.avl}));
    }
    console.log('raw:', JSON.stringify(r).slice(0,200));
    return [];
  }

  async function watchAndBook() {
    console.log('👁 Watch mode | autoBook:', CONFIG.autoBook);
    let busy = false;
    const iv = setInterval(async () => {
      if (busy) return;               // previous check still running — skip this tick
      busy = true;
      try {
        const avail = await checkAvailability();
        if (avail.length) {
          console.log('🔔 SLOTS OPEN!', avail);
          if (CONFIG.autoBook) {
            clearInterval(iv);
            CONFIG.sevaDate = avail[0].date;
            await book();
          }
        }
      } catch (e) {
        if (e.message === 'SESSION_EXPIRED') {
          clearInterval(iv);
          alert('🔒 TTD session expired — watch stopped. Log in again.');
        } else console.error('watch error:', e);
      } finally { busy = false; }
    }, CONFIG.watchInterval);
    window.__TTD_WATCH = iv;
  }

  console.log('%c TTD Console v10 ', 'background:#059669;color:white;font-size:16px;padding:4px');
  console.log('TTD.book() | TTD.members() | TTD.remove() | TTD.check() | TTD.watch() | TTD.stop()');
  console.log('Config:', CONFIG);
  console.log('Change date: TTD.config({sevaDate:"20261027"})');

  window.TTD = {
    book, remove:removeSevaks, members:listMembers, check:checkAvailability, watch:watchAndBook,
    stop:()=>{clearInterval(window.__TTD_WATCH);console.log('⏹');},
    config:(c)=>{Object.assign(CONFIG,c);console.log('Config:',CONFIG);},
    cfg:CONFIG
  };
})();
