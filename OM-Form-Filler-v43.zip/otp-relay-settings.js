/* Settings for the TTD login OTP relay (new) — stored in chrome.storage.local "omOtpRelay" */
document.addEventListener("DOMContentLoaded", async () => {
  const $ = (id) => document.getElementById(id);
  if (!$("otp_url")) return;
  const { omOtpRelay: cfg = {} } = await chrome.storage.local.get("omOtpRelay");
  $("otp_url").value = cfg.url || ""; $("otp_key").value = cfg.key || ""; $("otp_on").checked = !!cfg.enabled;
  $("otp_mobiles").value = cfg.mobiles || ""; $("otp_autoSend").checked = !!cfg.autoSend;
  const save = () => chrome.storage.local.set({ omOtpRelay: { url: $("otp_url").value.trim(), key: $("otp_key").value.trim(), enabled: $("otp_on").checked,
    mobiles: $("otp_mobiles").value, autoSend: $("otp_autoSend").checked } });
  ["otp_url", "otp_key", "otp_mobiles"].forEach(id => { $(id).addEventListener("change", save); $(id).addEventListener("input", save); });
  ["otp_on", "otp_autoSend"].forEach(id => $(id).addEventListener("change", save));
  $("otp_test").addEventListener("click", async () => {
    await save();
    const msg = $("otp_msg");
    const url = $("otp_url").value.trim().replace(/\/+$/, ""), key = $("otp_key").value.trim();
    if (!/^https:\/\//.test(url) || !key) { msg.style.color = "#f38ba8"; msg.textContent = "Enter the https relay URL and key first"; return; }
    try {
      const res = await fetch(`${url}/otp?mobile=0000000000&since=${Date.now()}`, { headers: { "X-Key": key }, cache: "no-store" });
      if (res.status === 204) { msg.style.color = "#a6e3a1"; msg.textContent = "✅ Relay reachable and key accepted"; }
      else if (res.status === 401) { msg.style.color = "#f38ba8"; msg.textContent = "❌ Relay rejected the key (401)"; }
      else { msg.style.color = "#f9e2af"; msg.textContent = `Relay answered HTTP ${res.status} — is the /otp route added to the Worker?`; }
    } catch (e) { msg.style.color = "#f38ba8"; msg.textContent = "❌ Can't reach relay: " + e.message; }
  });
});
