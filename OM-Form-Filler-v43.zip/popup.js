/* =========================================================
   POPUP SCRIPT — CLEAN & SAFE VERSION (IMAGE LIBRARY FIXED)
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

  console.log("🔥 popup.js DOM ready");

  /* ================= DOM ================= */

  const pasteBox = document.getElementById("pasteBox");

  // ── Slow down textarea scroll speed for easier editing ──
  pasteBox?.addEventListener("wheel", (e) => {
    e.preventDefault();
    const lineHeight = 19; // px per line (~12px font * 1.6 lineHeight)
    const lines = e.deltaY > 0 ? 2 : -2; // scroll 2 lines at a time
    pasteBox.scrollTop += lines * lineHeight;
  }, { passive: false });
  const profileListTop = document.getElementById("profileListTop");
  const clearBtn = document.getElementById("clearPasteBoxBtn");
  const fillBtn = document.getElementById("fillBtn");
  const counter = document.getElementById("counter");

  const fileInput = document.getElementById("fileInput");
  const fileNameSpan = document.querySelector(".file-name");

  const tableModeRadio = document.getElementById("tableMode");
  const tableProfiles = document.getElementById("tableProfiles");
  const profileList = document.getElementById("profileList");

  const repeatToggle = document.getElementById("repeatToggle");

  /* ================= IMAGE LIBRARY ================= */

  const openImageBtn = document.getElementById("openImageLibrary");
  const closeImageBtn = document.getElementById("closeImageLibrary");
  const imagePanel = document.getElementById("imageLibraryPanel");

  const MAX_IMAGE_SIZE_MB = 2;

  let selectedForDelete = new Set();
  let lastSelectedIndex = null;
  let profiles = [];

  const PROFILE_STORAGE_KEY = "savedProfiles";
const TRASH_STORAGE_KEY   = "deletedProfiles";
const MAX_TRASH = 20;

let trash = [];  // [{text, deletedAt, label}, ...]

// Load trash from storage
chrome.storage.local.get(TRASH_STORAGE_KEY, (res) => {
  trash = res[TRASH_STORAGE_KEY] || [];
});

function moveToTrash(text, label) {
  if (!text || !text.trim()) return;
  trash.unshift({ text: text.trim(), deletedAt: Date.now(), label: label || "" });
  if (trash.length > MAX_TRASH) trash.length = MAX_TRASH;
  chrome.storage.local.set({ [TRASH_STORAGE_KEY]: trash });
}

function saveSnapshot(index, text) {
  // kept for compatibility
}


chrome.storage.local.get(["currentDraft", PROFILE_STORAGE_KEY], (res) => {
  if (res.currentDraft) {
    pasteBox.value = res.currentDraft;
    updateUI();

    // Restore _activeProfileIndex: find which pill matches the current draft
    const savedProfiles = res[PROFILE_STORAGE_KEY];
    if (Array.isArray(savedProfiles)) {
      const matchIndex = savedProfiles.findIndex(p => p === res.currentDraft.trim());
      if (matchIndex !== -1) {
        _activeProfileIndex = matchIndex;
        // Highlight matching pill after it renders
        setTimeout(() => {
          const pills = document.querySelectorAll(".profile-pill");
          pills.forEach((p, i) => {
            p.classList.toggle("active", i === matchIndex);
          });
        }, 100);
      }
    }
  }
});


let _suppressDraftSave = false;
let _activeProfileIndex = null;   // which pill is currently loaded in textarea

profileListTop?.addEventListener("click", function (e) {
  const pill = e.target.closest(".profile-pill");
  if (!pill) return;

  const number = pill.querySelector(".pill-number");
  const index = parseInt(number.dataset.index, 10);

  if (profiles[index] === undefined) return;

  // ── Save current textarea edits back to the active pill BEFORE switching ──
  if (
    _activeProfileIndex !== null &&
    _activeProfileIndex !== index &&
    profiles[_activeProfileIndex] !== undefined
  ) {
    const currentText = pasteBox.value.trim();
    if (currentText && currentText !== profiles[_activeProfileIndex]) {
      saveSnapshot(_activeProfileIndex, profiles[_activeProfileIndex]); // backup old version
      profiles[_activeProfileIndex] = currentText;
      chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profiles });
    }
  }

  // ── Load selected pill into textarea ──
  // If clicking the SAME pill that's already active, don't overwrite edits
  if (_activeProfileIndex === index) {
    // Just re-highlight, don't reload
    document.querySelectorAll(".profile-pill")
      .forEach(p => p.classList.remove("active"));
    pill.classList.add("active");
    return;
  }

  _suppressDraftSave = true;
  pasteBox.value = profiles[index];
  _activeProfileIndex = index;
  updateUI();
  setTimeout(() => { _suppressDraftSave = false; }, 0);

  document.querySelectorAll(".profile-pill")
    .forEach(p => p.classList.remove("active"));

  pill.classList.add("active");
});


  // ── ? button — opens COMMANDS.html in a new tab ──
  document.getElementById("helpTooltipBtn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("COMMANDS.html") });
  });

  // ── Quick format guide toggle ──
  const toggleGuideBtn = document.getElementById("toggleGuideBtn");
  const guideContent   = document.getElementById("guideContent");
  const guideArrow     = document.getElementById("guideArrow");
  toggleGuideBtn?.addEventListener("click", () => {
    const isHidden = guideContent.classList.toggle("hidden");
    guideArrow.textContent = isHidden ? "▶" : "▼";
  });

  // ── Highlight active pill when repeat mode cycles through profiles ──
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "REPEAT_PROFILE_USED") {
      const idx = msg.index;
      _activeProfileIndex = idx;
      document.querySelectorAll(".profile-pill").forEach((p, i) => {
        p.classList.toggle("active", i === idx);
      });
      // Update repeat indicator
      const indicator = document.getElementById("repeatIndicator");
      if (indicator) indicator.textContent = `(${idx + 1}/${profiles.length})`;
      // Load the used profile into textarea
      if (profiles[idx] !== undefined) {
        _suppressDraftSave = true;
        pasteBox.value = profiles[idx];
        updateUI();
        setTimeout(() => { _suppressDraftSave = false; }, 0);
      }
    }
  });

  // ── Scan Page button ──
  const scanPageBtn   = document.getElementById("scanPageBtn");
  const scanPanel     = document.getElementById("scanResultPanel");
  const scanSummary   = document.getElementById("scanSummary");
  const scanPreview   = document.getElementById("scanCommandPreview");
  const scanUseBtn    = document.getElementById("scanUseBtn");
  const scanDismissBtn = document.getElementById("scanDismissBtn");

  let _lastScanResult = null;

  scanPageBtn?.addEventListener("click", async () => {
    scanPageBtn.disabled = true;
    scanPageBtn.textContent = "⏳ Scanning...";

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return;

      // Inject content.js if needed
      try {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      } catch(e) {}

      await new Promise(r => setTimeout(r, 150));

      chrome.tabs.sendMessage(tab.id, { type: "SCAN_PAGE" }, (res) => {
        scanPageBtn.disabled = false;
        scanPageBtn.textContent = "🔍 Scan Page";

        if (!res || chrome.runtime.lastError) {
          alert("Could not scan this page. Try refreshing.");
          return;
        }

        _lastScanResult = res;

        // Build summary tags
        const tags = [];
        if (res.fields.length)            tags.push({ icon: "📝", text: `${res.fields.length} fields`, warn: false });
        if (res.buttons.length)            tags.push({ icon: "🔘", text: `${res.buttons.length} buttons`, warn: false });
        if (res.hasCalendar)               tags.push({ icon: "📅", text: "Calendar", warn: false });
        if (res.hasSlotCards.length)       tags.push({ icon: "🃏", text: `${res.hasSlotCards.length} slot cards`, warn: false });
        if (res.hasRadios.length)          tags.push({ icon: "⭕", text: `${res.hasRadios.length} radio options`, warn: false });
        if (res.hasCheckboxes.length)      tags.push({ icon: "☑️", text: `${res.hasCheckboxes.length} checkboxes`, warn: false });
        if (res.hasNativeSelects.length)   tags.push({ icon: "▼", text: `${res.hasNativeSelects.length} selects`, warn: false });
        if (res.hasFakeDropdowns?.length)  tags.push({ icon: "▼", text: `${res.hasFakeDropdowns.length} dropdowns`, warn: false });
        if (res.hasFileInputs)             tags.push({ icon: "📎", text: "File upload", warn: true });
        if (!res.fields.length && !res.buttons.length) tags.push({ icon: "⚠️", text: "Nothing detected", warn: true });

        scanSummary.innerHTML = tags.map(t =>
          `<span class="scan-tag ${t.warn ? 'warn' : ''}">${t.icon} ${t.text}</span>`
        ).join("");

        scanPreview.textContent = res.generatedCommand || "# Nothing to generate";
        scanPanel.classList.add("visible");
      });

    } catch(e) {
      scanPageBtn.disabled = false;
      scanPageBtn.textContent = "🔍 Scan Page";
      console.error("Scan error:", e);
    }
  });

  scanUseBtn?.addEventListener("click", () => {
    if (!_lastScanResult?.generatedCommand) return;
    pasteBox.value = _lastScanResult.generatedCommand;
    scanPanel.classList.remove("visible");
    updateUI();
    autoSaveCurrentText();
    showFlashMessage("✅ Command inserted into textarea");
  });

  scanDismissBtn?.addEventListener("click", () => {
    scanPanel.classList.remove("visible");
    _lastScanResult = null;
  });

  const generateBtn = document.getElementById("generateBtn");

    generateBtn?.addEventListener("click", async () => {
      const generateWithValues =
        document.getElementById("Generatevalues")?.checked === true;

      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      if (!tab?.id) return;

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["generatefile.js"]
      });

      chrome.tabs.sendMessage(
        tab.id,
        { type: "GENERATE_READ_ONLY" },
        (res) => {
          if (!res || !Array.isArray(res.fields)) {
            alert("No form detected");
            return;
          }

          let text = "fill\n\n---\n";

          if (generateWithValues) {
            text += res.fields
              .map(f => `${f.label}, ${f.value || ""}`)
              .join("\n");
          } else {
            text += res.fields
              .map(f => `${f.label}, `)
              .join("\n");
          }

          downloadGeneratedFile(text);
        }
      );
    });


  function restoreProfiles() {
    chrome.storage.local.get(PROFILE_STORAGE_KEY, (res) => {
      if (Array.isArray(res[PROFILE_STORAGE_KEY])) {
        profiles = res[PROFILE_STORAGE_KEY];
        renderProfiles();
      }
    });
  }

  restoreProfiles();

    document.getElementById("clearForm").addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      chrome.tabs.sendMessage(tab.id, { action: "CLEAR_FORM" });
    });

   document.getElementById("clearAllProfiles")?.addEventListener("click", () => {
    if (profiles.length === 0) return;
    // Move all to trash before clearing
    profiles.forEach((p, i) => moveToTrash(p, "Profile " + (i + 1)));
    profiles = [];
    chrome.storage.local.remove(PROFILE_STORAGE_KEY);
    renderProfiles();
    showFlashMessage("🗑 All cleared — click 🗑 Trash to restore");
  });

  // ── Trash panel ──
  const trashBtn      = document.getElementById("trashBtn");
  const trashPanel    = document.getElementById("trashPanel");
  const trashList     = document.getElementById("trashList");
  const trashClose    = document.getElementById("trashClose");
  const clearTrashBtn = document.getElementById("clearTrashBtn");

  function renderTrash() {
    if (!trashList) return;
    if (trash.length === 0) {
      trashList.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:8px;">No deleted profiles</div>';
      return;
    }
    trashList.innerHTML = trash.map((item, i) => {
      const date = new Date(item.deletedAt);
      const when = date.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}) +
                   " " + date.toLocaleDateString([], {month:"short", day:"numeric"});
      const preview = item.text.split("\n")[0].slice(0, 38);
      return `<div style="display:flex;align-items:center;gap:6px;padding:4px 2px;border-bottom:1px solid #fed7aa;">
        <div style="flex:1;min-width:0;">
          <div style="font-size:11px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${preview}</div>
          <div style="font-size:10px;color:#9ca3af;">${item.label} · ${when}</div>
        </div>
        <button data-trash-index="${i}" style="flex-shrink:0;padding:2px 7px;font-size:11px;border-radius:4px;border:1px solid #86efac;background:#f0fdf4;color:#166534;cursor:pointer;">↩ Restore</button>
      </div>`;
    }).join("");

    trashList.querySelectorAll("[data-trash-index]").forEach(btn => {
      btn.addEventListener("click", () => {
        const i = parseInt(btn.dataset.trashIndex, 10);
        const item = trash[i];
        if (!item) return;
        profiles.push(item.text);
        trash.splice(i, 1);
        chrome.storage.local.set({
          [PROFILE_STORAGE_KEY]: profiles,
          [TRASH_STORAGE_KEY]: trash
        });
        renderProfiles();
        renderTrash();
        showFlashMessage("✅ Profile restored!");
      });
    });
  }

  trashBtn?.addEventListener("click", () => {
    const isVisible = trashPanel.style.display !== "none";
    trashPanel.style.display = isVisible ? "none" : "block";
    if (!isVisible) renderTrash();
  });

  trashClose?.addEventListener("click", () => {
    trashPanel.style.display = "none";
  });

  clearTrashBtn?.addEventListener("click", () => {
    trash = [];
    chrome.storage.local.remove(TRASH_STORAGE_KEY);
    renderTrash();
    showFlashMessage("🗑 Trash emptied");
  });


  document.getElementById("addProfileBtn")?.addEventListener("click", () => {
    const text = pasteBox.value.trim();
    if (!text) return;

    // Determine if text is a WORKFLOW (has commands) or MULTI-PROFILE data
    // Workflow: has fill/click/date/etc commands → keep as ONE profile always
    // Multi-profile: only data separated by --- → split into multiple profiles
    const WORKFLOW_KEYWORDS = /^(fill|date|click|select|section|next|submit|back|wait|upload|icon|row)\b/im;
    const isWorkflow = text.includes("===") || WORKFLOW_KEYWORDS.test(text);

    let parts;
    if (isWorkflow) {
      // Workflow command — never split, always one profile
      parts = [text];
    } else {
      // Pure data mode — --- separates different person profiles
      parts = text
        .split(/\n---\n|\n---$|^---\n/m)
        .map(p => p.trim())
        .filter(Boolean);
    }

    let added = 0;
    parts.forEach(part => {
      const existingIdx = profiles.indexOf(part);
      if (existingIdx === -1) {
        profiles.push(part);
        added++;
      }
    });

    // Update active index to point to last added profile
    if (added > 0) {
      _activeProfileIndex = profiles.length - 1;
    }

    chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profiles });
    chrome.storage.local.remove("currentDraft");

    renderProfiles();

    pasteBox.value = "";
    _activeProfileIndex = null;
    updateUI();

    if (added === 0) {
      showFlashMessage("⚠️ Already in list (no duplicate added)");
    } else {
      showFlashMessage(`✅ ${added} profile${added > 1 ? "s" : ""} added to list`);
    }
  });


    /* ===============================
   CREATE PROFILE (auto-save draft only, no auto-add)
    =============================== */

      function autoSaveCurrentText() {
      if (_suppressDraftSave) return;
      const raw = pasteBox.value.trim();
      // only save draft — do NOT auto-add to profiles list
      chrome.storage.local.set({ currentDraft: raw });
    }
    /* ===============================
       RENDER PROFILE LIST
    =============================== */



function renderProfiles() {
  if (!profileListTop) return;

  profileListTop.innerHTML = "";

  profiles.forEach((profile, index) => {
    const pill = document.createElement("div");
    pill.className = "profile-pill";

    pill.innerHTML = `
      <span class="pill-delete" data-index="${index}">✕</span>
      <span class="pill-number" data-index="${index}">${index + 1}</span>
    `;

    profileListTop.appendChild(pill);
  });

  attachDelete();

  profileListTop.scrollLeft = profileListTop.scrollWidth;
  
}

    /* ===============================
       DELETE PROFILE
    =============================== */

 function attachDelete() {
  document.querySelectorAll(".pill-delete").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const index = parseInt(e.target.dataset.index, 10);

      // Two-click confirmation — prevents accidental delete
      if (btn.dataset.confirm === "1") {
        // Second click: confirmed — move to trash (not permanent delete)
        const deletedText = profiles[index];
        const deletedLabel = "Profile " + (index + 1);
        moveToTrash(deletedText, deletedLabel);
        profiles.splice(index, 1);
        if (_activeProfileIndex === index) {
          _activeProfileIndex = null;
          pasteBox.value = "";
          updateUI();
        } else if (_activeProfileIndex > index) {
          _activeProfileIndex--;
        }
        chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profiles });
        renderProfiles();
        showFlashMessage("🗑 Deleted — click 🗑 Trash to restore");
      } else {
        // First click: show confirm state
        btn.dataset.confirm = "1";
        btn.textContent = "?";
        btn.style.background = "#ef4444";
        btn.style.color = "#fff";
        btn.style.display = "flex";  // keep visible while confirming
        // Auto-cancel after 2s
        setTimeout(() => {
          if (btn.dataset.confirm === "1") {
            btn.dataset.confirm = "";
            btn.textContent = "✕";
            btn.style.background = "";
            btn.style.color = "";
            btn.style.display = "";
          }
        }, 2000);
      }
    });
  });
}
    /* ===============================
       CLEAR TEXTAREA
    =============================== */

    clearBtn?.addEventListener("click", () => {
        pasteBox.value = "";
        chrome.storage.local.remove("currentDraft");
        updateUI();
      });

  /* =========================================================
     PRESETS — save/load named command blocks
  ========================================================= */
  const PRESETS_KEY       = "savedPresets";
  let presets             = [];

  const presetsPanel      = document.getElementById("presetsPanel");
  const openPresetsBtn    = document.getElementById("openPresetsBtn");
  const closePresetsBtn   = document.getElementById("closePresetsBtn");
  const savePresetBtn     = document.getElementById("savePresetBtn");
  const presetListEl      = document.getElementById("presetList");
  const presetEmptyEl     = document.getElementById("presetEmpty");
  const presetSearchInput = document.getElementById("presetSearchInput");

  const KNOWN_COMMANDS_P = [
    "fill","section","click","add","next","submit","back","checkall","if",
    "wait","waitpage","waitcalendar","icon","upload","row",
    "select","date","pickslot","anysite","scroll","press","hover","goto","type"
  ];

  chrome.storage.local.get(PRESETS_KEY, (res) => {
    presets = res[PRESETS_KEY] || [];
  });

  // ── Import / Export all presets ──────────────────────────────────
  const exportBtn = document.getElementById("exportPresetsBtn");
  const importBtn = document.getElementById("importPresetsBtn");
  const importFile = document.getElementById("importPresetsFile");

  exportBtn?.addEventListener("click", () => {
    // savedPresets is the key the extension uses for all presets
    chrome.storage.local.get("savedPresets", (res) => {
      const list = res["savedPresets"] || [];
      if (!list.length) { alert("No presets saved yet."); return; }
      const blob = new Blob([JSON.stringify({ savedPresets: list }, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url;
      a.download = "om-form-filler-presets.json"; a.click();
      URL.revokeObjectURL(url);
    });
  });

  importBtn?.addEventListener("click", () => importFile?.click());

  importFile?.addEventListener("change", () => {
    const file = importFile.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        // accept both {savedPresets:[...]} and a raw array [...]
        const incoming = Array.isArray(data) ? data : (data.savedPresets || []);
        if (!Array.isArray(incoming) || !incoming.length) throw new Error("No presets found in file");
        chrome.storage.local.get("savedPresets", (res) => {
          const existing = res["savedPresets"] || [];
          // merge: skip duplicates by id, add new ones
          const ids = new Set(existing.map(p => p.id));
          const merged = [...existing, ...incoming.filter(p => !ids.has(p.id))];
          chrome.storage.local.set({ savedPresets: merged }, () => {
            presets = merged;
            alert("✅ " + incoming.length + " preset(s) imported. " + (merged.length - existing.length) + " new added.");
            renderPresets();
          });
        });
      } catch (err) {
        alert("❌ Import failed: " + err.message);
      }
    };
    reader.readAsText(file);
    importFile.value = "";
  });
  // ──────────────────────────────────────────────────────────────────

  openPresetsBtn?.addEventListener("click", () => {
    presetsPanel.classList.remove("hidden");
    renderPresets();
    presetSearchInput?.focus();
  });

  closePresetsBtn?.addEventListener("click", () => {
    presetsPanel.classList.add("hidden");
  });

  function extractCommandSection(text) {
    const sep = text.match(/\n\s*(?:---|===)\s*\n/);
    if (sep) return text.slice(0, sep.index).trim();
    const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
    const lastCmd = lines.reduce((last, line, i) => {
      const w = line.split(/\s+/)[0].toLowerCase();
      return KNOWN_COMMANDS_P.includes(w) ? i : last;
    }, -1);
    return lastCmd >= 0 ? lines.slice(0, lastCmd + 1).join("\n") : "";
  }

  function applyPreset(commandText) {
    const current  = pasteBox.value;
    const sepMatch = current.match(/\n\s*(?:---|===)\s*\n/);
    const dataPart = sepMatch ? current.slice(sepMatch.index) : "";
    pasteBox.value = commandText + (dataPart || "");
    updateUI();
    autoSaveCurrentText();
    presetsPanel.classList.add("hidden");
    showFlashMessage("✅ Preset loaded!");
  }

  function renderPresets(filter = "") {
    if (!presetListEl) return;
    presetListEl.innerHTML = "";
    const q = filter.toLowerCase().trim();
    const filtered = presets.filter(p =>
      !q || p.name.toLowerCase().includes(q) || p.commands.toLowerCase().includes(q)
    );
    if (filtered.length === 0) {
      presetEmptyEl.style.display = "block";
      return;
    }
    presetEmptyEl.style.display = "none";
    [...filtered].reverse().forEach(preset => {
      const card = document.createElement("div");
      card.className = "preset-card";
      const d = new Date(preset.createdAt);
      const when = d.toLocaleDateString([],{month:"short",day:"numeric"}) + " " +
                   d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
      const preview = preset.commands.split("\n").map(l=>l.trim()).filter(Boolean)
                        .slice(0,3).join("  ·  ");
      card.innerHTML = `
        <div class="preset-card-name" title="${preset.name}">${preset.name}</div>
        <div class="preset-card-preview">${preview}</div>
        <div class="preset-card-meta">${when}</div>
        <div class="preset-card-actions">
          <button class="preset-load-btn">Load</button>
          <button class="preset-del-btn">✕</button>
        </div>`;
      card.addEventListener("click", (e) => {
        if (e.target.closest(".preset-card-actions")) return;
        applyPreset(preset.commands);
      });
      card.querySelector(".preset-load-btn").addEventListener("click", (e) => {
        e.stopPropagation();
        applyPreset(preset.commands);
      });
      const delBtn = card.querySelector(".preset-del-btn");
      delBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        if (delBtn.dataset.confirm === "1") {
          presets = presets.filter(p => p.id !== preset.id);
          chrome.storage.local.set({ [PRESETS_KEY]: presets });
          renderPresets(presetSearchInput?.value || "");
          showFlashMessage("🗑 Preset deleted");
        } else {
          delBtn.dataset.confirm = "1";
          delBtn.textContent = "?";
          setTimeout(() => {
            if (delBtn.dataset.confirm === "1") {
              delBtn.dataset.confirm = "";
              delBtn.textContent = "✕";
            }
          }, 2000);
        }
      });
      presetListEl.appendChild(card);
    });
  }

  savePresetBtn?.addEventListener("click", () => {
    const raw = pasteBox.value.trim();
    if (!raw) { showFlashMessage("⚠️ Textarea is empty"); return; }
    const cmdText = extractCommandSection(raw);
    if (!cmdText) { showFlashMessage("⚠️ No commands found above ---"); return; }
    const firstLine = cmdText.split("\n").find(l => l.trim()) || "Preset";
    const name = prompt("Name this preset:", firstLine.trim().slice(0, 40));
    if (!name?.trim()) return;
    const preset = {
      id:        Date.now() + "_" + Math.random().toString(36).slice(2,6),
      name:      name.trim(),
      commands:  cmdText,
      createdAt: Date.now()
    };
    presets.push(preset);
    chrome.storage.local.set({ [PRESETS_KEY]: presets });
    renderPresets(presetSearchInput?.value || "");
    showFlashMessage(`✅ Preset "${preset.name}" saved!`);
  });

  presetSearchInput?.addEventListener("input", () => {
    renderPresets(presetSearchInput.value);
  });

  /* END PRESETS */

    /* ===============================
       CREATE PROFILE ON PASTE
    =============================== */

   




  console.log("openImageBtn =", openImageBtn);
  console.log("imagePanel =", imagePanel);

  if (openImageBtn && imagePanel) {
    openImageBtn?.addEventListener("click", () => {
      console.log("📸 Image Library OPEN");
      imagePanel.classList.remove("hidden");
      loadImageLibraryFromStorage(); // 🔥 IMPORTANT
    });

    closeImageBtn?.addEventListener("click", () => {
      imagePanel.classList.add("hidden");
    });
  } else {
    console.error("❌ Image Library elements missing");
  }


  /* =========================================================
   IMAGE LIBRARY LOGIC (MISSING PART)
   ========================================================= */

const imagePicker = document.getElementById("imagePicker");
const imageGrid = document.getElementById("imageGrid");
const saveImagesBtn = document.getElementById("saveImages");

let selectedImages = {};

/* -------- Load saved images on open -------- */
chrome.storage.local.get("imageLibrary", (res) => {
  if (res.imageLibrary && typeof res.imageLibrary === "object") {
  selectedImages = res.imageLibrary;
  renderImageGrid();
  }
});

/* -------- Pick images -------- */
imagePicker?.addEventListener("change", () => {
  const files = [...imagePicker.files];

  files.forEach(file => {
    const sizeMB = file.size / (1024 * 1024);

    if (sizeMB > MAX_IMAGE_SIZE_MB) {
      alert(
        `❌ ${file.name} is ${sizeMB.toFixed(2)} MB\nMax allowed: ${MAX_IMAGE_SIZE_MB} MB`
      );
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      // ✅ store in memory
      selectedImages[file.name] = {
        name: file.name,
        type: file.type,
        data: reader.result,
        used: false
      };

      // ✅ persist immediately
      chrome.storage.local.set(
        { imageLibrary: selectedImages },
        () => {
          console.log("💾 Image saved:", file.name);
          renderImageGrid(); // ⭐ render AFTER save
        }
      );
    };

    reader.readAsDataURL(file);
  });

  // allow selecting same file again
  imagePicker.value = "";
});




const deleteSelectedBtn = document.getElementById("deleteSelectedImages");

deleteSelectedBtn?.addEventListener("click", () => {
  if (!selectedForDelete.size) {
    alert("No images selected");
    return;
  }

  if (!confirm(`Delete ${selectedForDelete.size} selected images?`)) return;

  selectedForDelete.forEach(name => {
    delete selectedImages[name];
  });

  selectedForDelete.clear();

  chrome.storage.local.set(
    { imageLibrary: selectedImages },
    () => {
      renderImageGrid();
      console.log("🗑 Multiple images deleted");
    }
  );
});


const selectAllCheckbox = document.getElementById("selectAllImages");

selectAllCheckbox?.addEventListener("change", () => {
  const allThumbs = document.querySelectorAll(".image-thumb");

  selectedForDelete.clear();

  if (selectAllCheckbox.checked) {
    allThumbs.forEach(div => {
      const name = div.querySelector(".img-name")?.textContent.trim();
      if (name) {
        selectedForDelete.add(name);
        div.classList.add("selected");
      }
    });
  } else {
    allThumbs.forEach(div => div.classList.remove("selected"));
  }
});



function renderImageGrid() {
  imageGrid.innerHTML = "";

  const query =
    document.getElementById("imageSearch")?.value
      .toLowerCase()
      .trim() || "";

  const files = Object.values(selectedImages)
    .filter(f => f.name.toLowerCase().includes(query));

  files.forEach((file, index) => {
    const div = document.createElement("div");
    div.className = "image-thumb";

    if (selectedForDelete.has(file.name)) {
      div.classList.add("selected");
    }

    const ext = file.name.split(".").pop().toLowerCase();

    let previewHTML = "";

    if (file.type.startsWith("image/")) {
      previewHTML = `<img src="${file.data}" />`;
    }
    else if (file.type === "application/pdf") {
      previewHTML = `<div class="file-preview pdf">📄<span>PDF</span></div>`;
    }
    else if (["doc", "docx"].includes(ext)) {
      previewHTML = `<div class="file-preview doc">📝<span>DOC</span></div>`;
    }
    else if (ext === "zip") {
      previewHTML = `<div class="file-preview zip">🗜<span>ZIP</span></div>`;
    }
    else if (ext === "rar") {
      previewHTML = `<div class="file-preview rar">🗄<span>RAR</span></div>`;
    }
    else {
      previewHTML = `<div class="file-preview file">📦<span>FILE</span></div>`;
    }

    div.innerHTML = `
      <div class="thumb-wrapper">
        ${previewHTML}
        ${file.used ? `<span class="used-tick">✔</span>` : ""}
        <div class="img-actions">
          <span class="icon-btn rename-btn" title="Rename">✏️</span>
          <span class="icon-btn delete-btn" title="Delete">🗑</span>
        </div>
      </div>

      <div class="img-name" title="${file.name}">
        ${file.name}
      </div>
    `;

    /* ================= CLICK / SHIFT CLICK ================= */

    div.onclick = (e) => {
      if (e.target.closest(".icon-btn")) return;

      if (e.shiftKey && lastSelectedIndex !== null) {
        const start = Math.min(lastSelectedIndex, index);
        const end = Math.max(lastSelectedIndex, index);

        for (let i = start; i <= end; i++) {
          selectedForDelete.add(files[i].name);
        }

        renderImageGrid();
        return;
      }

      if (selectedForDelete.has(file.name)) {
        selectedForDelete.delete(file.name);
        div.classList.remove("selected");
      } else {
        selectedForDelete.add(file.name);
        div.classList.add("selected");
      }

      lastSelectedIndex = index;
    };

    /* ================= DELETE ================= */

    div.querySelector(".delete-btn").onclick = () => {
      if (!confirm(`Delete ${file.name}?`)) return;

      delete selectedImages[file.name];
      selectedForDelete.delete(file.name);

      chrome.storage.local.set(
        { imageLibrary: selectedImages },
        renderImageGrid
      );
    };

    /* ================= RENAME ================= */

    div.querySelector(".rename-btn").onclick = () => {
      const newName = prompt("Rename file", file.name);
      if (!newName || newName === file.name) return;

      if (selectedImages[newName]) {
        alert("File name already exists");
        return;
      }

      selectedImages[newName] = { ...file, name: newName };
      delete selectedImages[file.name];
      selectedForDelete.delete(file.name);

      chrome.storage.local.set(
        { imageLibrary: selectedImages },
        renderImageGrid
      );
    };

    imageGrid.appendChild(div);
  });

  if (files.length === 0) {
    lastSelectedIndex = null;
  }
}


document
  .getElementById("imageSearch")
  ?.addEventListener("input", () => {
    lastSelectedIndex = null; // reset shift range
    renderImageGrid();
  });


document.getElementById("selectAllImages")?.addEventListener("click", () => {
  const names = Object.values(selectedImages).map(i => i.name);

  if (selectedForDelete.size === names.length) {
    selectedForDelete.clear();        // 🔄 clear all
  } else {
    names.forEach(n => selectedForDelete.add(n)); // ☑️ select all
  }

  renderImageGrid();
});


/* -------- Save images -------- */
saveImagesBtn?.addEventListener("click", () => {
  chrome.storage.local.get("imageLibrary", (res) => {
    const existing = res.imageLibrary || {};

    const merged = {
      ...existing,
      ...selectedImages // ✅ merge, don’t overwrite
    };

    chrome.storage.local.set(
      { imageLibrary: merged },
      () => {
        console.log("✅ Images saved", merged);
        alert("Images saved successfully");
        imagePanel.classList.add("hidden");
      }
    );
  });
});


const resetUsedBtn = document.getElementById("resetUsedImages");

resetUsedBtn?.addEventListener("click", () => {
  if (!confirm("Reset used status for all images?")) return;

  chrome.storage.local.get("imageLibrary", (res) => {
    const lib = res.imageLibrary || {};

    Object.values(lib).forEach(img => {
      img.used = false;
    });

    chrome.storage.local.set({ imageLibrary: lib }, () => {
      selectedImages = lib;
      renderImageGrid();
      console.log("🔄 Image used status reset");
      alert("Used status reset successfully");
    });
  });
});



  /* ================= STATE ================= */

  const STORAGE_KEY = "formFillerState";

  let tableHeaders = [];
  let tableRows = [];
  let selectedProfileIndex = null;

  /* ================= HELPERS ================= */

  async function sendToActiveTab(payload) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    const tabId = tab.id;

    // ⏰ Scheduled start? (null = run now, false = invalid time — message already shown)
    const runAt = getScheduledRunAt();
    if (runAt === false) return;

    const segKey = `pendingSegments_${tabId}`;

    // ── Always clear stale pending segments FIRST (before saving new ones) ──
    try { await chrome.storage.session.remove(segKey); } catch(e) {}
    try { await chrome.storage.local.remove(segKey); } catch(e) {}

    /* ── Multi-segment handling ── */
    if (Array.isArray(payload.segments) && payload.segments.length > 1) {
      // 1. Tell background.js to hold segments for full-page-load navigation
      //    (in-memory only — no chrome.storage, no stale data loops)
      //    When scheduled, the page does this itself at start time (background keeps them only 10 minutes).
      if (!runAt) chrome.runtime.sendMessage({
        type:             "STORE_PENDING",
        tabId,
        segments:         payload.segments,
        segmentIndex:     1,
        repeat:           payload.repeat           || false,
        selectedRowIndex: payload.selectedRowIndex ?? null,
        speed:            parseFloat(document.getElementById("fillSpeed")?.value) || 1.0,   // carry Fast/Turbo to later pages
        originUrl:        tab.url   // used by background.js to skip external domains
      });

      console.log(`📦 ${payload.segments.length} segments — SPA watcher + background.js ready`);

      // 2. Send segment[0] now + full segments array for content.js SPA watcher
      const seg0 = payload.segments[0];
      payload = {
        ...payload,
        commands: seg0.commands || [],
        groups:   seg0.groups   || []
        // segments kept so content.js stores in window.__pendingSegments
      };
    }

    /* ── Send to content script — ping first, inject only if needed ── */
    const ping = () => new Promise(resolve => {
      chrome.tabs.sendMessage(tabId, { type: "PING" }, () => {
        resolve(!chrome.runtime.lastError);
      });
    });

    const isAlive = await ping();

    // Add unique message ID for deduplication in content.js
    payload._id = Date.now() + "_" + Math.random().toString(36).slice(2, 7);

    // Add speed setting
    const speedSel = document.getElementById("fillSpeed");
    payload._speed = speedSel ? parseFloat(speedSel.value) : 1.0;

    // Scheduled: hand the whole payload to the page, which starts it at `runAt`
    const out = runAt ? { type: "SCHEDULE_RUN", runAt, payload } : payload;
    const afterSend = () => { if (runAt) { onScheduled(runAt); chrome.runtime.sendMessage({ type: "OM_TTD_REMEMBER_SCHEDULE", tabId, runAt, payload }, () => void chrome.runtime.lastError); } };   // OM TTD add-on

    if (isAlive) {
      chrome.tabs.sendMessage(tabId, out);
      afterSend();
    } else {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          files: ["content.js"]
        });
        // Small wait for content.js to initialise its listener
        await new Promise(r => setTimeout(r, 100));
        chrome.tabs.sendMessage(tabId, out);
        afterSend();
      } catch (err) {
        console.warn("❌ Could not inject content.js:", err);
      }
    }
  }

  function horizontalToVertical(headers, row) {
    return headers.map((_, i) => row[i] ?? "");
  }



function excelDateToDDMMYYYY(value) {
  if (typeof value !== "number") return value;

  // strict Excel date range (prevents touching normal numbers)
  if (value < 30000 || value > 60000) return value;

  const excelEpoch = new Date(1899, 11, 30);
  const date = new Date(excelEpoch.getTime() + value * 86400000);

  const dd = String(date.getDate()).padStart(2, "0");
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const yyyy = date.getFullYear();

  return `${dd}/${mm}/${yyyy}`;
}





/* ================= CSV + EXCEL ================= */

fileInput?.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  fileNameSpan.textContent = file.name;

  const ext = file.name.split(".").pop().toLowerCase();

  // ---------- CSV ----------
  if (ext === "csv") {
    const text = await file.text();
    parseCSV(text);
    saveState();
    return;
  }

  // ---------- EXCEL (.xlsx) ----------
  if (ext === "xlsx") {
    parseExcel(file);
    saveState();
    return;
  }

  alert("Please select a CSV or Excel (.xlsx) file");
});


/* =========================================================
   FIX MOJIBAKE — repairs double-encoded UTF-8 strings
   Happens when UTF-8 bytes were stored as Windows-1252 chars
   e.g. "Fatherâ€™s" → "Father's"
   e.g. "Government â€" State" → "Government – State"
   ========================================================= */
function fixMojibake(str) {
  if (typeof str !== "string") return str;
  // Only attempt fix if garbled chars are present
  if (!/[\u00c0-\u00ff]/.test(str)) return str;
  try {
    // Re-encode each char as cp1252 byte, then decode bytes as UTF-8
    const bytes = new Uint8Array(str.length);
    // cp1252 mapping for 0x80-0x9F range (differs from latin-1)
    const cp1252 = {
      0x80:0x20AC, 0x82:0x201A, 0x83:0x0192, 0x84:0x201E, 0x85:0x2026,
      0x86:0x2020, 0x87:0x2021, 0x88:0x02C6, 0x89:0x2030, 0x8A:0x0160,
      0x8B:0x2039, 0x8C:0x0152, 0x8E:0x017D, 0x91:0x2018, 0x92:0x2019,
      0x93:0x201C, 0x94:0x201D, 0x95:0x2022, 0x96:0x2013, 0x97:0x2014,
      0x98:0x02DC, 0x99:0x2122, 0x9A:0x0161, 0x9B:0x203A, 0x9C:0x0153,
      0x9E:0x017E, 0x9F:0x0178
    };
    // Reverse map: unicode → cp1252 byte
    const revCp1252 = {};
    for (const [b, u] of Object.entries(cp1252)) revCp1252[u] = parseInt(b);

    let valid = true;
    for (let i = 0; i < str.length; i++) {
      const cp = str.charCodeAt(i);
      if (cp < 0x80) {
        bytes[i] = cp;
      } else if (revCp1252[cp] !== undefined) {
        bytes[i] = revCp1252[cp];
      } else if (cp <= 0xFF) {
        bytes[i] = cp;
      } else {
        valid = false; break;
      }
    }
    if (!valid) return str;

    const decoded = new TextDecoder("utf-8").decode(bytes);
    // Only use fixed version if it looks better (fewer replacement chars)
    if (!decoded.includes("\uFFFD")) return decoded;
    return str;
  } catch(e) {
    return str;
  }
}

async function parseExcel(file) {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: "array" });

  const sheetName = workbook.SheetNames[0]; // first sheet
  const sheet = workbook.Sheets[sheetName];

  const rows = XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    blankrows: false
  });

  if (!rows || rows.length < 2) {
    alert("Excel must contain header and at least one row");
    return;
  }

  tableHeaders = rows[0].map(h => fixMojibake(String(h).trim()));
  tableRows = rows
  .slice(1)
  .filter(r => r.some(v => v !== undefined && v !== ""))
  .map(row => row.map(v => fixMojibake(excelDateToDDMMYYYY(v))));

  renderProfileList();
}


function parseCSV(text) {
  // Fix mojibake encoding before parsing
  text = fixMojibake(text);
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) {
    alert("CSV must contain header and at least one row");
    return;
  }

  tableHeaders = lines[0].split(",").map(h => h.trim());
  tableRows = lines
    .slice(1)
    .filter(l => l.trim())
    .map(l => l.split(",").map(v => v.trim()));

  renderProfileList();
}


  function getUsefulColumnIndexes(rows) {
  if (!rows.length) return [];

  const colCount = Math.max(...rows.map(r => r.length));
  const columns = [];

  for (let col = 0; col < colCount; col++) {
    const values = rows.map(r => (r[col] || "").trim());
    const nonEmpty = values.filter(Boolean);
    const unique = new Set(nonEmpty);

    columns.push({
      index: col,
      nonEmptyCount: nonEmpty.length,
      uniqueCount: unique.size
    });
  }

  // 🔥 PRIORITY SORT
  columns.sort((a, b) => {
    // 1️⃣ Prefer columns with multiple unique values
    if (b.uniqueCount !== a.uniqueCount) {
      return b.uniqueCount - a.uniqueCount;
    }
    // 2️⃣ Prefer columns with more data
    return b.nonEmptyCount - a.nonEmptyCount;
  });

  // ✅ pick top 3 meaningful columns
  return columns
    .filter(c => c.nonEmptyCount > 0)
    .slice(0, 3)
    .map(c => c.index);
}



function renderProfileList() {
  profileList.innerHTML = "";

  tableRows.forEach((row, rowIndex) => {
    const item = document.createElement("div");
    item.className = "profile-item";

    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "profile";

    const cols = document.createElement("div");
    cols.className = "profile-cols";

    // ✅ SHOW FIRST 3 NON-EMPTY COLUMNS ONLY
    let shown = 0;

     for (let i = 0; i < tableHeaders.length; i++) {
      const val = row[i];

      if (val === undefined || val === null || String(val).trim() === "") continue;

      if (shown > 0) {
        const sep = document.createElement("span");
        sep.className = "sep";
        sep.textContent = "|";
        cols.appendChild(sep);
      }

      const span = document.createElement("span");
      span.className = "col";
      span.textContent = String(val);
      cols.appendChild(span);

      shown++;
      if (shown === 3) break;
    }


    item.appendChild(radio);
    item.appendChild(cols);

    item.onclick = () => {
      selectedProfileIndex = rowIndex;

      profileList
        .querySelectorAll("input[type=radio]")
        .forEach(r => (r.checked = false));

      radio.checked = true;
      fillBtn.disabled = false;
      fillBtn.classList.add("active");
      fillBtn.textContent = "Fill";
      fillBtn.classList.remove("fill-running");
      fillBtn.style.background = "";

      // ── Show selected row data in textarea ──
      const rowData = tableHeaders
        .map((header, i) => {
          const val = row[i];
          if (val === undefined || val === null || String(val).trim() === "") return null;
          return `${header}, ${val}`;
        })
        .filter(Boolean)
        .join("\n");

      if (rowData) {
        _suppressDraftSave = true;
        pasteBox.value = rowData;
        updateUI();
        setTimeout(() => { _suppressDraftSave = false; }, 0);
      }

      saveState();
    };

    profileList.appendChild(item);
  });

  tableProfiles.classList.remove("hidden");
}



   /* ================= MODE SWITCH ================= */

tableModeRadio?.addEventListener("change", () => {
  if (tableModeRadio.checked) {
    // 🔥 CLEAR old radio selection
    selectedProfileIndex = null;
    profileList
      ?.querySelectorAll("input[type=radio]")
      .forEach(r => (r.checked = false));
    if (tableRows.length) tableProfiles.classList.remove("hidden");
  } else {
    tableProfiles.classList.add("hidden");
  }
  saveState();
});

  document.querySelectorAll('input[name="mode"]').forEach(radio => {
    radio.addEventListener("change", () => {
      saveState();
    });
  });



  /* ================= PARSER ================= */

const KNOWN_COMMANDS = [
  "fill", "section", "click", "add", "next", "submit", "back",
  "wait", "waitpage", "waitcalendar", "icon", "upload", "row", "select", "date",
  "pickslot", "anysite", "scroll", "press", "hover", "goto", "type", "checkall", "if"
];

function parseWorkflow(text) {
  const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
  const commands = [];

  for (const line of lines) {
    if (line === "---" || line === "===") break;

    // 🔥 Auto-fix "wait200" → "wait 200" (missing space)
    let normalized = line.replace(/^(wait)(\d+)$/i, "$1 $2");

    // 🔥 Handle lines like "after payment page  click saved 2nd"
    // Find if a known command appears ANYWHERE in the line
    const words = normalized.split(/\s+/);
    const cmdIndex = words.findIndex(w => KNOWN_COMMANDS.includes(w.toLowerCase()));

    if (cmdIndex === -1) continue;  // no known command found in this line

    // Re-parse from the command word onward
    const cmdLower = words[cmdIndex].toLowerCase();
    const value = words.slice(cmdIndex + 1).join(" ").trim();

    if (cmdLower === "row") {
      commands.push({
        type: "row",
        value: parseRowValue(value)
      });
    } else {
      commands.push({ type: cmdLower, value });
    }
  }

  return commands;
}


function parseRowValue(text) {
  // row 1
  if (/^\d+$/.test(text)) {
    const idx = parseInt(text, 10) - 1;
    return { start: idx, end: idx };
  }

  // row 1-5
  const m = text.match(/^(\d+)\s*-\s*(\d+)$/);
  if (m) {
    return {
      start: parseInt(m[1], 10) - 1,
      end: parseInt(m[2], 10) - 1
    };
  }

  console.warn("❌ Invalid row command:", text);
  return null;
}



  function parseValues(text) {
  const lines = text
    .split("\n")
    .map(l => l.trim())
    .filter(Boolean);

  const values = [];
  let detectedLabelMode = false;

  for (const line of lines) {

    if (line.toLowerCase() === "fill") continue;
    if (line === "---") continue;

    // 🔥 Detect label,value format
    if (line.includes(",")) {
      const parts = line.split(",");
      if (parts.length >= 2) {
        detectedLabelMode = true;

        values.push({
          label: parts[0].trim(),
          value: parts.slice(1).join(",").trim()
        });

        continue;
      }
    }

    // 🔹 Pure value mode
    values.push(line.trim());
  }

  return values;
}



  function parseWithRepeat(text) {
      const cleaned = text.trim();

      // ✅ If user pasted ONLY data (no ---)
      if (!cleaned.includes("\n---\n")) {
        return [parseValues(cleaned)];
      }

      // ✅ If workflow style with multiple groups
      return cleaned.split("\n---\n").map(parseValues);
    }


    /* ================= UI ================= */

  function updateUI() {
    const text = (pasteBox.value || "").trim();
    const hasText = text.length > 0;

    fillBtn.disabled = !hasText && !tableModeRadio.checked;
    fillBtn.classList.toggle("active", !fillBtn.disabled);

    if (!hasText) {
      counter.textContent = "0 detected";
      return;
    }

    counter.textContent = `${parseValues(text).length} fields detected`;
  }

  ["input", "keyup", "paste"].forEach(evt => {
    pasteBox.addEventListener(evt, () => {
      setTimeout(() => {
        updateUI();
        saveState();
        autoSaveCurrentText(); // save draft only, never auto-adds profile
      }, 0);
    });
  });








function showFlashMessage(lines, duration = 3000) {
  let flash = document.getElementById("autoFillFlash");

  if (!flash) {
    flash = document.createElement("div");
    flash.id = "autoFillFlash";

    flash.style.cssText = `
    position: fixed;
    bottom: 15px;
    left: 50%;
    transform: translateX(-50%);
    background: #1e1e1e;
    color: #fff;
    padding: 12px 16px;
    border-radius: 12px;
    font-size: 12px;
    font-family: system-ui, sans-serif;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 9999;
    text-align: left;
    line-height: 1.5;
    white-space: pre;
  `;

    document.body.appendChild(flash);
  }

  flash.textContent = Array.isArray(lines)
    ? lines.join("\n")
    : lines;

  flash.style.opacity = "1";

  setTimeout(() => {
    flash.style.opacity = "0";
  }, duration);
}





  function resolveCommandValue(value, row, headers) {
  return value.replace(/\{\{(.+?)\}\}/g, (_, key) => {
    const idx = headers.indexOf(key.trim());
    return idx >= 0 ? row[idx] : "";
  });
}



    // Split one block (no === inside) into workflow + data
    function splitOneBlock(blockText) {
      const parts = blockText.split(/\r?\n\s*---\s*\r?\n/);
      return {
        workflowText: parts[0]?.trim() || "",
        dataText: parts.slice(1).join("\n---\n").trim()
      };
    }

    // Split full text into multiple page blocks by ===
    function splitWorkflowAndData(text) {
      const pageBlocks = text.split(/\r?\n\s*===\s*\r?\n/);
      return pageBlocks.map(b => splitOneBlock(b.trim()));
    }

    /* ================= ACTION LOG (main panel) =================
       content.js writes chrome.storage.local.actionLog; this only reads and shows it. */
    const logList     = document.getElementById("logList");
    const clearLogBtn = document.getElementById("clearLogBtn");

    function escLog(str) {
      return String(str ?? "").replace(/[&<>"']/g, c =>
        ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    }

    function describeLogEntry(e) {
      const reasons = {
        not_found:      "button not found",
        disabled:       "button disabled",
        no_page_change: "no page change",
        no_option:      "no matching option",
        unparsed:       "could not read it",
        no_slot_in_range: "no slot in that time range",
        no_calendar:    "calendar not found on page",
        no_day_cells:   "day not found on calendar",
        no_available:   "no available date",
        day_disabled:   "day looks unavailable"
      };
      if (e.type === "manual_edit") return `manual edit: ${e.value}`;
      if (e.type === "refill")      return e.note || "re-fill";
      const what = [e.type, e.value].filter(Boolean).join(" ");
      return e.status === "failed" ? `${what} — ${reasons[e.reason] || e.reason || "failed"}` : what;
    }

    function renderActionLog() {
      if (!logList) return;
      chrome.storage.local.get("actionLog", (res) => {
        const log = res?.actionLog || [];
        if (!log.length) {
          logList.innerHTML = '<div class="log-empty">No actions logged yet</div>';
          return;
        }
        logList.innerHTML = [...log].reverse().slice(0, 20).map(e => {
          let icon = "ℹ️", cls = "log-info";
          if (e.status === "success")       { icon = "✅"; cls = "log-ok"; }
          else if (e.status === "failed")   { icon = "❌"; cls = "log-fail"; }
          else if (e.type === "manual_edit"){ icon = "✏️"; }
          else if (e.type === "refill")     { icon = "🔁"; }
          const time = new Date(e.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
          const label = escLog(describeLogEntry(e));
          return `<div class="log-row" title="${escLog([e.detail, e.url].filter(Boolean).join("  |  "))}">
            <span>${icon}</span>
            <span class="log-label ${cls}">${label}</span>
            <span class="log-time">${time}</span>
          </div>`;
        }).join("");
      });
    }

    clearLogBtn?.addEventListener("click", () => {
      chrome.storage.local.remove("actionLog", () => showFlashMessage("🗑 Log cleared"));
    });

    // Live refresh — content.js writing to storage is enough, no messaging needed
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.actionLog) renderActionLog();
    });

    renderActionLog();

    /* ================= SCHEDULED START =================
       Pick a clock time. While "⏰ Start at" is ticked the main button SCHEDULES instead of running
       now: the page itself holds the timer (so it keeps working after this popup closes) and starts
       the workflow at that moment. Needs the tab to stay open — and visible if you need second-exact
       starts, because Chrome slows timers in hidden tabs. */
    const SCHEDULE_MIN = "00:00";   // earliest start time you can pick
    const SCHEDULE_MAX = "23:59";   // latest start time you can pick

    const scheduleToggle = document.getElementById("scheduleToggle");
    const scheduleTime   = document.getElementById("scheduleTime");
    const scheduleStatus = document.getElementById("scheduleStatus");
    const scheduleCancel = document.getElementById("scheduleCancel");
    let scheduleRunAt = null;
    let scheduleTicker = null;

    if (scheduleTime) { scheduleTime.min = SCHEDULE_MIN; scheduleTime.max = SCHEDULE_MAX; }

    const timeToSeconds = (t) => {
      const [h = 0, m = 0, s = 0] = String(t).split(":").map(Number);
      return h * 3600 + m * 60 + s;
    };

    // "HH:MM[:SS]" → today's epoch ms, or { error }
    function computeRunAt(timeStr, nowMs = Date.now()) {
      if (!timeStr) return { error: "Pick a start time first" };
      const sec = timeToSeconds(timeStr);
      if (sec < timeToSeconds(SCHEDULE_MIN) || sec > timeToSeconds(SCHEDULE_MAX)) {
        return { error: `Start time must be between ${SCHEDULE_MIN} and ${SCHEDULE_MAX}` };
      }
      const now = new Date(nowMs);
      const [h = 0, m = 0, s = 0] = String(timeStr).split(":").map(Number);
      const runAt = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m, s).getTime();
      if (runAt <= nowMs) return { error: "That time has already passed today" };
      return { runAt };
    }

    // null → run now · false → invalid (message shown) · number → schedule for that moment
    function getScheduledRunAt() {
      if (!scheduleToggle?.checked) return null;
      const res = computeRunAt(scheduleTime?.value);
      if (res.error) { showFlashMessage("⚠️ " + res.error); return false; }
      return res.runAt;
    }

    function formatCountdown(ms) {
      const total = Math.max(0, Math.ceil(ms / 1000));
      const h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), s = total % 60;
      if (h) return `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
      if (m) return `${m}m ${String(s).padStart(2, "0")}s`;
      return `${s}s`;
    }

    function renderScheduleStatus() {
      if (!scheduleStatus) return;
      const left = scheduleRunAt ? scheduleRunAt - Date.now() : 0;
      if (scheduleRunAt && left > 0) {
        const at = new Date(scheduleRunAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        scheduleStatus.textContent = `⏰ Starts at ${at} — in ${formatCountdown(left)}`;
        scheduleCancel.style.display = "";
      } else {
        if (scheduleRunAt) scheduleStatus.textContent = "▶ Started";   // it fired while the popup was open
        else scheduleStatus.textContent = "";
        scheduleCancel.style.display = "none";
        scheduleRunAt = null;
        clearInterval(scheduleTicker); scheduleTicker = null;
      }
    }

    function onScheduled(runAt) {
      scheduleRunAt = runAt;
      renderScheduleStatus();
      clearInterval(scheduleTicker);
      scheduleTicker = setInterval(renderScheduleStatus, 250);
      showFlashMessage(`⏰ Scheduled — keep this tab open`);
    }

    function updateFillLabel() {
      if (fillBtn) fillBtn.textContent = scheduleToggle?.checked ? "⏰ Schedule" : "Fill";
      if (scheduleTime) scheduleTime.disabled = !scheduleToggle?.checked;
    }

    function saveScheduleSettings() {
      chrome.storage.local.set({ scheduleSettings: { enabled: !!scheduleToggle?.checked, time: scheduleTime?.value || "" } });
    }

    scheduleToggle?.addEventListener("change", () => { updateFillLabel(); saveScheduleSettings(); });
    scheduleTime?.addEventListener("change", saveScheduleSettings);

    scheduleCancel?.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "SCHEDULE_CANCEL" }, () => void chrome.runtime.lastError);
      if (tab?.id) chrome.runtime.sendMessage({ type: "OM_TTD_FORGET_SCHEDULE", tabId: tab.id }, () => void chrome.runtime.lastError);   // OM TTD add-on
      scheduleRunAt = null;
      renderScheduleStatus();
      showFlashMessage("⏰ Schedule cancelled");
    });

    // Restore the last choice, then ask the page whether a schedule is still armed
    chrome.storage.local.get("scheduleSettings", (res) => {
      const s = res?.scheduleSettings;
      if (s) {
        if (s.time && scheduleTime) scheduleTime.value = s.time;
        if (scheduleToggle) scheduleToggle.checked = !!s.enabled;
      }
      updateFillLabel();
    });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const id = tabs?.[0]?.id;
      if (!id) return;
      chrome.tabs.sendMessage(id, { type: "SCHEDULE_STATUS" }, (resp) => {
        if (chrome.runtime.lastError || !resp?.scheduled) return;
        onScheduledSilently(resp.runAt);
      });
    });
    function onScheduledSilently(runAt) {
      scheduleRunAt = runAt;
      renderScheduleStatus();
      clearInterval(scheduleTicker);
      scheduleTicker = setInterval(renderScheduleStatus, 250);
    }

    /* ================= FILL ================= */

// ── API Log button ──
document.getElementById("apiLogBtn")?.addEventListener("click", async () => {
  let tab; try { tab = await ttdTab(); } catch (e) { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); }   // OM capture fix: TTD tab, not the popup tab
  if (!tab) return;
  // Must run in MAIN world to access page's window.__OM_API_LOG
  const result = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => {
      const log = window.__OM_API_LOG || [];
      return JSON.stringify(log);
    }
  });
  const raw = result?.[0]?.result || "[]";
  const log = JSON.parse(raw);
  if (!log.length) {
    alert("No API calls captured yet.\n\nStep 1: Make sure you are on the TTD website\nStep 2: Do a complete manual booking\nStep 3: Click this button after Confirm");
    return;
  }
  const blob = new Blob([JSON.stringify(log, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "ttd-api-log.json"; a.click();
  URL.revokeObjectURL(url);
  alert("Downloaded ttd-api-log.json\n" + log.length + " API calls captured.");
});

document.getElementById("apiClearBtn")?.addEventListener("click", async () => {
  let tab; try { tab = await ttdTab(); } catch (e) { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); }   // OM capture fix
  if (!tab) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => { if (window.__OM_API_LOG_CLEAR) window.__OM_API_LOG_CLEAR(); else window.__OM_API_LOG = []; console.log("[OM-API] Log cleared"); }
  });
  alert("API log cleared.");
});

// ── Direct Book ──
document.getElementById("directBookBtn")?.addEventListener("click", () => {
  document.getElementById("directBookPanel").style.display = "block";
  document.getElementById("db_status").style.display = "none";
});
document.getElementById("db_cancelBtn")?.addEventListener("click", () => {
  document.getElementById("directBookPanel").style.display = "none";
});
// Old ttd-direct-book.js flow (stale add_sevak payload → "Master Sevak id required"). Kept but no longer wired.   // OM TTD console
document.getElementById("db_fireBtn_legacy")?.addEventListener("click", async () => {
  const sevaTypeId = parseInt(document.getElementById("db_sevaTypeId").value);
  const sevaDate = document.getElementById("db_sevaDate").value.trim().replace(/\D/g, "");
  const bookingType = document.getElementById("db_bookingType").value;
  const noOfPilgrim = parseInt(document.getElementById("db_pilgrim").value) || 1;

  if (!sevaTypeId || !sevaDate || sevaDate.length !== 8) {
    alert("Please enter valid Seva Type ID and Date (YYYYMMDD)");
    return;
  }

  const statusEl = document.getElementById("db_status");
  const fireBtn = document.getElementById("db_fireBtn");
  statusEl.style.display = "block";
  statusEl.style.color = "#cba6f7";
  statusEl.textContent = "⏳ Booking in progress...";
  fireBtn.disabled = true;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url?.includes("ttdevasthanams.ap.gov.in")) {
    statusEl.style.color = "#f38ba8";
    statusEl.textContent = "❌ Please navigate to the TTD website first and login";
    fireBtn.disabled = false;
    return;
  }
  if (/curtain/i.test(tab.url)) { statusEl.style.color = "#f9e2af"; statusEl.textContent = "⏳ Still on the curtain / queue page — wait until it lets you through"; fireBtn.disabled = false; return; }   // OM TTD console

  const t0 = Date.now();
  const result = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: async (cfg) => {
      return await window.__TTD_DIRECT_BOOK(cfg);
    },
    args: [{ sevaTypeId, sevaDate, bookingType, noOfPilgrim }]
  });

  const res = result?.[0]?.result;
  const elapsed = ((Date.now() - t0) / 1000).toFixed(2);
  fireBtn.disabled = false;

  if (res?.status === "success") {
    statusEl.style.color = "#a6e3a1";
    statusEl.textContent = `✅ BOOKED in ${elapsed}s!
Ticket ID: ${res.ticketId}
Sevak ID: ${res.sevakId}`;
  } else {
    statusEl.style.color = "#f38ba8";
    statusEl.textContent = `❌ Failed (${elapsed}s)
${res?.error || JSON.stringify(res)}`;
  }
});

// ── TTD console: popup buttons → window.TTD (ttd-console.js v10, MAIN world) ──   // OM TTD console
// v10 methods read their settings from TTD.config(), take no arguments and report via console.log,
// so each call pushes the popup fields into TTD.config() and captures the console output for the status box.
const TTD_METHODS = { book: "book", check: "check", watch: "watch", stop: "stop", remove: "remove", members: "members" };
let ttdSelected = null;   // seva picked in the list (gives sevaName + remarks for slots)

// Find the TTD tab itself (in Kiwi the popup opens as its own tab, so "active tab" isn't reliable)
async function ttdTab() {
  const tabs = await chrome.tabs.query({ url: ["https://ttdevasthanams.ap.gov.in/*", "http://ttdevasthanams.ap.gov.in/*"] });
  if (!tabs.length) throw new Error("Open the TTD website first and log in");
  const tab = tabs.find(t => t.active) || tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  if (/curtain/i.test(tab.url)) throw new Error("Still on the curtain / queue page — wait until it lets you through");
  if (tab.discarded) throw new Error("The browser unloaded the TTD tab — open it, let the page load, then come back");
  return tab;
}

// executeScript with one retry; clear message when the TTD tab can't be reached (unloaded, reloading, error page)
async function ttdExecute(tab, opts) {
  try { return await chrome.scripting.executeScript(opts); }
  catch (e) {
    if (!/cannot access|cannot be scripted|no frame|frame with id|error page|was removed|not ready/i.test(e.message)) throw e;
    await new Promise(r => setTimeout(r, 800));
    let t = null; try { t = await chrome.tabs.get(tab.id); } catch (_) {}
    if (t && !t.discarded && t.status === "complete" && /ttdevasthanams\.ap\.gov\.in/.test(t.url || "") && !/curtain/i.test(t.url)) {
      try { return await chrome.scripting.executeScript(opts); } catch (_) {}
    }
    const why = !t ? "tab closed" : t.discarded ? "unloaded by the browser" : t.status !== "complete" ? "still loading" : "page not ready / error page";
    throw new Error(`TTD tab not reachable (${why}). Open the TTD tab, wait until the page shows, then try again.`);
  }
}

const ttdChecked = (id) => !!document.getElementById(id)?.checked;

// Popup fields → ttd-console.js CONFIG keys
function ttdCfg() {
  const bookingType = document.getElementById("db_bookingType").value;
  const sevaDate = document.getElementById("db_sevaDate").value.trim().replace(/\D/g, "");
  const sevaTypeId = parseInt(document.getElementById("db_sevaTypeId").value) || null;
  const c = {
    bookingType,
    noOfPilgrim: parseInt(document.getElementById("db_pilgrim").value) || 1,
    dryRun: ttdChecked("ttd_dryRun"),
    autoBook: ttdChecked("ttd_autoBook")
  };
  if (sevaDate.length === 8) c.sevaDate = sevaDate;
  if (sevaTypeId) c.sevaTypeId = sevaTypeId;
  if (ttdSelected) { c.sevaName = ttdSelected.name; c.remarks = ttdSelected.remarks || ""; }
  if (bookingType === "GROUP") {
    c.members = (document.getElementById("ttd_members")?.value || "").split(/[,\n]/).map(x => x.trim()).filter(Boolean);
    c.leader = document.getElementById("ttd_leader")?.value.trim() || null;
  } else { c.members = []; c.leader = null; }
  return c;
}

function ttdStatus(text, color) {
  const el = document.getElementById("db_status");
  el.style.display = "block";
  el.style.color = color || "#cba6f7";
  el.textContent = text;
}

async function callTTD(key, cfg) {
  const tab = await ttdTab();
  const [r] = await ttdExecute(tab, {
    target: { tabId: tab.id },
    world: "MAIN",
    func: async (method, cfg) => {
      const T = window.TTD;
      if (!T) return { __err: "window.TTD not found — reload the TTD tab (ttd-console.js loads with the page)" };
      if (typeof T[method] !== "function") return { __err: `TTD.${method} not found. Available: ${Object.keys(T).join(", ")}` };
      // Not logged in → stop here (v10 reads authtoken / user_id from these cookies)
      if (method !== "stop") {
        const ck = {};
        document.cookie.split(";").forEach(c => { const i = c.indexOf("="); if (i > 0) ck[c.slice(0, i).trim()] = c.slice(i + 1); });
        if (!ck.authtoken || !ck.user_id) return { __err: "🔒 Not logged in to TTD — log in on the TTD tab first, then try again" };
      }
      if (cfg && T.cfg) Object.assign(T.cfg, cfg);          // same as TTD.config(), without the log line
      const lines = [], orig = {};
      const fmt = (a) => {
        a = a.slice();
        if (typeof a[0] === "string" && a[0].includes("%c")) { const n = (a[0].match(/%c/g) || []).length; a[0] = a[0].replace(/%c/g, "").trim(); a.splice(1, n); }
        return a.map(x => typeof x === "string" ? x : (() => { try { return JSON.stringify(x); } catch (e) { return String(x); } })()).join(" ");
      };
      ["log", "warn", "error"].forEach(k => { orig[k] = console[k]; console[k] = (...a) => { lines.push(fmt(a)); orig[k].apply(console, a); }; });
      const origAlert = window.alert;                     // v10 alerts would freeze the background TTD tab — show them here instead
      window.alert = (m) => lines.push("🔔 " + m);
      try {
        const v = await T[method]();
        let out = null; try { out = v === undefined ? null : JSON.parse(JSON.stringify(v)); } catch (e) {}
        return { __ok: out, logs: lines };
      } catch (e) {
        return { __err: e?.message === "SESSION_EXPIRED" ? "🔒 TTD session expired — log in again" : (e?.message || String(e)), logs: lines };
      } finally { Object.assign(console, orig); window.alert = origAlert; }
    },
    args: [TTD_METHODS[key], cfg]
  });
  return r?.result || { __err: "no result from page" };
}

// BOOK NOW → ttd-console.js v10 book() (verified flow), same as the console Book button   // OM TTD console
document.getElementById("db_fireBtn")?.addEventListener("click", () => document.getElementById("ttd_book")?.click());

function ttdSyncLabels() {
  const group = document.getElementById("db_bookingType")?.value === "GROUP";
  const gf = document.getElementById("ttd_groupFields"); if (gf) gf.style.display = group ? "block" : "none";
  const b = document.getElementById("ttd_book"); if (b) b.textContent = ttdChecked("ttd_dryRun") ? "Book (dry run)" : "Book (REAL)";
  const f = document.getElementById("db_fireBtn"); if (f) f.textContent = ttdChecked("ttd_dryRun") ? "🧪 BOOK NOW (dry run)" : "🚀 BOOK NOW (REAL)";
}
document.getElementById("ttd_dryRun")?.addEventListener("change", ttdSyncLabels);
document.getElementById("db_bookingType")?.addEventListener("change", ttdSyncLabels);
ttdSyncLabels();

[["ttd_book", "book"], ["ttd_check", "check"], ["ttd_watch", "watch"],
 ["ttd_stop", "stop"], ["ttd_remove", "remove"], ["ttd_members", "members"]].forEach(([id, key]) => {
  document.getElementById(id)?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    const cfg = ["book", "check", "watch"].includes(key) ? ttdCfg() : null;
    if (key === "book" && !cfg.sevaDate) { ttdStatus("❌ Pick a date first (tap a date chip or type YYYYMMDD)", "#f38ba8"); return; }
    if (key === "remove" && !confirm("Remove ALL sevaks from your OPEN (unconfirmed) ticket?\nConfirmed bookings are never touched.")) return;
    if (key !== "stop") btn.disabled = true;          // Stop always stays clickable
    const note = cfg && !cfg.sevaName ? "\n(no seva picked from TTD list — script default seva is used)" : "";
    ttdStatus(`⏳ ${key}…${note}`);
    const t0 = Date.now();
    try {
      const res = await callTTD(key, cfg);
      const secs = ((Date.now() - t0) / 1000).toFixed(2);
      const logs = (res.logs || []).join("\n");
      const ret = res.__ok == null ? "" : "\n" + JSON.stringify(res.__ok, null, 1);
      const failed = res.__err || /❌|session expired/i.test(logs);
      const head = res.__err ? `❌ ${key} (${secs}s) — ${res.__err}` : `${failed ? "❌" : "✅"} ${key} (${secs}s)`;
      ttdStatus(`${head}${note}\n${logs}${ret}`.slice(0, 6000), failed ? "#f38ba8" : "#a6e3a1");
    } catch (err) {
      ttdStatus(`❌ ${key} — ${err.message}`, "#f38ba8");
    } finally { btn.disabled = false; }
  });
});

// ── Direct Book: seva list from TTD site data + available dates ──   // OM TTD picker
// The list comes from what the TTD site itself requested (window.__OM_API_LOG, recorded by api-capture.js):
// every /slot/get_availability call carries the exact sevaType / sevaName / remarks the site uses.
// Seen sevas are remembered in chrome.storage.local, so the list survives page reloads.
const TTD_CACHE_KEY = "omTtdSevas";
let ttdTypeItems = [];

// GET on the TTD API from inside the page, reusing the headers the site itself last sent
async function ttdPageGet(path) {
  const tab = await ttdTab();
  const [r] = await ttdExecute(tab, {
    target: { tabId: tab.id }, world: "MAIN",
    func: async (path) => {
      const ck = {};
      document.cookie.split(";").forEach(c => { const i = c.indexOf("="); if (i > 0) { try { ck[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1)); } catch (e) {} } });
      const headers = { "Content-Type": "application/json", Accept: "application/json", Authtoken: ck.authtoken || "", Userid: ck.user_id || "" };
      const site = (window.__OM_API_LOG || []).filter(x => x.status === 200 && /\/api\//.test(x.url) && x.reqHeaders && Object.keys(x.reqHeaders).some(k => /auth|token|user/i.test(k))).pop();
      if (site) Object.assign(headers, site.reqHeaders);
      try {
        const res = await fetch("https://ttdevasthanams.ap.gov.in/api/sed/v1/seva" + path, { headers, credentials: "include" });
        const text = await res.text();
        try { return { ok: res.ok, status: res.status, json: JSON.parse(text) }; }
        catch (e) { return { ok: false, status: res.status, text: text.slice(0, 300) }; }
      } catch (e) { return { ok: false, error: e.message }; }
    },
    args: [path]
  });
  return r?.result || { ok: false, error: "no result" };
}

// Read what the TTD site requested on this page
async function ttdReadSiteLog() {
  const tab = await ttdTab();
  const [r] = await ttdExecute(tab, {
    target: { tabId: tab.id }, world: "MAIN",
    func: () => (window.__OM_API_LOG || []).filter(x => /\/api\//.test(x.url)).map(x => ({ url: x.url, status: x.status, response: x.response }))
  });
  return r?.result || [];
}

function ttdWalk(x, out = []) {
  if (Array.isArray(x)) x.forEach(v => ttdWalk(v, out));
  else if (x && typeof x === "object") { out.push(x); Object.values(x).forEach(v => { if (v && typeof v === "object") ttdWalk(v, out); }); }
  return out;
}
const ttdPick = (o, re) => { const k = Object.keys(o).find(k => re.test(k) && o[k] != null && typeof o[k] !== "object" && o[k] !== ""); return k ? o[k] : undefined; };

function ttdDate8(v) {
  if (v == null) return null;
  if (typeof v === "number" && v > 1e11) { const d = new Date(v); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`; }
  const s = String(v).trim(); let m;
  if (/^\d{8}$/.test(s)) return s;
  if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return m[1] + m[2] + m[3];
  if ((m = s.match(/^(\d{2})[-\/](\d{2})[-\/](\d{4})$/))) return m[3] + m[2] + m[1];
  return null;
}

// Sevas the site asked about: from /slot/get_availability URLs, plus any sevaName/remarks objects in replies
function ttdSevasFromLog(log) {
  const found = [];
  for (const x of log) {
    let u; try { u = new URL(x.url); } catch (e) { continue; }
    if (/\/slot\/get_availability/.test(u.pathname) && u.searchParams.get("sevaName")) {
      let json = null; try { json = JSON.parse(x.response); } catch (e) {}
      found.push({ name: u.searchParams.get("sevaName"), remarks: u.searchParams.get("remarks") || "",
                   sevaType: u.searchParams.get("sevaType") || "", lastReply: json && x.status === 200 ? json : null });
      continue;
    }
    if (/master_sevaks|get_by_user_id/.test(u.pathname)) continue;   // pilgrim data, not sevas
    let json = null; try { json = JSON.parse(x.response); } catch (e) { continue; }
    for (const o of ttdWalk(json)) {
      const name = o.sevaName ?? o.seva_name;
      if (name && typeof name === "string") found.push({ name, remarks: typeof o.remarks === "string" ? o.remarks : "", sevaType: o.sevaType || o.bookingType || "" });
    }
  }
  return found;
}

const ttdKey = (it) => `${it.name}|${it.remarks}|${it.sevaType}`;

async function ttdMergeCache(found) {
  const store = (await chrome.storage.local.get(TTD_CACHE_KEY))?.[TTD_CACHE_KEY] || [];
  const map = new Map(store.map(it => [ttdKey(it), it]));
  for (const it of found) map.set(ttdKey(it), { name: it.name, remarks: it.remarks, sevaType: it.sevaType, seen: Date.now() });
  const list = [...map.values()].sort((a, b) => b.seen - a.seen).slice(0, 60);
  await chrome.storage.local.set({ [TTD_CACHE_KEY]: list });
  return list;
}

function ttdParseDates(json) {
  // v10 / site shape: result.totalDateSlots[YYYYMMDD] = { avl, slots: { <sevaTypeId>: … } }
  const tds = json?.result?.totalDateSlots;
  if (tds && typeof tds === "object") {
    return Object.entries(tds).map(([d, v]) => ({
      date: ttdDate8(d) || d, left: v?.avl, status: null,
      id: (() => { const k = Object.keys(v?.slots || {})[0]; return k != null ? Number(k) : null; })()
    })).filter(x => /^\d{8}$/.test(x.date)).sort((a, b) => a.date.localeCompare(b.date));
  }
  const seen = new Set(), out = [];
  const add = (date, o = {}) => {
    const id = o.id ?? ttdPick(o, /seva_?type|type_?id/i) ?? null;
    const left = ttdPick(o, /avail|remaining|balance|quota|count|capacity|vacan/i);
    const status = ttdPick(o, /status/i);
    const key = date + "|" + id; if (seen.has(key)) return; seen.add(key);
    out.push({ date, id, left, status });
  };
  for (const o of ttdWalk(json)) {
    for (const [k, v] of Object.entries(o)) {
      if (/date/i.test(k)) { const d = ttdDate8(v); if (d) add(d, o); }
      else { const d = ttdDate8(k); if (d && /^\d{4}-?\d{2}-?\d{2}$/.test(k)) add(d, v && typeof v === "object" ? v : { count: v }); }
    }
  }
  return out.sort((a, b) => a.date.localeCompare(b.date));
}

const ttdLabel = (it) => `${it.name}${it.remarks ? " — " + it.remarks : ""}`;

function ttdSetHint(text, color) { const el = document.getElementById("db_typeHint"); if (el) { el.textContent = text; el.style.color = color || "#6c7086"; } }

function ttdFillSelect(items, note) {
  const sel = document.getElementById("db_sevaTypeSelect");
  if (!sel) return;
  ttdTypeItems = items;
  sel.innerHTML = "";
  sel.add(new Option(note, ""));
  items.forEach((it, i) => sel.add(new Option(ttdLabel(it), String(i))));
}

let ttdLastReplies = new Map();   // key → availability reply the site already received
async function ttdLoadTypes() {
  const bt = document.getElementById("db_bookingType").value;
  ttdFillSelect([], "Loading from TTD…");
  let found = [], live = [], err = "";
  try {
    const log = await ttdReadSiteLog();
    found = ttdSevasFromLog(log);
    ttdLastReplies = new Map(found.filter(f => f.lastReply).map(f => [ttdKey(f), f.lastReply]));
    const r = await ttdPageGet(`/get_seva_name?sevaType=${encodeURIComponent(bt)}`);   // bonus source, fine if it fails
    if (r.ok) live = ttdSevasFromLog([{ url: "https://x/api/seva_name", status: 200, response: JSON.stringify(r.json) }]).map(it => ({ ...it, sevaType: it.sevaType || bt }));
    else if (r.status === 401) err = "TTD said 401 — if dates also fail, log in to TTD again";
  } catch (e) { err = e.message; }
  let list = [];
  try { list = await ttdMergeCache([...found, ...live]); } catch (e) { list = [...found, ...live]; }
  const forType = list.filter(it => !it.sevaType || it.sevaType === bt);
  if (forType.length) {
    ttdFillSelect(forType, `— pick a seva (${forType.length} from TTD site) —`);
    ttdSetHint("Pick a seva to see its available dates");
  } else {
    ttdFillSelect([], "— no sevas seen yet —");
    ttdSetHint((err ? err + ". " : "") + `On the TTD site, open ${bt === "GROUP" ? "a group" : "an individual"} seva and its date calendar once, then tap ↻`, "#f9e2af");
  }
}

function ttdRenderDates(it, json, live) {
  const box = document.getElementById("db_dates");
  const dates = ttdParseDates(json);
  box.innerHTML = "";
  if (!dates.length) {
    box.innerHTML = '<span style="color:#f9e2af;">No dates in TTD reply.</span>';
    const raw = document.createElement("div");
    raw.style.cssText = "flex-basis:100%;font-size:10px;color:#6c7086;word-break:break-all;";
    raw.textContent = JSON.stringify(json).slice(0, 300);
    box.appendChild(raw);
    return;
  }
  const open = dates.filter(d => d.left == null || Number(d.left) > 0);
  const tag = document.createElement("div");
  tag.style.cssText = "flex-basis:100%;font-size:11px;color:#6c7086;";
  tag.textContent = `${open.length} of ${dates.length} dates open · ${live ? "live" : "from the site's last check — refreshing…"}`;
  box.appendChild(tag);
  dates.forEach(d => {
    const b = document.createElement("button");
    const dt = new Date(+d.date.slice(0, 4), +d.date.slice(4, 6) - 1, +d.date.slice(6, 8));
    const full = d.left != null && Number(d.left) <= 0;
    b.textContent = `${dt.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })}${d.left != null ? " · " + d.left : ""}${d.id != null ? " · #" + d.id : ""}`;
    b.style.cssText = `padding:5px 8px;border:none;border-radius:999px;cursor:pointer;background:${full ? "#45475a" : "#313244"};color:${full ? "#6c7086" : "#a6e3a1"};`;
    if (document.getElementById("db_sevaDate").value === d.date) b.style.outline = "2px solid #a6e3a1";
    b.addEventListener("click", () => {
      document.getElementById("db_sevaDate").value = d.date;
      if (d.id != null) document.getElementById("db_sevaTypeId").value = d.id;
      ttdSetHint(`${ttdLabel(it)} · ${d.date} → seva type ${d.id ?? "?"}`, "#a6e3a1");
      box.querySelectorAll("button").forEach(x => x.style.outline = "");
      b.style.outline = "2px solid #a6e3a1";
    });
    box.appendChild(b);
  });
}

async function ttdLoadDates(it) {
  const box = document.getElementById("db_dates");
  if (!box) return;
  const cached = ttdLastReplies.get(ttdKey(it));
  if (cached) ttdRenderDates(it, cached, false);
  else box.innerHTML = '<span style="color:#6c7086;">Checking available dates…</span>';
  const bt = it.sevaType || document.getElementById("db_bookingType").value;
  try {
    const r = await ttdPageGet(`/slot/get_availability?sevaType=${encodeURIComponent(bt)}&sevaName=${encodeURIComponent(it.name)}&remarks=${encodeURIComponent(it.remarks || "")}`);
    if (!r.ok) throw new Error(r.status === 401 ? "HTTP 401 — TTD session expired, log in again" : (r.error || `HTTP ${r.status}`));
    ttdRenderDates(it, r.json, true);
  } catch (err) {
    if (cached) { const t = box.querySelector("div"); if (t) { t.textContent = "Live check failed (" + err.message + ") — showing the site's last check"; t.style.color = "#f9e2af"; } return; }
    box.innerHTML = "";
    const s = document.createElement("span"); s.style.color = "#f38ba8"; s.textContent = "Dates: " + err.message; box.appendChild(s);
  }
}

document.getElementById("db_sevaTypeSelect")?.addEventListener("change", (e) => {
  const it = ttdTypeItems[+e.target.value];
  if (!e.target.value || !it) { ttdSelected = null; return; }
  ttdSelected = it;
  ttdSetHint(ttdLabel(it) + " — tap a date", "#a6e3a1");
  ttdLoadDates(it);
});
document.getElementById("db_bookingType")?.addEventListener("change", () => { ttdSelected = null; document.getElementById("db_dates").innerHTML = ""; ttdLoadTypes(); });
document.getElementById("db_typesReload")?.addEventListener("click", () => { ttdLoadTypes(); if (ttdSelected) ttdLoadDates(ttdSelected); });
document.getElementById("directBookBtn")?.addEventListener("click", () => {
  document.body.classList.add("db-open");
  ttdLoadTypes();
});
document.getElementById("db_cancelBtn")?.addEventListener("click", () => document.body.classList.remove("db-open"));
// ── end OM TTD console ──

fillBtn?.addEventListener("click", async () => {
  if (fillBtn.disabled) return;

  // If fill is already running → stop it
  if (fillBtn.classList.contains("fill-running")) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => { window.__OM_FILL_STOP = true; }
      });
    });
    fillBtn.textContent = "Fill";
    fillBtn.classList.remove("fill-running");
    fillBtn.style.background = "";
    showFlashMessage("⏹ Fill stopped");
    return;
  }

  const repeat = repeatToggle?.checked || false;
  let rawText = pasteBox.value.trim();

  if (!rawText) return;

  // Mark as running → button becomes Stop
  fillBtn.textContent = "⏹ Stop";
  fillBtn.classList.add("fill-running");
  fillBtn.style.background = "#dc2626";

  /* =====================================================
     1️⃣ DETECT WORKFLOW STRUCTURE
  ===================================================== */

  const lines = rawText
    .split("\n")
    .map(l => l.trim())
    .filter(Boolean);

  const hasWorkflowCommand = lines.some(line =>
    /^(fill|section|click|submit|next|add|icon|upload|wait|waitpage|waitcalendar|row|back|select|date)\b/i.test(line)
  );

  const hasSeparator = rawText.includes("---");
  const hasPageBreak = rawText.includes("===");

  /* =====================================================
     2️⃣ AUTO FIX LOGIC
  ===================================================== */

  // CASE A: Pure data (no workflow commands, no page break)
  if (!hasWorkflowCommand && !hasPageBreak) {
    rawText = "fill\n\n---\n" + rawText;

    showFlashMessage([
      "🔥 Fill Command Auto Added",
      "🔥 --- Separator Auto Added"
    ]);
  }

  // CASE B: Workflow + Data mixed but no separator (single block only)
  else if (hasWorkflowCommand && !hasSeparator && !hasPageBreak) {

    const firstDataLineIndex = lines.findIndex(line =>
      line.includes(",") // label mode detection
    );

    if (firstDataLineIndex !== -1) {
      const workflowPart = lines.slice(0, firstDataLineIndex).join("\n");
      const dataPart = lines.slice(firstDataLineIndex).join("\n");
      rawText = workflowPart + "\n\n---\n" + dataPart;
    }
  }

  /* =====================================================
     3️⃣ SPLIT INTO PAGE BLOCKS (supports ===)
  ===================================================== */

  const pageBlocks = splitWorkflowAndData(rawText);

  /* =====================================================
     4️⃣ BUILD GROUPS FROM DATA (first block's data)
  ===================================================== */

  let groups;

  if (tableModeRadio.checked) {
    groups = tableRows.map(row =>
      horizontalToVertical(tableHeaders, row)
    );
  }
  else {
    const firstDataText = pageBlocks[0]?.dataText || "";
    if (!firstDataText.trim()) {
      groups = [[]];
    } else {
      groups = parseWithRepeat(firstDataText);
    }
  }

  /* =====================================================
     5️⃣ PARSE ALL BLOCKS INTO COMMAND SEGMENTS
  ===================================================== */

  // Each page block becomes a segment: { commands, groups }
  // First block uses the shared groups; later blocks parse their own data
  const segments = pageBlocks.map((block, blockIdx) => {
    let cmds = parseWorkflow(block.workflowText);

    if (tableModeRadio.checked && cmds.length === 0) {
      cmds = [{ type: "fill", value: "" }];
    }

    // Resolve {{placeholder}} for table mode
    const resolvedCmds = tableModeRadio.checked && groups.length > 0
      ? cmds.map(cmd => ({
          ...cmd,
          value: typeof cmd.value === "string"
            ? resolveCommandValue(cmd.value, groups[0], tableHeaders)
            : cmd.value
        }))
      : cmds;

    // Later blocks may have their own data
    let blockGroups = groups;
    if (blockIdx > 0 && block.dataText.trim()) {
      blockGroups = parseWithRepeat(block.dataText);
    }

    return { commands: resolvedCmds, groups: blockGroups };
  });

  /* =====================================================
     6️⃣ REPEAT SAFETY CHECK (first segment)
  ===================================================== */

  const firstCmds = segments[0]?.commands || [];
  if (
    tableModeRadio.checked &&
    repeat &&
    !firstCmds.some(c =>
      ["click", "add", "next", "submit", "continue", "save"].includes(c.type)
    )
  ) {
    alert(
      "Repeat mode needs Add / Save / Next / Continue to avoid overwriting the same form."
    );
    return;
  }

  /* =====================================================
     7️⃣ SEND TO CONTENT — multi-block aware
  ===================================================== */

  await sendToActiveTab({
    type: "RUN_WORKFLOW",
    segments,                          // 🔥 array of {commands, groups}
    // Legacy single-block fields (kept for backward compat)
    commands: segments[0]?.commands || [],
    groups,
    repeat,
    selectedRowIndex: tableModeRadio.checked ? selectedProfileIndex : null
  });

});



  /* ================= STATE ================= */

  function saveState() {
    chrome.storage.local.set({
      [STORAGE_KEY]: {
        pasteText: pasteBox.value,
        tableHeaders,
        tableRows,
        selectedProfileIndex,
        repeat: repeatToggle?.checked || false,
        fileName: fileNameSpan.textContent
      }
    });
  }


function loadImageLibraryFromStorage() {
  chrome.storage.local.get("imageLibrary", (res) => {
    selectedImages =
      res.imageLibrary && typeof res.imageLibrary === "object"
        ? res.imageLibrary
        : {};

    renderImageGrid();
    console.log("📂 Image library loaded", selectedImages);
  });
}
  

  function restoreState() {
    chrome.storage.local.get([STORAGE_KEY, "currentDraft"], res => {
      const s = res[STORAGE_KEY];
      if (!s) return;

      // currentDraft takes priority over stored pasteText
      if (!res.currentDraft) {
        pasteBox.value = s.pasteText || "";
      }

      tableHeaders = s.tableHeaders || [];
      tableRows = s.tableRows || [];
      selectedProfileIndex = s.selectedProfileIndex ?? null;

      fileNameSpan.textContent = s.fileName || "No file chosen";

      if (tableRows.length) renderProfileList();
      updateUI();
    });
  }

  restoreState();
  updateUI();

});




    document.getElementById("downloadTableSample")
      ?.addEventListener("click", async (e) => {
        e.stopPropagation(); // prevent radio toggle

        const defaultHeaders = [
          "Full Name",
          "Email",
          "Mobile",
          "City",
          "Gender"
        ];

        // fallback CSV (when no live form)
        const fallbackCSV = buildHorizontalCSV(defaultHeaders);

        const [tab] = await chrome.tabs.query({
          active: true,
          currentWindow: true
        });

        // ❌ No active tab → download default
        if (!tab?.id) {
          downloadCSV(fallbackCSV);
          return;
        }

        // ✅ Ask content.js for live form labels
        chrome.tabs.sendMessage(
          tab.id,
          { type: "GET_FIELD_LABELS" },
          (labels) => {
            // fallback if no response / no form
            if (
              chrome.runtime.lastError ||
              !Array.isArray(labels) ||
              labels.length === 0
            ) {
              downloadCSV(fallbackCSV);
              return;
            }

            // ✅ LIVE FORM → HORIZONTAL TABLE
            const csv = buildHorizontalCSV(labels);
            downloadCSV(csv);
          }
        );
      });


      function buildHorizontalCSV(headers) {
          const headerRow = headers.join(",");
          const emptyRow = headers.map(() => "").join(",");

          // 2 empty rows for user convenience
          return `${headerRow}\n${emptyRow}\n${emptyRow}`;
        }



      function downloadCSV(text) {
          const blob = new Blob([text], { type: "text/csv" });
          const url = URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = url;
          a.download = "table_sample.csv";
          document.body.appendChild(a);
          a.click();

          URL.revokeObjectURL(url);
          a.remove();
        }


        function downloadGeneratedFile(text) {
          const blob = new Blob([text], { type: "text/plain" });
          const url = URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = url;
          a.download = "generated_form.txt"; // 👈 vertical file
          document.body.appendChild(a);
          a.click();

          URL.revokeObjectURL(url);
          a.remove();
        }


        // tooltip removed — ? now opens externally
