// OM API Capture v2 — runs at document_start in MAIN world
// Intercepts ALL fetch/XHR before TTD page makes any calls

(function() {
  if (window.__OM_API_CAPTURE_ACTIVE) return;
  window.__OM_API_CAPTURE_ACTIVE = true;
  // Keep the log across page loads in this tab (sessionStorage), so a multi-page booking flow is captured whole   // OM capture fix
  const KEY = '__OM_API_LOG';
  try { window.__OM_API_LOG = JSON.parse(sessionStorage.getItem(KEY) || '[]'); } catch (e) { window.__OM_API_LOG = []; }
  let persistTimer = null;
  function persist() {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => {
      try {
        const keep = window.__OM_API_LOG.slice(-200).map(e => ({ ...e, response: e.response ? e.response.slice(0, 3000) : e.response }));
        sessionStorage.setItem(KEY, JSON.stringify(keep));
      } catch (e) {}
    }, 300);
  }
  window.addEventListener('pagehide', () => { clearTimeout(persistTimer); try { sessionStorage.setItem(KEY, JSON.stringify(window.__OM_API_LOG.slice(-200))); } catch (e) {} });
  window.__OM_API_LOG_CLEAR = () => { window.__OM_API_LOG = []; try { sessionStorage.removeItem(KEY); } catch (e) {} };

  // Non-string request bodies (FormData, URLSearchParams, Blob, ArrayBuffer) → readable text   // OM capture fix
  async function bodyText(b) {
    if (b == null || typeof b === 'string') return b;
    try {
      if (b instanceof URLSearchParams) return b.toString();
      if (b instanceof FormData) { const o = {}; b.forEach((v, k) => { o[k] = typeof v === 'string' ? v : '[file ' + (v.name || '') + ']'; }); return JSON.stringify(o); }
      return await new Response(b).text();
    } catch (e) { return '[unreadable body: ' + (b && b.constructor && b.constructor.name) + ']'; }
  }

  function save(method, url, reqHeaders, body, resText, status) {
    // resolve relative URLs ("/api/...") and match the real host, not text inside query strings (e.g. analytics)   // OM capture fix
    try { url = new URL(url, location.href).href; } catch (e) { return; }
    if (!/(^|\.)ttdevasthanams\.ap\.gov\.in$/i.test(new URL(url).hostname)) return;
    const entry = {
      t: new Date().toISOString(),
      method: (method || 'GET').toUpperCase(),
      url,
      reqHeaders: {},
      body: body ? (typeof body === 'string' ? body.slice(0, 5000) : JSON.stringify(body).slice(0, 5000)) : null,
      status,
      response: resText ? resText.slice(0, 5000) : null
    };
    for (const [k, v] of Object.entries(reqHeaders || {})) {
      if (/auth|token|bearer|cookie|content-type|x-/i.test(k)) {
        entry.reqHeaders[k] = v;
      }
    }
    window.__OM_API_LOG.push(entry);
    persist();
    console.log('[OM-API]', entry.method, entry.url, status, '→ logged');
  }

  // ── Intercept fetch ──
  const _fetch = window.fetch;
  window.fetch = async function(input, init) {
    init = init || {};
    const url = typeof input === 'string' ? input : (input?.url || '');
    const method = init.method || 'GET';
    let headers = {};
    if (init.headers) {
      if (init.headers instanceof Headers) {
        init.headers.forEach((v, k) => headers[k] = v);
      } else {
        headers = { ...init.headers };
      }
    }
    const body = init.body;
    let res;
    try {
      res = await _fetch.apply(this, arguments);
      const clone = res.clone();
      Promise.all([clone.text(), bodyText(body)]).then(([txt, b]) => save(method, url, headers, b, txt, res.status)).catch(() => {});
      return res;
    } catch (e) {
      bodyText(body).then(b => save(method, url, headers, b, null, 'ERROR: ' + e.message));
      throw e;
    }
  };

  // ── Intercept XHR ──
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  const _setHdr = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function(method, url) {
    this.__m = method;
    this.__u = url;
    this.__h = {};
    return _open.apply(this, arguments);
  };

  XMLHttpRequest.prototype.setRequestHeader = function(k, v) {
    if (this.__h) this.__h[k] = v;
    return _setHdr.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function(body) {
    const xhr = this;
    xhr.addEventListener('loadend', function() {
      let r = ''; try { r = (xhr.responseType === '' || xhr.responseType === 'text') ? xhr.responseText : JSON.stringify(xhr.response); } catch (e) {}
      bodyText(body).then(b => save(xhr.__m, xhr.__u, xhr.__h, b, r, xhr.status));
    });
    return _send.apply(this, arguments);
  };

  console.log('[OM-API] Capture active — watching ttdevasthanams.ap.gov.in');
})();
