// TTD Direct Booking API — bypasses website UI and virtual queue
// Reads auth from cookies automatically, books in under 500ms

(function() {

const BASE = 'https://ttdevasthanams.ap.gov.in/api/sed/v1/seva';

// Get auth cookies from the page
function getCookies() {
  const cookies = {};
  document.cookie.split(';').forEach(c => {
    const [k, v] = c.trim().split('=');
    if (k) cookies[k.trim()] = decodeURIComponent(v || '');
  });
  return cookies;
}

function getAuthHeaders() {
  const c = getCookies();
  return {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authtoken': c.authtoken || '',
    'Userid': c.user_id || '',
    'Origin': 'https://ttdevasthanams.ap.gov.in',
    'Referer': window.location.href  // use actual page URL as referer
  };
}

async function apiPost(path, body, query = '') {
  const url = BASE + path + (query ? '?' + query : '');
  const res = await fetch(url, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(body),
    credentials: 'include'
  });
  return res.json();
}

async function apiGet(path, query = '') {
  const url = BASE + path + (query ? '?' + query : '');
  const res = await fetch(url, {
    method: 'GET',
    headers: getAuthHeaders(),
    credentials: 'include'
  });
  return res.json();
}

// Main booking function
// sevaTypeId: the userSelectedSevaType number (e.g. 47 for Bangalore Batch B)
// sevaDate: "YYYYMMDD" format (e.g. "20261110")
// userProfile: full sevak profile object from get_master_sevaks
// bookingType: "INDIVIDUAL" or "GROUP"
window.__TTD_DIRECT_BOOK = async function(config) {
  const { sevaTypeId, sevaDate, bookingType = 'INDIVIDUAL', noOfPilgrim = 1 } = config;

  const log = [];
  const step = (msg, data) => { log.push({ msg, data }); console.log('[TTD-DIRECT]', msg, data || ''); };

  try {
    // Log what cookies are being used
    const cookieCheck = getCookies();
    step('Auth cookies', { authtoken: cookieCheck.authtoken?.slice(0,20) + '...', user_id: cookieCheck.user_id, valid_till: cookieCheck.valid_till });

    // Step 0: Get master sevaks — response: {status, result: [{sevakId, masterSevakId, ...}]}
    step('Getting master sevaks...');
    const masterRes = await apiGet('/get_master_sevaks');
    step('get_master_sevaks raw', JSON.stringify(masterRes).slice(0, 300));

    // result is an array
    const masterList = Array.isArray(masterRes?.result) ? masterRes.result
                     : Array.isArray(masterRes) ? masterRes : [];

    if (!masterList.length) {
      return { status: 'error', error: 'No master sevaks found. Response: ' + JSON.stringify(masterRes).slice(0,300), log };
    }

    // Group leader first, else first entry
    const masterSevak = masterList.find(s => s.isGroupLeader) || masterList[0];

    // From screenshot: field is "masterSevakId" (with k) — same value as sevakId
    // The API body needs "masterSevaId" (without k)
    const masterSevaId = masterSevak.masterSevakId || masterSevak.masterSevaId ||
                         masterSevak.sevakId || masterSevak.id;

    if (!masterSevaId) {
      return { status: 'error', error: 'masterSevaId not found. Keys: ' + Object.keys(masterSevak).join(','), log };
    }
    step('Got master sevak', { name: masterSevak.sevakName, masterSevaId, keys: Object.keys(masterSevak).join(',') });

    // Step 1: Create ticket (slot booking)
    step('Creating ticket...');
    const ticketRes = await apiPost('/ticket', {
      bookingType,
      userSelectedSevaDate: sevaDate,
      userSelectedSevaType: sevaTypeId,
      noOfPilgrim
    });

    step('ticket response', JSON.stringify(ticketRes).slice(0, 300));
    if (ticketRes?.status !== 'success') {
      return { status: 'error', error: 'Ticket creation failed: ' + JSON.stringify(ticketRes), log };
    }
    const ticketId = ticketRes.result?.id;
    const bookingStatus = ticketRes.result?.bookingStatus;

    // Get masterSevaId from ticket response masterSevaList
    // This is the correct source — not from get_master_sevaks
    const masterSevaList = ticketRes.result?.masterSevaList || ticketRes.result?.masterSevakList || [];
    const masterSevaFromTicket = masterSevaList[0];
    const masterSevaIdFromTicket = masterSevaFromTicket?.masterSevaId || masterSevaFromTicket?.masterSevakId ||
                                   masterSevaFromTicket?.sevakId || masterSevaId;

    step('Ticket created', { ticketId, bookingStatus, masterSevaIdFromTicket, masterSevaList: JSON.stringify(masterSevaList) });

    if (bookingStatus && bookingStatus !== 'OPEN') {
      return { status: 'error', error: 'Ticket status is ' + bookingStatus + ' (not OPEN) — try a different date or seva type', log };
    }

    // Use masterSevaId from ticket response — this is what TTD expects
    const finalMasterSevaId = masterSevaIdFromTicket || masterSevaId;

    const sevakDetail = {
      ...masterSevak,
      masterSevakId: finalMasterSevaId,
      isGroupLeader: true,
      isSecondaryLeader: false,
      isMaster: true
    };

    const addMasterPayload = {
      isGroupLeader: true,
      isSecondaryLeader: false,
      masterSevaId: finalMasterSevaId,   // without k
      masterSevakId: finalMasterSevaId,  // with k — TTD may check either
      sevakDetail,
      ticketId
    };
    step('add_sevak_to_master_list payload', JSON.stringify(addMasterPayload).slice(0, 500));
    // Manual booking always used GROUP — use GROUP for all bookings
    const regType = 'GROUP';
    const addMasterRes = await apiPost('/add_sevak_to_master_list', addMasterPayload, 'registration_type=' + regType);
    step('add_sevak_to_master_list response', JSON.stringify(addMasterRes).slice(0, 500));

    if (addMasterRes?.status !== 'success') {
      return { status: 'error', error: 'Add master list failed: ' + JSON.stringify(addMasterRes) + ' | payload: ' + JSON.stringify(addMasterPayload).slice(0, 300), log };
    }
    const sevakId = addMasterRes.result?.sevakId;
    step('Added to master list', { sevakId });

    // Step 3: Add sevaks (final confirmation)
    step('Adding sevaks...');
    const addSevaksBody = {
      ticketId,
      isGroupLeader: true,
      isSecondaryLeader: false,
      registeredSevakId: null,
      sevakDetail: {
        ...sevakDetail,
        id: sevakId,
        registeredSevakId: masterSevak.registeredSevaId || masterSevak.registeredSevakId || null,
        templeId: masterSevak.templeId || 10,
        masterSevakId: masterSevaId,
        isGroupLeader: true,
        isSecondaryLeader: false,
        isMaster: true,
        isVerified: true
      }
    };
    const addSevaksRes = await apiPost('/add_sevaks', addSevaksBody);

    if (addSevaksRes?.status !== 'success') {
      return { status: 'error', error: 'Add sevaks failed: ' + JSON.stringify(addSevaksRes), log };
    }
    step('Booking COMPLETE!', addSevaksRes.result);

    return {
      status: 'success',
      ticketId,
      sevakId,
      result: addSevaksRes.result,
      log
    };

  } catch (e) {
    return { status: 'error', error: e.message, log };
  }
};

// Helper to get available seva types
window.__TTD_GET_SEVA_TYPES = async function() {
  const res = await fetch(BASE + '/get_seva_name?sevaType=INDIVIDUAL', {
    headers: getAuthHeaders(),
    credentials: 'include'
  });
  return res.json();
};

// Helper to check availability
window.__TTD_GET_AVAILABILITY = async function(sevaName, sevaDate) {
  const url = BASE + `/get_availability?sevaType=INDIVIDUAL&sevaName=${encodeURIComponent(sevaName)}&date=${sevaDate}`;
  const res = await fetch(url, { headers: getAuthHeaders(), credentials: 'include' });
  return res.json();
};

console.log('[TTD-DIRECT] Loaded. Use window.__TTD_DIRECT_BOOK({sevaTypeId, sevaDate, bookingType})');

})();
