/* =========================================================
   BACKGROUND SERVICE WORKER
   Handles full-page-load navigation for multi-segment workflows.
   Uses chrome.storage.session for persistence across service worker sleep.
   ONE-SHOT: storage entry is DELETED immediately on first read — no loops.
   ========================================================= */

try { importScripts("ttd-addon.js"); } catch (e) { console.warn("TTD add-on not loaded:", e); }   // OM TTD add-on

console.log("🔧 background build: anysite v3");

const COOLDOWN_MS = 4000;
// in-memory duplicate-event guard: tabId → { t: time, url }  (ok to lose on restart)
const tabFired = {};

// ── Receive pending segments from popup.js ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // The page tells us an `anysite` segment did its job — stop re-trying it after further redirects
  if (msg.type === "SEGMENT_DONE") {
    const id = sender?.tab?.id;
    if (id !== undefined && id !== null) {
      try { chrome.storage.session.remove(`any_${id}`); } catch(e) {}
    }
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "STORE_PENDING") {
    const { segments, segmentIndex, repeat, selectedRowIndex, originUrl, speed } = msg;
    const tabId = msg.tabId ?? sender?.tab?.id;      // scheduled runs are sent by the page itself
    if (tabId === undefined || tabId === null) { sendResponse({ ok: false }); return; }

    const key = `seg_${tabId}`;
    const data = {
      segments,
      segmentIndex: segmentIndex || 1,
      repeat:       repeat || false,
      selectedRowIndex: selectedRowIndex ?? null,
      speed:        speed || 1.0,     // Normal/Fast/Turbo multiplier from popup — must reach later pages too
      storedAt:     Date.now(),
      originHost:   originUrl ? new URL(originUrl).hostname : null
    };

    // Try session storage, fallback to local
    const save = (cb) => {
      chrome.storage.session.set({ [key]: data }, () => {
        if (chrome.runtime.lastError) {
          chrome.storage.local.set({ [key]: data }, cb);
        } else {
          cb && cb();
        }
      });
    };

    save(() => {
      console.log(`💾 bg: stored ${segments.length} segments for tab ${tabId}`);
    });

    sendResponse({ ok: true });
    return true;
  }
});

// Inject content.js (no-op if already there) and hand the page its commands
async function sendSegment(tabId, seg, meta) {
  await sleep(150);   // was 400

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch(e) {
    console.warn("❌ inject failed:", e.message);
    return;
  }

  await sleep(80);    // was 150

  const runMsg = {
    type:    "WAIT_AND_RUN",
    commands: seg.commands || [],
    groups:   seg.groups   || [],
    repeat: meta.repeat,
    selectedRowIndex: meta.selectedRowIndex,
    _speed: meta.speed || 1.0,          // ← was never sent, so every later page ran at Normal speed
    _anysite: !!meta.anySite,           // page reports back (SEGMENT_DONE) after its first successful action
    _id: Date.now() + "_bg_" + Math.random().toString(36).slice(2, 5)
  };
  // Delays are shorter now, so retry a couple of times if the content script isn't listening yet
  const send = (attempt) => chrome.tabs.sendMessage(tabId, runMsg, () => {
    if (chrome.runtime.lastError && attempt < 4) setTimeout(() => send(attempt + 1), 300);
  });
  send(1);
}

// `anysite` segments can land on a transient redirect page (payment gateways). If the page has not
// reported back (SEGMENT_DONE), run the same segment again on the next page load — a few times, briefly.
async function retryAnySite(tabId, tab) {
  const rkey = `any_${tabId}`;
  let rec = null;
  try { const r = await chrome.storage.session.get(rkey); rec = r?.[rkey] || null; } catch(e) {}
  if (!rec) return;

  const now = Date.now();
  if (now - rec.storedAt > 60 * 1000 || rec.attempts >= 4) {
    try { await chrome.storage.session.remove(rkey); } catch(e) {}
    return;
  }
  const last = tabFired[tabId];
  if (last && last.url === tab.url && now - last.t < COOLDOWN_MS) return;   // duplicate event, same page

  rec.attempts += 1;
  try { await chrome.storage.session.set({ [rkey]: rec }); } catch(e) {}
  tabFired[tabId] = { t: now, url: tab.url };
  console.log(`🔁 bg: anysite retry ${rec.attempts}/4 | ${tab.url}`);
  await sendSegment(tabId, rec.seg, rec.meta);
}

// ── Fire on real full-page load ──
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab.url || tab.url.startsWith("chrome")) return;

  const key = `seg_${tabId}`;

  // Read AND DELETE in one operation — guarantees single consumption
  let pending = null;
  try {
    const res = await chrome.storage.session.get(key);
    pending = res?.[key] || null;
    if (pending) await chrome.storage.session.remove(key);
  } catch(e) {
    try {
      const res = await chrome.storage.local.get(key);
      pending = res?.[key] || null;
      if (pending) await chrome.storage.local.remove(key);
    } catch(e2) {}
  }

  if (!pending) { await retryAnySite(tabId, tab); return; }

  // Expiry: 10 minutes
  if (Date.now() - pending.storedAt > 10 * 60 * 1000) {
    console.log("⏰ bg: segments expired");
    return;
  }

  // ── Domain check: skip external domains (payment gateways etc) ──
  // Only fire when back on the original site domain — unless this segment says `anysite`
  const nextSeg = pending.segments?.[pending.segmentIndex];
  const anySite = !!nextSeg?.commands?.some(c => c.type === "anysite");
  if (pending.originHost && !anySite) {
    try {
      const currentHost = new URL(tab.url).hostname;
      if (currentHost !== pending.originHost) {
        console.log(`⏭️ bg: skipping external domain ${currentHost} (waiting for ${pending.originHost})`);
        // We left the site (payment gateway etc.) — the next load on our domain is a real return, never a duplicate
        delete tabFired[tabId];
        // Re-save — segment not consumed, waiting for redirect back
        try { await chrome.storage.session.set({ [`seg_${tabId}`]: pending }); } catch(e) {
          try { await chrome.storage.local.set({ [`seg_${tabId}`]: pending }); } catch(e2) {}
        }
        return;
      }
    } catch(e) {}
  }

  // Duplicate-event guard: only swallow a repeat "complete" for the SAME url shortly after a fire.
  // (A genuine next page has a different url, so fast runs / Turbo can no longer be swallowed.)
  const now = Date.now();
  const last = tabFired[tabId];
  if (last && last.url === tab.url && now - last.t < COOLDOWN_MS) {
    // Re-save for next navigation since we deleted it
    const rekey = `seg_${tabId}`;
    try { await chrome.storage.session.set({ [rekey]: pending }); } catch(e) {
      try { await chrome.storage.local.set({ [rekey]: pending }); } catch(e2) {}
    }
    return;
  }
  tabFired[tabId] = { t: now, url: tab.url };

  const { segments, segmentIndex, repeat, selectedRowIndex, speed } = pending;

  if (!segments || segmentIndex >= segments.length) {
    console.log("✅ bg: all segments done");
    return;
  }

  // If more segments remain after this one, re-save with advanced index
  const nextIndex = segmentIndex + 1;
  if (nextIndex < segments.length) {
    const nextData = { ...pending, segmentIndex: nextIndex, storedAt: Date.now() };
    try { await chrome.storage.session.set({ [`seg_${tabId}`]: nextData }); } catch(e) {
      try { await chrome.storage.local.set({ [`seg_${tabId}`]: nextData }); } catch(e2) {}
    }
  }

  console.log(`🔁 bg: page load → segment ${segmentIndex + 1}/${segments.length} | ${tab.url}${anySite ? " (anysite)" : ""}`);

  const seg = segments[segmentIndex];
  const meta = { repeat, selectedRowIndex, speed, anySite };

  if (anySite) {
    try {
      await chrome.storage.session.set({ [`any_${tabId}`]: { seg, meta, storedAt: Date.now(), attempts: 1 } });
    } catch(e) {}
  }

  await sendSegment(tabId, seg, meta);
});

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── TTD login OTP relay (new) — content script otp-autofill.js asks, we fetch from the user's relay ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "OM_OTP_GET") return;
  (async () => {
    const { omOtpRelay: cfg } = await chrome.storage.local.get("omOtpRelay");
    if (!cfg?.enabled || !cfg.url || !cfg.key) return { disabled: true };
    const url = `${cfg.url.replace(/\/+$/, "")}/otp?mobile=${encodeURIComponent(msg.mobile)}&since=${msg.since}`;
    try {
      const res = await fetch(url, { headers: { "X-Key": cfg.key }, cache: "no-store" });
      if (res.status === 204) return {};
      if (!res.ok) return { error: `HTTP ${res.status}` };
      const j = await res.json();
      return { otp: j.otp ? String(j.otp) : null };
    } catch (e) { return { error: e.message }; }
  })().then(sendResponse);
  return true;
});
