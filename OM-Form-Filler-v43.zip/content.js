if (window.__AUTO_FILL_ENGINE_LOADED__) {
  console.log("⏭️ Engine already injected");
} else {
  window.__AUTO_FILL_ENGINE_LOADED__ = true;
  console.log("🔧 content.js build: anysite v13");


/* =========================================================
   Universal Order-Based Form Autofill (FINAL CLEAN VERSION)
   ========================================================= */

/* ================= MESSAGE LISTENER ================= */

window.__repeatMode ??= false;
window.__workflowGroups ??= [];
window.__selectedRowIndex = null;
window.__repeatProfileIndex ??= 0;  // tracks which profile to use next in repeat mode
window.__pendingSegments ??= null;   // stores remaining segments for SPA navigation
window.__spaLastUrl ??= "";
window.__spaRunning ??= false;
window.__spaHandledUrl ??= "";

/* =========================================================
   SPA NAVIGATION WATCHER
   Patches history.pushState to detect React Router navigation.
   When URL changes, runs the next pending segment directly.
   This avoids background.js which loses state on service worker restart.
   ========================================================= */
if (!window.__spaWatcherInstalled) {
  window.__spaWatcherInstalled = true;

  const _origPush    = history.pushState.bind(history);
  const _origReplace = history.replaceState.bind(history);

  const onUrlChange = async (newUrl) => {
    const bare = newUrl.split("?")[0];
    console.log(`🌐 pushState detected: ${bare} | pending: ${!!window.__pendingSegments} | running: ${window.__spaRunning} | lastUrl: ${window.__spaLastUrl}`);

    if (!window.__pendingSegments) return;
    if (window.__spaRunning) return;

    if (bare === window.__spaLastUrl) {
      console.log("⏭️ SPA: same URL, skipping");
      return;
    }
    window.__spaLastUrl = bare;

    const { segments, segmentIndex } = window.__pendingSegments;
    if (segmentIndex >= segments.length) {
      window.__pendingSegments = null;
      return;
    }

    window.__spaRunning = true;
    window.__spaHandledUrl = bare;
    window.__pendingSegments = {
      ...window.__pendingSegments,
      segmentIndex: segmentIndex + 1
    };

    console.log(`🔁 SPA nav → segment ${segmentIndex + 1}/${segments.length} | ${bare}`);

    const seg = segments[segmentIndex];
    window.__workflowGroups = seg.groups || [];

    console.log(`📋 Segment groups: ${seg.groups?.length} rows, commands: ${seg.commands?.map(c=>c.type).join(',')}`);

    await waitForSegmentReady(seg.commands, seg.groups, 15000);
    await sleep(200); // extra buffer for React to finish hydrating route

    console.log(`🚀 Running segment ${segmentIndex + 1} now`);
    await runWorkflow(seg.commands || []);

    window.__spaRunning = false;

    if (!window.__pendingSegments ||
        window.__pendingSegments.segmentIndex >= segments.length) {
      window.__pendingSegments = null;
      window.__spaLastUrl = "";
      window.__spaHandledUrl = "";
      console.log("✅ All SPA segments complete");
    }
  };

  history.pushState = function(...args) {
    _origPush(...args);
    setTimeout(() => onUrlChange(location.href), 50);
  };

  history.replaceState = function(...args) {
    const before = location.href.split("?")[0];
    _origReplace(...args);
    const after = location.href.split("?")[0];
    if (after !== before) {
      console.log(`🌐 replaceState detected: ${after}`);
      setTimeout(() => onUrlChange(location.href), 50);
    }
  };

  // Also watch popstate (browser back/forward)
  window.addEventListener("popstate", () => {
    console.log(`🌐 popstate detected: ${location.href}`);
    setTimeout(() => onUrlChange(location.href), 50);
  });

  // Poll for URL changes as final fallback (catches any navigation method)
  let _pollUrl = location.href.split("?")[0];
  setInterval(() => {
    const cur = location.href.split("?")[0];
    if (cur !== _pollUrl) {
      _pollUrl = cur;
      console.log(`🌐 URL poll detected: ${cur}`);
      onUrlChange(location.href);
    }
  }, 300);
}



// 🔐 Safe global workflow state
window.__workflowState ??= {
  running: false,
  processedCount: 0,
  totalRows: 0
};


// Deduplication: track last processed message to prevent double execution
window.__lastMsgId ??= null;

// (named so the scheduler below can run a payload exactly as if it had just arrived from the popup)
const __mainMessageHandler = (msg, sender, sendResponse) => {
  // 🏓 PING — used by popup to check if content.js is alive
  if (msg.type === "PING") {
    sendResponse({ alive: true });
    return true;
  }

  // 🔁 repeat mode
  if (msg.repeat !== undefined) {
    window.__repeatMode = msg.repeat;
  }

  // 🧠 selected table row (radio selection from popup)
  if (msg.selectedRowIndex !== undefined) {
    window.__selectedRowIndex = msg.selectedRowIndex;
  }

  if (msg.type === "FILL_BY_ORDER") {
    if (!Array.isArray(msg.groups)) return;

    msg.groups.forEach(values =>
      fillInOrder(values, window.__repeatMode)
    );
  }

  if (msg.type === "WAIT_AND_RUN") {
    const targetUrl = location.href.split("?")[0];
    (async () => {
      console.log(`⏱ WAIT_AND_RUN received ${Math.round(performance.now())}ms after page start | speed x${msg._speed ?? 1.0}`);
      await waitForSegmentReady(msg.commands, msg.groups, 15000);
      console.log(`⏱ page ready ${Math.round(performance.now())}ms after page start`);
      await sleep(150);
      if (window.__spaHandledUrl === targetUrl || window.__spaRunning) {
        console.log("⏭️ WAIT_AND_RUN skipped — SPA watcher handling:", targetUrl);
        return;
      }
      window.__workflowGroups = msg.groups || [];
      window.__fillSpeed = msg._speed ?? 1.0;
      window.__anySiteRun = !!msg._anysite;          // report back to background after the first successful action
      await runWorkflow(msg.commands || []);
    })();
    return;
  }

  if (msg.type === "RUN_WORKFLOW") {
    if (!Array.isArray(msg.commands)) return;

    // ── Deduplication ──
    const msgId = msg._id ||
      ((msg.commands.map(c=>c.type+(c.value||"")).join("|")) +
       "|" + (msg.groups?.[0]?.length || 0));

    if (msgId && msgId === window.__lastMsgId) {
      console.log("⏭️ Duplicate RUN_WORKFLOW ignored:", msgId);
      return;
    }
    window.__lastMsgId = msgId;
    setTimeout(() => { if (window.__lastMsgId === msgId) window.__lastMsgId = null; }, 10000);

    // ── Smart segment detection ──
    // If this is a multi-segment workflow but the current page already matches
    // a later segment's expected page, skip earlier segments and run the right one.
    if (Array.isArray(msg.segments) && msg.segments.length > 1) {

      // Find the best matching segment for current URL
      const currentUrl = location.href.toLowerCase();

      // Detect which segment to start from based on current page
      // Segment[0] is typically the "slot/calendar" page
      // Segment[1] is typically the "pilgrim/fill" page
      // Heuristic: if segment[0] has "date" command but no fill-like page indicators,
      // and current URL looks like a "later" page, skip to segment[1]

      const seg0Commands = msg.segments[0]?.commands || [];
      const seg0HasDate = seg0Commands.some(c => c.type === "date");
      const seg0HasSlotClick = seg0Commands.some(c =>
        c.type === "click" && (c.value || "").toLowerCase().includes("slot")
      );

      // Check if current page looks like a pilgrim/details page (not slot page)
      // by looking for many visible inputs (slot page has ~5, pilgrim page has 30+)
      const visibleFields = document.querySelectorAll(
        "input:not([type=hidden]):not([type=submit]):not([type=button])"
      ).length;

      // Pilgrim page has 5 fields × N pilgrims = 25+ fields minimum
      // Slot page has calendar + number of tickets = fewer fields
      // Use 25 as threshold to reliably distinguish them
      const onLaterPage = (seg0HasDate || seg0HasSlotClick) && visibleFields > 25;

      if (onLaterPage) {
        // We're already past segment[0]'s page — run segment[1] directly
        console.log(`⏭️ Already on later page (${visibleFields} fields) — skipping to segment 2`);
        const seg1 = msg.segments[1];
        window.__workflowGroups = seg1.groups || [];
        window.__pendingSegments = msg.segments.length > 2 ? {
          segments: msg.segments,
          segmentIndex: 2,
          groups: msg.groups || [],
          repeat: msg.repeat || false
        } : null;
        window.__spaLastUrl = location.href.split("?")[0];
        window.__spaRunning = false;
        runWorkflow(seg1.commands || []);
        return;
      }

      // Normal case: start from segment[0]
      window.__pendingSegments = {
        segments:     msg.segments,
        segmentIndex: 1,
        groups:       msg.groups || [],
        repeat:       msg.repeat || false
      };
      window.__spaLastUrl = "";
      window.__spaRunning = false;
      console.log(`📦 ${msg.segments.length} segments stored in memory (SPA watcher ready)`);

    } else {
      window.__pendingSegments = null;
    }

    window.__workflowGroups = msg.groups || [];
    window.__fillSpeed = msg._speed ?? 1.0;
    if (msg._segmentMeta) {
      const { tabId, segmentIndex, totalSegments } = msg._segmentMeta;
      const key = `pendingSegments_${tabId}`;
      const nextIndex = segmentIndex + 1;

      const advanceStorage = async () => {
        try {
          const stored = await chrome.storage.session.get(key);
          if (stored?.[key]) {
            if (nextIndex >= totalSegments) {
              await chrome.storage.session.remove(key);
              console.log("✅ All segments complete — cleared pending storage");
            } else {
              await chrome.storage.session.set({
                [key]: { ...stored[key], segmentIndex: nextIndex }
              });
            }
          }
        } catch (e) {
          // fallback to local
          try {
            const stored = await chrome.storage.local.get(key);
            if (stored?.[key]) {
              if (nextIndex >= totalSegments) {
                await chrome.storage.local.remove(key);
              } else {
                await chrome.storage.local.set({
                  [key]: { ...stored[key], segmentIndex: nextIndex }
                });
              }
            }
          } catch(e2) {}
        }
      };

      advanceStorage();
    }

    runWorkflow(msg.commands);
  }

  if (msg.action === "CLEAR_FORM") {
      universalClearForm();
      window.__workflowState.processedCount = 0;
      window.__workflowState.totalRows = 0;
      hideRowProgress();
  }

};
chrome.runtime.onMessage.addListener(__mainMessageHandler);


/* =========================================================
   SCHEDULED START
   The popup hands us { runAt, payload }; the timer lives HERE, in the page, so it keeps running
   after the popup closes. Far away: wake rarely. Last ~1.5 s: poll every 10 ms for an exact start.
   (Lost if the page reloads; Chrome slows timers in hidden tabs, so keep the tab visible.)
   ========================================================= */
window.__schedule = null;

function __cancelSchedule() {
  if (window.__schedule?.timer) clearTimeout(window.__schedule.timer);
  window.__schedule = null;
}

function __fireScheduled(payload) {
  try { chrome.runtime.sendMessage({ type: "OM_TTD_SCHEDULE_FIRED" }, () => void chrome.runtime.lastError); } catch (e) {}   // OM TTD add-on
  // Multi-page workflows: hand the later pages to background.js NOW (not when scheduling —
  // it forgets pending pages after 10 minutes).
  if (Array.isArray(payload.segments) && payload.segments.length > 1) {
    try {
      chrome.runtime.sendMessage({
        type: "STORE_PENDING",                       // background reads the tab id from the sender
        segments: payload.segments,
        segmentIndex: 1,
        repeat: payload.repeat || false,
        selectedRowIndex: payload.selectedRowIndex ?? null,
        speed: payload._speed || 1.0,
        originUrl: location.href
      }, () => void chrome.runtime.lastError);
    } catch (e) {}
  }
  console.log("⏰ Scheduled start — running workflow now");
  __mainMessageHandler(
    { ...payload, _id: Date.now() + "_sch_" + Math.random().toString(36).slice(2, 6) },
    {}, () => {}
  );
}

function __armSchedule(runAt, payload) {
  __cancelSchedule();
  const state = { runAt, timer: null };
  window.__schedule = state;

  const tick = () => {
    if (window.__schedule !== state) return;          // cancelled or replaced
    const left = runAt - Date.now();
    if (left <= 0) {
      window.__schedule = null;
      __fireScheduled(payload);
      return;
    }
    const delay = left > 1500 ? Math.min(left - 1000, 15000) : Math.min(left, 10);
    state.timer = setTimeout(tick, delay);
  };
  console.log(`⏰ Scheduled for ${new Date(runAt).toLocaleTimeString()} (in ${Math.round((runAt - Date.now()) / 1000)}s)`);
  tick();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SCHEDULE_RUN" && msg.payload && msg.runAt) {
    __armSchedule(msg.runAt, msg.payload);
    sendResponse({ ok: true, runAt: msg.runAt });
    return true;
  }
  if (msg.type === "SCHEDULE_CANCEL") {
    __cancelSchedule();
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "SCHEDULE_STATUS") {
    sendResponse({ scheduled: !!window.__schedule, runAt: window.__schedule?.runAt || null });
    return true;
  }
});



function smartNormalizeValue(str) {
  const s = String(str || "").trim().toLowerCase();

  // Time: "3:00 pm", "03:00 PM", "3.00pm" → "3:00pm"
  const timeMatch = s.match(/^(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?$/);
  if (timeMatch) {
    const h = parseInt(timeMatch[1], 10);
    const m = timeMatch[2] || "00";
    const ap = timeMatch[3] || "";
    return `${h}:${m}${ap}`;
  }

  // Pure number: strip leading zeros → "02" and "2" both become "2"
  if (/^\d+$/.test(s)) return String(parseInt(s, 10));

  return normalize(s);
}

// Leading-zero / am-pm-spacing tolerant text: "03:00 PM", "3:00pm", "3.00 PM" → "3 0 pm"; "02" → "2"
function looseNorm(str) {
  return normalize(str)
    .replace(/(\d)\s*(am|pm)\b/g, "$1 $2")
    .replace(/\b0+(\d)/g, "$1");
}

// Does optionText match the typed value ignoring leading zeros?
//  - exact (after looseNorm) → match
//  - pure number ("2")       → exact only, so "2" never matches "12" / "20"
//  - has digits ("3:00 PM")  → whole-token match, so "1:00 pm" never matches "11:00 pm",
//                              but "3:00 PM" still matches "03:00 PM - 04:00 PM"
//  - plain text              → substring
function looseTextMatch(optionText, value) {
  const o = looseNorm(optionText), t = looseNorm(value);
  if (!o || !t) return false;
  if (o === t) return true;
  if (/^\d+$/.test(t)) return false;
  if (/\d/.test(t)) return (" " + o + " ").includes(" " + t + " ");
  return o.includes(t);
}

/* ================= TIME RANGE  ("between 11:00 AM and 06:00 PM") =================
   Lets a value mean "any slot in this window": the first slot found inside it is chosen.
   Accepted: "between 11:00 AM and 06:00 PM" · "11:00 AM - 6 PM" · "11:00 to 18:00" ·
   optional last word  latest | last  (default is the earliest slot in the window).
   ================================================================================== */

// One clock: "3:00 PM" "03:00pm" "3pm" "15:30" "11" → { min (since midnight), explicit, ap, h12, h, mn } | null
function parseClockSide(str) {
  const m = String(str || "").trim().toLowerCase().match(/^(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?$/);
  if (!m) return null;
  const h = +m[1], mn = m[2] ? +m[2] : 0, ap = m[3] ? m[3][0] : "";
  if (mn > 59) return null;
  if (ap) { if (h < 1 || h > 12) return null; }
  else if (h > 23) return null;
  const h24 = ap ? (h % 12) + (ap === "p" ? 12 : 0) : h;
  return { min: h24 * 60 + mn, explicit: !!(m[2] || ap), ap, h12: !ap && h <= 12, h, mn };
}

// First clock time inside free text: "10:00 AM - 11:00 AM (5 left)" → 600 · needs a colon or am/pm, so "5 slots" is ignored
function firstClockIn(text) {
  const s = String(text || "");
  const re = /(\d{1,2}):(\d{2})\s*(am|pm|a\.m\.|p\.m\.)?|(\d{1,2})(?:\.(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)(?![a-z])/gi;
  let m;
  while ((m = re.exec(s))) {
    const prev = m.index > 0 ? s[m.index - 1] : "";
    if (/[\d:]/.test(prev)) continue;                       // inside a longer number
    const h = +(m[1] ?? m[4]), mn = +(m[2] ?? m[5] ?? 0), ap = ((m[3] ?? m[6]) || "")[0]?.toLowerCase() || "";
    if (mn > 59) continue;
    if (ap) { if (h < 1 || h > 12) continue; }
    else if (h > 23) continue;
    return ((ap ? (h % 12) + (ap === "p" ? 12 : 0) : h) * 60) + mn;
  }
  return null;
}

// "between 11:00 AM and 06:00 PM [latest]" → { from, to, pick } (minutes) | null when the text is not a time range
function parseTimeRangeSpec(value) {
  const s = String(value || "").trim();
  if (!s) return null;
  const kw = s.match(/\s+(latest|last|earliest|first)$/i);
  const pick = kw && /^(latest|last)$/i.test(kw[1]) ? "latest" : "earliest";
  const body = (kw ? s.slice(0, kw.index) : s).replace(/^between\s+/i, "").trim();
  const parts = body.split(/\s+(?:and|to)\s+|\s*[-–—~]\s*/i);
  if (parts.length !== 2) return null;
  let a = parseClockSide(parts[0]), b = parseClockSide(parts[1]);
  if (!a || !b) return null;
  if (!a.explicit && !b.explicit) return null;               // "2-3" is not a time range
  // "11 - 6 PM" / "6 - 9 PM": borrow the second side's am/pm for the first when that makes sense
  if (!a.ap && b.ap && a.h12) {
    const alt = ((a.h % 12) + (b.ap === "p" ? 12 : 0)) * 60 + a.mn;
    if (alt <= b.min) a = { ...a, min: alt };
  }
  if (a.min > b.min) return null;
  return { from: a.min, to: b.min, pick };
}

// Sold-out / disabled / closed slot?
function slotLooksUnavailable(el, text) {
  if (!el) return true;
  if (el.disabled === true) return true;
  if (el.getAttribute?.("aria-disabled") === "true") return true;
  if (el.style?.pointerEvents === "none") return true;
  if (/disabled|unavailable|booked|sold|inactive|\bfull\b|closed|\bpast\b/i.test(String(el.className || ""))) return true;
  return /sold\s*out|house\s*full|not\s*available|unavailable|\bfull\b|no\s*slots?|closed/i.test(String(text || ""));
}

// Among items, the earliest (or latest) available one whose first time falls inside the window
function pickSlotInRange(items, spec, getText = (x) => x.text) {
  const cands = [];
  items.forEach((it, idx) => {
    const text = getText(it) || "";
    const min = firstClockIn(text);
    if (min === null || min < spec.from || min > spec.to) return;
    if (slotLooksUnavailable(it && it.el ? it.el : it, text) || (it && it.radio && !radioEnabled(it.radio))) return;   // items may be {el, text, radio} wrappers
    cands.push({ it, min, idx });
  });
  if (!cands.length) return null;
  cands.sort((x, y) => (spec.pick === "latest" ? y.min - x.min : x.min - y.min) || x.idx - y.idx);
  return cands[0].it;
}

// "10:00 AM, 07:00 PM" — what the page offered (for failure messages)
function describeSlotsFound(items, getText = (x) => x.text) {
  const set = [];
  items.forEach(it => {
    const t = (getText(it) || "").replace(/\s+/g, " ").trim();
    if (t && firstClockIn(t) !== null && !set.includes(t)) set.push(t.slice(0, 24));
  });
  return set.length ? "found: " + set.slice(0, 8).join(", ") : "no time slots found on the page";
}

// Best option for native <select> / lists:
//   exact → smart time/number → leading-zero tolerant → time RANGE → original substring
function pickOption(items, value, getText = (x) => x.text) {
  const t = normalize(value);
  const spec = parseTimeRangeSpec(value);
  return items.find(i => normalize(getText(i)) === t)
      || items.find(i => smartNormalizeValue(getText(i)) === smartNormalizeValue(value))
      || items.find(i => looseTextMatch(getText(i), value))
      || (spec ? pickSlotInRange(items, spec, getText) : null)
      || (spec ? null : items.find(i => normalize(getText(i)).includes(t)));   // a range never falls back to substring guessing
}


/* ================= IMAGE UPLOAD ENGINE ================= */

// Convert base64 → File
function base64ToFile(base64, filename, mime) {
  const byteString = atob(base64.split(",")[1]);
  const array = new Uint8Array(byteString.length);

  for (let i = 0; i < byteString.length; i++) {
    array[i] = byteString.charCodeAt(i);
  }

  return new File([array], filename, { type: mime });
}


// Find nearest / any file input
function findFileInput() {
  return (
    document.querySelector('input[type="file"]:not([disabled])') ||
    document.querySelector('input[type="file"]')
  );
}


// Upload image by filename
async function uploadImageByName(filename) {
  return new Promise((resolve) => {
    chrome.storage.local.get("imageLibrary", (res) => {
      const library = res.imageLibrary || {};
      const image = library[filename];

      if (!image) {
        console.warn(`❌ Image not found in library: ${filename}`);
        return resolve(false);
      }

      const input = findFileInput();
      if (!input) {
        console.warn("❌ File input not found on page");
        return resolve(false);
      }

      const file = base64ToFile(
        image.data,
        image.name,
        image.type
      );

      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;

      input.dispatchEvent(new Event("change", { bubbles: true }));

      console.log(`✅ Image uploaded: ${filename}`);
      resolve(true);
    });
  });
}




/* ================= HELPERS ================= */

/* =========================================================
   REACT FIBER CLEAR
   Finds React's internal onChange handler via the fiber tree
   and calls it with an empty value — the only reliable way
   to clear a React controlled input without re-render restoring it.
   ========================================================= */
function reactFiberClear(el) {
  if (!el) return false;

  const fieldName = el.name || el.getAttribute("label") || "";

  // Find React keys on the element
  const propsKey = Object.keys(el).find(k => k.startsWith("__reactProps"));
  const fiberKey = Object.keys(el).find(k =>
    k.startsWith("__reactFiber") || k.startsWith("__reactInternalInstance")
  );

  // ── Method A: direct __reactProps onChange ──
  if (propsKey) {
    const props = el[propsKey];
    if (props?.onChange) {
      try {
        props.onChange({ target: { value: "", name: fieldName }, currentTarget: el,
                         preventDefault:()=>{}, stopPropagation:()=>{} });
        return true;
      } catch(e) {}
    }
  }

  if (!fiberKey) return false;

  let fiber = el[fiberKey];

  // ── Method B: walk fiber tree ──
  let depth = 0;
  while (fiber && depth < 40) {
    depth++;

    // B1: props onChange
    const props = fiber.memoizedProps;
    if (props?.onChange) {
      try {
        props.onChange({ target: { value: "", name: fieldName }, currentTarget: el,
                         preventDefault:()=>{}, stopPropagation:()=>{} });
        return true;
      } catch(e) {}
    }

    // B2: hooks — useState (string value)
    // B3: hooks — useState/useReducer with object state containing this field
    let hook = fiber.memoizedState;
    let hookIdx = 0;
    while (hook && hookIdx < 25) {
      hookIdx++;
      const dispatch = hook.queue?.dispatch;
      const state = hook.memoizedState;

      if (dispatch) {
        // Plain string state matching our value
        if (typeof state === "string" && state !== "" && fieldName) {
          try { dispatch(""); return true; } catch(e) {}
        }

        // Object state containing our field name as a key
        if (state && typeof state === "object" && !Array.isArray(state) &&
            fieldName && fieldName in state && state[fieldName] !== "") {
          try {
            dispatch(prev => {
              if (typeof prev === "object" && prev !== null) {
                return { ...prev, [fieldName]: "" };
              }
              return prev;
            });
            return true;
          } catch(e) {}
        }

        // useReducer — try dispatching a RESET or CLEAR action
        if (typeof state === "object" && state !== null) {
          try {
            dispatch({ type: "RESET" });
          } catch(e) {}
          try {
            dispatch({ type: "CLEAR" });
          } catch(e) {}
          try {
            dispatch({ type: "SET_VALUE", payload: "", name: fieldName, value: "" });
          } catch(e) {}
        }
      }
      hook = hook.next;
    }

    fiber = fiber.return;
  }

  return false;
}


/* =========================================================
   UNIVERSAL REACT/VUE/ANGULAR SAFE INPUT SETTER
   Works on React, Vue, Angular, plain HTML
   ========================================================= */
function nativeSet(el, value) {
  const tag = el.tagName.toLowerCase();

  const getSetter = (proto) =>
    Object.getOwnPropertyDescriptor(proto, "value")?.set;

  const setter = tag === "textarea"
    ? getSetter(window.HTMLTextAreaElement.prototype)
    : getSetter(window.HTMLInputElement.prototype);

  const apply = (v) => {
    if (setter) setter.call(el, v);
    else el.value = v;
  };

  // If already has a value, clear first so React sees a real change
  if (el.value !== "" && el.value !== value) {
    apply("");
    el.dispatchEvent(new Event("input",  { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  apply(value);
  el.dispatchEvent(new Event("input",  { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

/* =========================================================
   UNIVERSAL REACT-SAFE CLICK
   Works on React, Vue, Angular, plain HTML
   ========================================================= */
function universalClick(el) {
  if (!el) return false;
  el.scrollIntoView({ block: "center" });
  el.dispatchEvent(new PointerEvent("pointerover",  { bubbles: true }));
  el.dispatchEvent(new PointerEvent("pointerenter", { bubbles: true }));
  el.dispatchEvent(new MouseEvent  ("mouseover",    { bubbles: true }));
  el.dispatchEvent(new MouseEvent  ("mouseenter",   { bubbles: true }));
  el.dispatchEvent(new PointerEvent("pointerdown",  { bubbles: true }));
  el.dispatchEvent(new MouseEvent  ("mousedown",    { bubbles: true }));
  el.focus();
  el.dispatchEvent(new PointerEvent("pointerup",    { bubbles: true }));
  el.dispatchEvent(new MouseEvent  ("mouseup",      { bubbles: true }));
  el.dispatchEvent(new MouseEvent  ("click",        { bubbles: true }));
  return true;
}

function universalClearForm() {

  console.log("🧹 Starting Advanced Universal Clear...");

  // ── React state bulk reset ──
  // Find all React fiber states on form inputs and reset them
  // This handles the case where React re-renders restoring old values
  const formInputs = [...document.querySelectorAll(
    "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=file])"
  )];

  // Collect all unique React state dispatch functions
  // Walk fibers from each input upward to find stateful components
  const clearedDispatches = new Set();

  for (const el of formInputs) {
    const fiberKey = Object.keys(el).find(k =>
      k.startsWith("__reactFiber") || k.startsWith("__reactInternalInstance")
    );
    if (!fiberKey) continue;

    let fiber = el[fiberKey];
    let depth = 0;

    while (fiber && depth < 50) {
      depth++;
      let hook = fiber.memoizedState;
      let hookIdx = 0;

      while (hook && hookIdx < 30) {
        hookIdx++;
        const dispatch = hook.queue?.dispatch;
        const state = hook.memoizedState;

        if (dispatch && !clearedDispatches.has(dispatch)) {
          clearedDispatches.add(dispatch);

          // Array of objects (pilgrim list) — reset all entries to empty strings
          if (Array.isArray(state) && state.length > 0 &&
              typeof state[0] === "object" && state[0] !== null) {
            try {
              const emptyArr = state.map(item => {
                const cleared = {};
                for (const key of Object.keys(item)) {
                  cleared[key] = typeof item[key] === "number" ? 0 :
                                 typeof item[key] === "boolean" ? false : "";
                }
                return cleared;
              });
              dispatch(emptyArr);
              console.log("🧹 React array state cleared:", state.length, "items");
            } catch(e) {}
          }

          // Single object state — reset all string/number fields to ""
          else if (state && typeof state === "object" && !Array.isArray(state)) {
            try {
              const cleared = {};
              for (const key of Object.keys(state)) {
                cleared[key] = typeof state[key] === "number" ? 0 :
                               typeof state[key] === "boolean" ? false : "";
              }
              dispatch(cleared);
              console.log("🧹 React object state cleared:", Object.keys(state).join(", "));
            } catch(e) {}
          }

          // Plain string state
          else if (typeof state === "string" && state !== "") {
            try { dispatch(""); } catch(e) {}
          }
        }

        hook = hook.next;
      }

      fiber = fiber.return;
    }
  }

  // 🔥 React-safe native setters
  const inputSetter =
    Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    ).set;

  const textareaSetter =
    Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype,
      "value"
    ).set;

  const elements = document.querySelectorAll(
    "input, textarea, select, [contenteditable='true'], [role='textbox'], [role='combobox']"
  );

  elements.forEach(el => {

    if (el.disabled) return;

    const tag = el.tagName.toLowerCase();

    /* ================= INPUT ================= */
    if (tag === "input") {

      if (el.type === "radio" || el.type === "checkbox") {
        if (el.checked) {
          // For custom React checkboxes, click the label to uncheck
          const labelEl = el.closest("label") || el.labels?.[0];
          if (labelEl) {
            labelEl.click();
          } else {
            el.checked = false;
            el.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
      }

      else if (el.type === "file") {
        el.value = "";

        // 🔥 clear visible file name text
        const wrapper = el.closest("div");
        wrapper?.querySelectorAll("span").forEach(span => {
          if (span.innerText.includes(".")) {
            span.innerText = "";
          }
        });
      }

      else {

        // 🔥 SPECIAL CASE: readonly dropdown (React-controlled)
        if (el.readOnly) {

          // Method 1: React fiber — tries onChange, useState, useReducer
          reactFiberClear(el);

          // Method 2: Always also force DOM clear with native setter
          // React may still re-render, but combined with fiber clear it sticks
          el.readOnly = false;
          inputSetter.call(el, "");
          el.removeAttribute("value");
          el.dispatchEvent(new Event("input",  { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          el.blur();
          el.readOnly = true;

          document.body.click(); // close any open dropdown

        } else {
          inputSetter.call(el, "");
        }
      }


      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.blur();
    }

    /* ================= TEXTAREA ================= */
    else if (tag === "textarea") {
      textareaSetter.call(el, "");
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.blur();
    }

    /* ================= SELECT ================= */
    else if (tag === "select") {

      if (el.multiple) {
        Array.from(el.options).forEach(opt => opt.selected = false);
      } else {
        el.selectedIndex = 0;
      }

      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    /* ================= CONTENTEDITABLE ================= */
    else if (el.isContentEditable) {
      el.innerHTML = "";
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }

  });


  // 🔥 force remove value attribute from all readonly inputs
    document.querySelectorAll("input[readonly]").forEach(el => {
      el.removeAttribute("value");
    });

  // 🔥 close open dropdowns / calendars
  document.body.click();

  console.log("✅ Advanced Universal Clear Completed");
}


function highlightElement(el, duration = 1200) {
  if (!el) return;

  // save original styles
  const original = {
    outline: el.style.outline,
    boxShadow: el.style.boxShadow,
    background: el.style.backgroundColor,
    transition: el.style.transition
  };

  el.style.transition = "all 0.2s ease";
  el.style.outline = "3px solid #ff9800";       // orange border
  el.style.boxShadow = "0 0 12px #ff9800";      // glow
  el.style.backgroundColor = "rgba(255,152,0,0.15)";

  setTimeout(() => {
    el.style.outline = original.outline;
    el.style.boxShadow = original.boxShadow;
    el.style.backgroundColor = original.background;
    el.style.transition = original.transition;
  }, duration);
}


function sleep(ms) {
  const mult = window.__fillSpeed ?? 1.0;
  const actual = Math.round(ms * mult);
  return new Promise(r => setTimeout(r, actual));
}


/* ================= ACTION LOG (lean) =================
   Recorded: button clicks, date + slot picks, and every dropdown selection (label → chosen value);
   failures of any of these are flagged. Writes are fire-and-forget (the workflow never waits for
   them). Rows are batched into ONE storage write; clicks/dates are flushed at once because the
   page may navigate away right after them.
   ====================================================== */
let __logChain = Promise.resolve();
let __logBuf = [];
let __logTimer = null;
const __LOG_NOW = /^(click|add|next|submit|pickslot|date|select|checkall)$/;

// Stop flag — set to true by the popup when user clicks Stop; checked between every command
window.__OM_FILL_STOP = false;
window.__OM_FILL_RUNNING = false;

// ── OM API Capture — intercepts all fetch/XHR on TTD website ──
(function() {
  if (window.__OM_API_CAPTURE_ACTIVE) return;
  window.__OM_API_CAPTURE_ACTIVE = true;
  window.__OM_API_LOG = window.__OM_API_LOG || [];

  const TTD_HOST = 'ttdevasthanams.ap.gov.in';

  function logEntry(method, url, headers, body, response, status) {
    if (!url || !url.includes(TTD_HOST)) return;
    // only capture POST/PUT/PATCH — booking calls are never GET
    if (!/POST|PUT|PATCH/i.test(method)) return;
    const entry = {
      time: new Date().toISOString(),
      method: method.toUpperCase(),
      url,
      headers: {},
      body: body ? (typeof body === 'string' ? body : JSON.stringify(body)) : null,
      status,
      response: response ? response.slice(0, 3000) : null
    };
    // capture auth/token headers
    for (const [k, v] of Object.entries(headers || {})) {
      if (/auth|token|cookie|content|accept|x-/i.test(k)) entry.headers[k] = v;
    }
    window.__OM_API_LOG.push(entry);
    console.log('[OM API]', entry.method, entry.url, status);
    try {
      window.dispatchEvent(new CustomEvent('__OM_API_CAPTURED', { detail: entry }));
    } catch(e) {}
  }

  // Intercept fetch
  const _fetch = window.fetch;
  window.fetch = async function(input, init) {
    init = init || {};
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const method = init.method || 'GET';
    const headers = init.headers instanceof Headers
      ? Object.fromEntries(init.headers.entries())
      : (init.headers || {});
    const body = init.body;
    try {
      const res = await _fetch.apply(this, arguments);
      if (/POST|PUT|PATCH/i.test(method) && url.includes(TTD_HOST)) {
        res.clone().text().then(txt => logEntry(method, url, headers, body, txt, res.status)).catch(()=>{});
      }
      return res;
    } catch(e) {
      logEntry(method, url, headers, body, null, 'ERROR');
      throw e;
    }
  };

  // Intercept XHR
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  const _setHdr = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function(m, u) {
    this._om_m = m; this._om_u = u; this._om_h = {};
    return _open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.setRequestHeader = function(k, v) {
    if (this._om_h) this._om_h[k] = v;
    return _setHdr.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(body) {
    this.addEventListener('loadend', () => {
      logEntry(this._om_m, this._om_u, this._om_h, body, this.responseText, this.status);
    });
    return _send.apply(this, arguments);
  };
})();

function flushActionLog() {
  if (__logTimer) { clearTimeout(__logTimer); __logTimer = null; }
  const batch = __logBuf;
  __logBuf = [];
  if (!batch.length) return;
  __logChain = __logChain.then(() => new Promise(resolve => {
    try {
      chrome.storage.local.get("actionLog", res => {
        const log = (res?.actionLog || []).concat(batch);
        if (log.length > 60) log.splice(0, log.length - 60);
        chrome.storage.local.set({ actionLog: log }, () => { void chrome.runtime.lastError; resolve(); });
      });
    } catch (e) { resolve(); }   // extension was reloaded under an old tab — just skip logging
  }));
}

function recordAction(entry) {
  // `anysite` page: the first successful click/pick means the segment did its job — tell background right away
  // (before any navigation) so it stops re-trying this segment on later redirects.
  if (window.__anySiteRun && entry.status === "success" && /^(click|add|next|submit|pickslot|select)$/.test(entry.type)) {
    window.__anySiteRun = false;
    try { chrome.runtime.sendMessage({ type: "SEGMENT_DONE" }, () => void chrome.runtime.lastError); } catch (e) {}
  }
  __logBuf.push({ ...entry, time: Date.now(), url: location.href.split("?")[0] });
  if (__LOG_NOW.test(entry.type)) flushActionLog();
  else if (!__logTimer) __logTimer = setTimeout(flushActionLog, 250);
}
window.addEventListener("pagehide", flushActionLog);

// After a date / slot / click the page usually re-renders; for a short while a labelled field that is
// "not there yet" is waited for instead of being skipped (see fillByLabelSafe).
function markPageChanging(ms = 3000) {
  window.__pageMayChangeUntil = Date.now() + ms;
}

// Short readable name for a form field: its label / aria-label / placeholder / name
function fieldLabelOf(el) {
  const s = el.getAttribute?.("label") || el.labels?.[0]?.innerText || el.getAttribute?.("aria-label") ||
            el.placeholder || el.name || el.id || "field";
  return String(s).replace(/\s+/g, " ").replace(/\s*\*+\s*$/, "").trim().slice(0, 30);
}

// Fast disabled-button handling: click the moment it is enabled; if it is still disabled after a
// short grace period, give up (logged) — you fix the form and press Fill again.
const CLICK_ENABLE_WAIT_MS = 5000;   // wait up to 5 s for React to enable the button
let __clickFailReason = "";

function isBtnDisabled(btn) {
  return !!(btn.disabled || btn.getAttribute?.("aria-disabled") === "true");
}

async function waitBtnEnabled(btn, timeout = CLICK_ENABLE_WAIT_MS) {
  const end = Date.now() + timeout;
  while (isBtnDisabled(btn)) {
    if (Date.now() >= end) return false;
    await new Promise(r => setTimeout(r, 50));   // real time, not scaled by fill speed
  }
  return true;
}


function normalize(str) {
  return String(str || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// Split camelCase → words: "idNumber"→"id number", "idProofNumber"→"id proof number"
function splitCamel(str) {
  return String(str || "")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function wordMatch(fieldKey, labelText) {
  // Both plain + camelCase-split, so "idNumber" finds "Photo Id Number"
  const field = normalize(fieldKey) + " " + splitCamel(fieldKey);
  const label = splitCamel(labelText);

  const SKIP = new Set(["a", "an", "the", "of", "in", "on", "at", "to", "is"]);
  const words = label.split(" ").filter(w => w.length >= 2 && !SKIP.has(w));

  if (!words.length) return false;

  return words.every(word => field.includes(word));
}




async function waitUntilEnabled(el, timeout = 4000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    if (!el.disabled) return true;
    await sleep(100);
  }
  return false;
}

function clickAnyClickableIcon(keyword) {
  const el = [...document.querySelectorAll("img, div, span")]
    .find(e =>
      normalize(e.innerText || e.alt || e.src || "")
        .includes(normalize(keyword)) &&
      getComputedStyle(e).cursor === "pointer"
    );

  if (!el) return false;

  el.scrollIntoView({ block: "center" });
  el.click();
  return true;
}




/* ================= RADIO ================= */

/* ================= RADIO BUTTONS =================
   Slot time (and similar) is often a group of radio buttons whose own labels are just the options
   ("10:00 AM", "03:00 PM"); the field name ("Slot time") is a heading above them.
   ================================================== */

// Text of ONE radio option: its label, aria-label, sibling text, short parent text, or value
function radioText(r) {
  let t = r.labels?.[0]?.innerText || r.closest("label")?.innerText || r.getAttribute("aria-label") || "";
  if (!t && r.nextElementSibling) t = r.nextElementSibling.innerText || "";
  if (!t && r.parentElement) {
    const pt = (r.parentElement.innerText || "").trim();
    if (pt.length <= 40) t = pt;
  }
  return String(t || r.value || "").replace(/\s+/g, " ").trim();
}

function radioEnabled(r) {
  return !r.disabled && r.getAttribute("aria-disabled") !== "true";
}

// The radios that belong with `r`: same name, else the nearest wrapper holding several radios
function radioGroupOf(r) {
  if (r.name) {
    const same = [...document.querySelectorAll('input[type="radio"]')].filter(x => x.name === r.name);
    if (same.length) return same;
  }
  let node = r.parentElement;
  for (let d = 0; d < 5 && node; d++, node = node.parentElement) {
    const g = [...node.querySelectorAll('input[type="radio"]')];
    if (g.length >= 2) return g;
  }
  return [r];
}

// Radio group sitting under a heading that matches `label` (e.g. "Slot time")
function radioGroupByHeading(label, used) {
  const want = normalize(String(label || "").replace(/\s*\*+\s*$/, ""));
  if (!want) return null;
  const heads = [...document.querySelectorAll("legend, label, h1, h2, h3, h4, h5, h6, p, span, div, strong, b")]
    .filter(el => {
      if (el.querySelector("input")) return false;                       // a wrapper, not a heading
      const own = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join(" ");
      const txt = normalize(own || el.innerText || "");
      return txt && txt.length <= want.length + 14 && txt.includes(want);
    });
  for (const h of heads) {
    let node = h.parentElement;
    for (let d = 0; d < 4 && node; d++, node = node.parentElement) {
      const radios = [...node.querySelectorAll('input[type="radio"]')];
      if (radios.length < 2) continue;
      const first = radios.find(r => h.compareDocumentPosition(r) & 4);   // first radio AFTER the heading
      if (!first) continue;
      const grp = radioGroupOf(first);
      if (used && used.has(grp[0])) break;                                // same heading text, later group (e.g. 2nd pilgrim)
      return grp;
    }
  }
  return null;
}

// Select a radio the way a user would (label click for hidden/custom radios), verify, fall back
async function clickRadio(r) {
  const labelEl = r.labels?.[0] || r.closest("label");
  const visible = r.offsetParent !== null && r.getBoundingClientRect().width > 0;
  r.scrollIntoView?.({ block: "center" });
  universalClick(labelEl && !visible ? labelEl : r);
  await sleep(60);
  if (!r.checked && labelEl) { universalClick(labelEl); await sleep(60); }
  if (!r.checked) {
    r.checked = true;
    r.dispatchEvent(new Event("input",  { bubbles: true }));
    r.dispatchEvent(new Event("change", { bubbles: true }));
  }
  return r.checked;
}

// Choose the right option in a radio group for `value` (exact / "03:00 PM" ≈ "3:00 PM" / a time RANGE) and click it
async function fillRadioGroup(group, label, value) {
  const name = String(label || "radio").replace(/\s*\*+\s*$/, "").trim().slice(0, 30);
  const options = group.filter(radioEnabled).map(r => ({ r, text: radioText(r) }));
  const hit = pickOption(options, value, it => it.text) || pickOption(options, value, it => it.r.value || "");

  if (!hit) {
    const spec = parseTimeRangeSpec(value);
    console.warn("❌ radio: no option for", value, "in", name, "| options:", options.map(o => o.text));
    recordAction({
      type: "radio", value: `${name} = ${value}`, status: "failed",
      reason: spec ? "no_slot_in_range" : "no_option",
      detail: spec ? describeSlotsFound(options, o => o.text)
                   : "options: " + (options.map(o => o.text).filter(Boolean).slice(0, 8).join(", ") || "none enabled")
    });
    return false;
  }

  if (hit.r.checked) {
    recordAction({ type: "radio", value: `${name} → ${hit.text.slice(0, 30)}`, status: "success", detail: "already selected" });
    return true;
  }
  const ok = await clickRadio(hit.r);
  console.log(ok ? "✅ radio:" : "⚠️ radio clicked but not checked:", name, "→", hit.text);
  recordAction({ type: "radio", value: `${name} → ${hit.text.slice(0, 30)}`, status: ok ? "success" : "failed",
                 reason: ok ? undefined : "not_checked" });
  return ok;
}

// Order-mode radio (no label available): search every radio on the page
function fillRadio(value) {
  const target = normalize(value);
  const radios = [...document.querySelectorAll('input[type="radio"]')].filter(radioEnabled);
  const spec = parseTimeRangeSpec(value);

  const radio =
    radios.find(r => normalize(r.value) === target) ||
    radios.find(r => normalize(r.value).includes(target)) ||
    radios.find(r =>
      normalize(r.closest("label")?.innerText || "").includes(target)
    ) ||
    radios.find(r =>
      r.nextElementSibling &&
      normalize(r.nextElementSibling.innerText).includes(target)
    ) ||
    // leading-zero tolerant fallbacks ("03:00 PM" vs "3:00 PM")
    radios.find(r => looseTextMatch(r.value, value)) ||
    radios.find(r => looseTextMatch(r.closest("label")?.innerText || "", value)) ||
    radios.find(r => r.nextElementSibling && looseTextMatch(r.nextElementSibling.innerText, value)) ||
    radios.find(r => looseTextMatch(radioText(r), value)) ||
    // time window ("between 11:00 AM and 06:00 PM") → earliest available slot inside it
    (spec ? pickSlotInRange(radios.map(r => ({ r, text: radioText(r) })), spec, o => o.text)?.r : null);

  if (!radio) {
    recordAction({ type: "radio", value: `radio = ${value}`, status: "failed", reason: spec ? "no_slot_in_range" : "no_option",
                   detail: spec ? describeSlotsFound(radios.map(r => ({ text: radioText(r) })), o => o.text) : undefined });
    return false;
  }

  const labelEl = radio.labels?.[0] || radio.closest("label");
  const visible = radio.offsetParent !== null && radio.getBoundingClientRect().width > 0;
  radio.focus();
  radio.checked = true;
  radio.dispatchEvent(new Event("input",  { bubbles: true }));
  radio.dispatchEvent(new Event("change", { bubbles: true }));
  radio.click();
  if (labelEl && !visible) universalClick(labelEl);        // hidden custom radio: the label is what the site listens to
  recordAction({ type: "radio", value: `radio → ${radioText(radio).slice(0, 30)}`, status: "success" });
  return true;
}

/* ================= FAKE DROPDOWN ================= */

async function fillFakeDropdown(input, value, label) {
  if (!input || !value) return false;

  const fieldName = String(label || fieldLabelOf(input)).replace(/\s*\*+\s*$/, "").trim().slice(0, 30);

  const target = normalize(value);

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  const rangeSpec = parseTimeRangeSpec(value);   // e.g. "between 11:00 AM and 06:00 PM"

  // ── Step 0: If input already has this value, skip (nothing to do) ──
  if (normalize(input.value) === target || smartNormalizeValue(input.value) === smartNormalizeValue(value)) {
    console.log("⏭️ fillFakeDropdown: already set to", value);
    recordAction({ type: "dropdown", value: `${fieldName} → ${String(input.value).trim()}`, status: "success", detail: "already set" });
    return true;
  }
  // …or already holds a time that is inside the requested window
  if (rangeSpec) {
    const cur = firstClockIn(input.value);
    if (cur !== null && cur >= rangeSpec.from && cur <= rangeSpec.to) {
      console.log("⏭️ fillFakeDropdown: current time already inside range:", input.value);
      recordAction({ type: "dropdown", value: `${fieldName} → ${String(input.value).trim()}`, status: "success", detail: "already inside the time range" });
      return true;
    }
  }

  // ── Step 0b: If input has a DIFFERENT existing value, clear via React fiber first ──
  // This forces React to acknowledge the change when we select the new option
  if (input.value.trim() !== "") {
    reactFiberClear(input);
    // Also clear DOM value so React sees a real change
    const setter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, "value"
    )?.set;
    if (setter) {
      input.readOnly = false;
      setter.call(input, "");
      input.dispatchEvent(new Event("input",  { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.readOnly = true;
    }
    await sleep(80);
  }

  // ── Step 1: Check if dropdown is ALREADY open (items already in DOM) ──
  // This handles the case where a previous interaction left the dropdown open,
  // or the site PRE-RENDERS options on page load (absolutely-positioned portals).
  // MutationObserver won't see already-existing nodes — must check BEFORE clicking.
  const inputContainer = input.closest('[style*="position: relative"]') || input.parentElement;

  function getVisibleOptions(scope) {
    return [...(scope || document).querySelectorAll('li, [role="option"]')]
      .filter(el => isVisible(el) && (el.innerText || "").trim().length > 0);
  }

  // ── Check container first, then fall back to whole document ──
  // Absolutely-positioned dropdown portals live outside inputContainer in the DOM,
  // so a global check catches pre-rendered dropdowns that container-scope misses.
  let preExisting = getVisibleOptions(inputContainer);
  if (preExisting.length === 0) {
    // Global check: find li/option elements near this input
    // Filter to those that are spatially close (within 400px) to avoid unrelated lists
    const inputRect = input.getBoundingClientRect();
    const globalOptions = getVisibleOptions(document);
    const nearby = globalOptions.filter(el => {
      const r = el.getBoundingClientRect();
      return Math.abs(r.top - inputRect.bottom) < 400 ||
             Math.abs(r.top - inputRect.top) < 400;
    });
    if (nearby.length > 0) preExisting = nearby;
  }

    // If already found visible options → use them directly, skip click/observer
  if (preExisting.length > 0) {
    const target = normalize(value);
    const smartTarget = smartNormalizeValue(value);
    let matched = null;

    // Pass 1: exact normalized match
    for (const li of preExisting) {
      if (normalize(li.innerText || "").trim() === target) { matched = li; break; }
    }

    // Pass 2: smart match — handles "2" vs "02", "3:00 pm" vs "03:00 PM"
    if (!matched) {
      for (const li of preExisting) {
        if (smartNormalizeValue(li.innerText || "") === smartTarget) { matched = li; break; }
      }
    }

    // Pass 2b: leading-zero tolerant ("03:00 PM" vs "3:00 PM - 4:00 PM")
    if (!matched) {
      for (const li of preExisting) {
        if (looseTextMatch(li.innerText || "", value)) { matched = li; break; }
      }
    }

    // Pass 2c: time range ("between 11:00 AM and 06:00 PM") → earliest available slot inside it
    if (!matched && rangeSpec) matched = pickSlotInRange(preExisting, rangeSpec, li => li.innerText || "");

    // Pass 3: substring fallback (skip for pure numbers to avoid "2" matching "12")
    if (!matched && !/^\d+$/.test(target)) {
      for (const li of preExisting) {
        if (normalize(li.innerText || "").includes(target)) { matched = li; break; }
      }
    }
    if (matched) {
      matched.scrollIntoView({ block: "nearest" });
      matched.dispatchEvent(new MouseEvent("mouseover",  { bubbles: true }));
      matched.dispatchEvent(new MouseEvent("mousedown",  { bubbles: true, cancelable: true }));
      matched.dispatchEvent(new MouseEvent("mouseup",    { bubbles: true, cancelable: true }));
      matched.dispatchEvent(new MouseEvent("click",      { bubbles: true, cancelable: true }));
      await sleep(80);
      if (!input.value.trim()) nativeSet(input, matched.innerText.trim());
      input.dispatchEvent(new Event("blur", { bubbles: true }));
      console.log("✅ fillFakeDropdown (pre-rendered):", input.getAttribute("label") || input.name, "→", matched.innerText.trim());
      recordAction({ type: "dropdown", value: `${fieldName} → ${matched.innerText.trim().slice(0, 30)}`, status: "success" });
      return true;
    }
    // No match in pre-existing options — close and reopen below
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    await sleep(80);
    preExisting = [];
  }

  // ── Step 2: Open the dropdown via MutationObserver + click ──
  const existingOptions = new Set(document.querySelectorAll('li, [role="option"]'));

  const newOptions = await new Promise(resolve => {
    const found = [];
    let resolved = false;

    const observer = new MutationObserver(() => {
      const allNow = document.querySelectorAll('li, [role="option"]');
      for (const el of allNow) {
        if (!existingOptions.has(el) && isVisible(el)) {
          found.push(el);
        }
      }
      if (found.length > 0) {
        observer.disconnect();
        resolved = true;
        resolve(found);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    input.scrollIntoView({ block: "center" });
    input.focus();
    input.click();

    setTimeout(() => {
      if (!resolved) {
        observer.disconnect();
        resolve([]);
      }
    }, 800);
  });

  // ── Step 3: If click didn't work, try mousedown ──
  let liItems = newOptions;

  if (liItems.length === 0) {
    const afterClick = getVisibleOptions(inputContainer);
    if (afterClick.length > 0) {
      liItems = afterClick;
    } else if (preExisting.length > 0) {
      liItems = preExisting;
    } else {
      const existingAfterClick = new Set(document.querySelectorAll('li, [role="option"]'));
      liItems = await new Promise(resolve => {
        const found = [];
        let resolved = false;
        const observer = new MutationObserver(() => {
          const allNow = document.querySelectorAll('li, [role="option"]');
          for (const el of allNow) {
            if (!existingAfterClick.has(el) && isVisible(el)) found.push(el);
          }
          if (found.length > 0) {
            observer.disconnect();
            resolved = true;
            resolve(found);
          }
        });
        observer.observe(document.body, { childList: true, subtree: true });
        input.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
        input.dispatchEvent(new MouseEvent("mouseup",   { bubbles: true, cancelable: true }));
        setTimeout(() => {
          if (!resolved) { observer.disconnect(); resolve([]); }
        }, 500);
      });
    }
  }

  // ── Step 4: Find the matching option ──
  let matched = null;

  // Priority 1: exact match (always preferred, critical for numbers like "2" vs "12")
  for (const li of liItems) {
    const text = normalize(li.innerText || "").trim();
    if (text === target) { matched = li; break; }
  }

  // Priority 1b: smart match — "2" vs "02", "3:00 pm" vs "03:00 PM"
  if (!matched) {
    const smartTarget = smartNormalizeValue(value);
    for (const li of liItems) {
      if (smartNormalizeValue(li.innerText || "") === smartTarget) { matched = li; break; }
    }
  }

  // Priority 1c: leading-zero tolerant ("03:00 PM" vs "3:00 PM - 4:00 PM")
  if (!matched) {
    for (const li of liItems) {
      if (looseTextMatch(li.innerText || "", value)) { matched = li; break; }
    }
  }

  // Priority 1d: time range ("between 11:00 AM and 06:00 PM") → earliest available slot inside it
  if (!matched && rangeSpec) matched = pickSlotInRange(liItems, rangeSpec, li => li.innerText || "");

  // Priority 2: partial match — only if target is NOT a pure number
  // Prevents "2" from matching "12", "20", "2 items" etc.
  if (!matched && !/^\d+$/.test(target)) {
    for (const li of liItems) {
      const text = normalize(li.innerText || "");
      if (text.includes(target)) { matched = li; break; }
    }
  }

  if (!matched) {
    console.warn("❌ fillFakeDropdown: no option found for:", JSON.stringify(value), "→", looseNorm(value),
      "| options:", liItems.map(l => JSON.stringify(l.innerText) + " → " + looseNorm(l.innerText)));
    recordAction({
      type: "dropdown",
      value: `${fieldName} = ${value}`,
      status: "failed",
      reason: rangeSpec ? "no_slot_in_range" : "no_option",
      detail: rangeSpec ? describeSlotsFound(liItems, li => li.innerText || "") : undefined
    });
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    return false;
  }

  // ── Step 5: Click the matched option ──
  matched.scrollIntoView({ block: "nearest" });
  matched.dispatchEvent(new MouseEvent("mouseover",  { bubbles: true }));
  matched.dispatchEvent(new MouseEvent("mousedown",  { bubbles: true, cancelable: true }));
  matched.dispatchEvent(new MouseEvent("mouseup",    { bubbles: true, cancelable: true }));
  matched.dispatchEvent(new MouseEvent("click",      { bubbles: true, cancelable: true }));

  await sleep(80);   // reduced from 300ms

  // ── Step 6: Fallback — force input value if site didn't update it ──
  if (!input.value.trim()) {
    nativeSet(input, matched.innerText.trim());
  }

  input.dispatchEvent(new Event("blur", { bubbles: true }));
  console.log("✅ fillFakeDropdown:", input.getAttribute("label") || input.name, "→", input.value);
  recordAction({ type: "dropdown", value: `${fieldName} → ${String(input.value || matched.innerText).trim().slice(0, 30)}`, status: "success" });

  // Wait for React to re-render after selection before processing next field
  await sleep(60);
  return true;
}


function getFieldKey(el) {
  return (
    el.name ||
    el.id ||
    el.getAttribute("aria-label") ||
    el.placeholder ||
    el.type
  );
}



async function waitForDropdownOptions(timeout = 3000) {
  const end = Date.now() + timeout;

  while (Date.now() < end) {
    const options = [...document.querySelectorAll("div, li, span")]
      .filter(el => el.offsetParent && el.innerText.trim().length > 0);

    if (options.length > 3) return true;

    await new Promise(r => setTimeout(r, 200));
  }

  return false;
}



function findDropdownOption(value) {
  const target = normalize(value);

  return [...document.querySelectorAll("div, li, span")]
    .find(el =>
      el.offsetParent &&
      normalize(el.innerText).includes(target)
    );
}


function isElementInViewport(el) {
  const rect = el.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
  );
}



function waitForNewDropdown(timeout = 2000) {
  return new Promise(resolve => {

    const existing = new Set(
      [...document.querySelectorAll("body *")]
    );

    const observer = new MutationObserver(() => {

      const candidates = [...document.querySelectorAll("body *")]
        .filter(el =>
          !existing.has(el) &&
          el.offsetParent &&
          el.innerText &&
          el.innerText.trim().length > 0
        );

      const dropdown = candidates.find(el =>
        el.querySelectorAll("*").length >= 2
      );

      if (dropdown) {
        observer.disconnect();
        resolve(dropdown);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, timeout);
  });
}


function wordMatchScore(labelA, labelB) {
  const wordsA = normalize(labelA).match(/[a-z0-9]+/g) || [];
  const wordsB = normalize(labelB).match(/[a-z0-9]+/g) || [];

  let score = 0;

  for (const wA of wordsA) {
    for (const wB of wordsB) {
      if (wA === wB && wA.length > 2) {
        score++;
      }
    }
  }

  return score;
}





  async function fillByLabelSafe(valuesWithLabels) {

  // fields list is rebuilt dynamically inside findFieldByLabel
  // to handle dynamically rendered DOM sections
  let pointer = 0;
  const usedRadioGroups = new Set();     // first radio of each group already filled (repeated labels, e.g. 2nd pilgrim)

  for (const item of valuesWithLabels) {

    if (!item || !item.label) continue;

    const label = item.label;
    const value = item.value ?? "";

    let field = null;

    // Helper: build candidates for a field element
    function getCandidates(el) {
      const realLabel = el.labels?.[0]?.innerText?.trim() || "";

      // Walk up ancestors — collect own text AND preceding sibling text
      let ancestorLabel = "";
      let siblingLabel  = "";
      let node = el.parentElement;

      for (let d = 0; d < 6 && node; d++) {
        // Own text nodes of this ancestor
        const ownText = [...node.childNodes]
          .filter(n => n.nodeType === Node.TEXT_NODE)
          .map(n => n.textContent.trim())
          .filter(Boolean)
          .join(" ");
        if (ownText.length > 1 && ownText.length < 80 && !ancestorLabel) {
          ancestorLabel = ownText;
        }

        // Preceding siblings — look for label-like text
        let sib = node.previousElementSibling;
        while (sib && !siblingLabel) {
          const sibText = (sib.innerText || "").trim();
          if (sibText.length > 1 && sibText.length < 100 &&
              !sib.querySelector("input, select, textarea")) {
            siblingLabel = sibText;
          }
          sib = sib.previousElementSibling;
        }

        // Following siblings — catches <label> AFTER the input
        // e.g. <input><label class="field-label">Enter VPA ID</label>
        if (!siblingLabel) {
          let nextSib = node.nextElementSibling;
          while (nextSib && !siblingLabel) {
            const sibText = (nextSib.innerText || "").trim();
            if (sibText.length > 1 && sibText.length < 100 &&
                !nextSib.querySelector("input, select, textarea") &&
                (nextSib.tagName === "LABEL" ||
                 nextSib.classList.contains("field-label") ||
                 nextSib.classList.contains("label") ||
                 sibText.split(" ").length <= 6)) {
              siblingLabel = sibText;
            }
            nextSib = nextSib.nextElementSibling;
          }
        }

        if (ancestorLabel && siblingLabel) break;
        node = node.parentElement;
      }

      // Fieldset legend — for grouped radio/checkboxes inside <fieldset>
      const legendText = el.closest("fieldset")?.querySelector("legend")?.innerText?.trim() || "";

      return [
        el.getAttribute("label"),
        el.getAttribute("aria-label"),
        el.getAttribute("aria-labelledby") &&
          document.getElementById(el.getAttribute("aria-labelledby"))?.innerText,
        el.getAttribute("placeholder"),
        el.getAttribute("name"),
        el.getAttribute("id"),
        realLabel,
        legendText,
        ancestorLabel,
        siblingLabel
      ].filter(Boolean);
    }

    // Helper: scan all current fields for a label match
    function findFieldByLabel(lbl, startFrom = 0) {
      const allFields = [
        ...document.querySelectorAll("input, textarea, select")
      ].filter(el =>
        el.type !== "hidden" &&
        el.type !== "submit" &&
        el.type !== "button" &&
        el.type !== "file" &&
        el.offsetParent !== null
      );

      // Pass 1: forward from startFrom
      for (let i = startFrom; i < allFields.length; i++) {
        if (getCandidates(allFields[i]).some(c => wordMatch(c, lbl))) {
          return { field: allFields[i], index: i };
        }
      }
      // Pass 2: full scan (catches fields before pointer — e.g. checkboxes)
      for (let i = 0; i < startFrom; i++) {
        if (getCandidates(allFields[i]).some(c => wordMatch(c, lbl))) {
          return { field: allFields[i], index: i };
        }
      }
      return null;
    }

    // Smart wait: only wait if DOM is still changing — stable page = skip immediately
    let found = findFieldByLabel(label, pointer);
    const hasRadios = () => !!document.querySelector('input[type="radio"]');
    let radioGrp = null;    // radio group found by its heading (inputs themselves carry no such label)

    if (!found) {
      const snapBefore = document.querySelectorAll("input,select,textarea").length;
      await sleep(120);
      const snapAfter = document.querySelectorAll("input,select,textarea").length;
      if (snapAfter !== snapBefore) {
        const deadline = Date.now() + 2000;
        while (!found && Date.now() < deadline) {
          await sleep(50);
          found = findFieldByLabel(label, pointer);
        }
      }
    }
    if (!found && hasRadios()) radioGrp = radioGroupByHeading(label, usedRadioGroups);

    // Just after a date / slot / click the page is still rendering (e.g. "Number of tickets" appears a
    // moment after the date is picked). Keep looking until that short window closes, then skip.
    if (!found && !radioGrp && Date.now() < (window.__pageMayChangeUntil || 0)) {
      const until = window.__pageMayChangeUntil;
      while (!found && !radioGrp && Date.now() < until) {
        await new Promise(r => setTimeout(r, 100));      // real time — the page is rendering, not us
        found = findFieldByLabel(label, pointer);
        if (!found && hasRadios()) radioGrp = radioGroupByHeading(label, usedRadioGroups);
      }
    }

    if (found) {
      field = found.field;
      // Only advance pointer if field was found at or after current position
      if (found.index >= pointer) pointer = found.index + 1;
    }

    if (!field) {
      // A radio group has a heading ("Slot time") but often no input that carries that name
      if (radioGrp) {
        usedRadioGroups.add(radioGrp[0]);
        await fillRadioGroup(radioGrp, label, value);
      }
      continue;
    }

    // Radio buttons: pick the matching option inside the group (never write text into a radio)
    if (field.type === "radio") {
      let grp = radioGroupOf(field);
      if (usedRadioGroups.has(grp[0])) {
        // that group was already filled by an earlier label — this label means the NEXT group
        const next = radioGroupByHeading(label, usedRadioGroups);
        if (next) grp = next;
      }
      usedRadioGroups.add(grp[0]);
      await fillRadioGroup(grp, label, value);
      // move the pointer past this whole group so the next label cannot land inside it again
      const visible = [...document.querySelectorAll("input, textarea, select")].filter(el =>
        el.type !== "hidden" && el.type !== "submit" && el.type !== "button" && el.type !== "file" && el.offsetParent !== null);
      const last = Math.max(...grp.map(r => visible.indexOf(r)));
      if (last >= pointer) pointer = last + 1;
      continue;
    }

    // Skip if already correct value (dropdowns still get a log row so the tickets/slot value shows)
    if (normalize(field.value) === normalize(value)) {
      if (field.readOnly || field.tagName === "SELECT") {
        recordAction({ type: "dropdown", value: `${String(label).replace(/\s*\*+\s*$/, "").trim().slice(0, 30)} → ${String(field.value).trim().slice(0, 30)}`, status: "success", detail: "already set" });
      }
      continue;
    }

    // ── CHECKBOX ──
    if (field.type === "checkbox") {
      const v = normalize(value);
      const check = v === "yes" || v === "true" || v === "1" || v === "checked" || v === "on";
      if (field.checked !== check) {
        // For custom styled checkboxes (React/CSS), click the <label> wrapper
        // which triggers the framework's synthetic event system.
        // Setting .checked directly on a hidden input doesn't trigger React state.
        const labelEl = field.closest("label") || field.labels?.[0];
        if (labelEl) {
          universalClick(labelEl);
        } else {
          // Fallback: direct input manipulation
          field.checked = check;
          field.dispatchEvent(new Event("input",  { bubbles: true }));
          field.dispatchEvent(new Event("change", { bubbles: true }));
          field.click();
        }
      }
      continue;
    }

    // ── READONLY FAKE DROPDOWN ──
    if (field.readOnly) {
      await fillFakeDropdown(field, value, label);
      continue;
    }

    // ── NATIVE SELECT ──
    if (field.tagName === "SELECT") {
      const opt = pickOption([...field.options], value);
      if (opt) {
        field.value = opt.value;
        field.dispatchEvent(new Event("change", { bubbles: true }));
        recordAction({ type: "dropdown", value: `${label} → ${opt.text.trim().slice(0, 30)}`, status: "success" });
      } else {
        recordAction({ type: "dropdown", value: `${label} = ${value}`, status: "failed", reason: "no_option" });
      }
      continue;
    }

    // ── DISABLED — wait then fill ──
    if (field.disabled) {
      const ok = await waitUntilEnabled(field, 8000);
      if (ok) {
        field.focus();
        nativeSet(field, value);
        field.blur();
      }
      continue;
    }

    // ── TEXT / TEXTAREA ──
    field.focus();
    nativeSet(field, value);
    field.blur();
  }
}


async function fillInOrder(values, repeatMode = false) {
  if (!Array.isArray(values) || values.length === 0) return;

  const usedNames = {};
  const fields = [...document.querySelectorAll("input, textarea, select")]
    .filter(el =>
      el.type !== "hidden" &&
      el.type !== "submit" &&
      el.type !== "button" &&
      el.type !== "file"
    );

  let index = 0;

  for (const el of fields) {
    const fieldKey = getFieldKey(el);

    let valueIndex;
    if (repeatMode && usedNames[fieldKey] !== undefined) {
      valueIndex = usedNames[fieldKey];
    } else {
      valueIndex = index;
    }

    const value = values[valueIndex];
    if (value === undefined) continue;

    if (el.disabled) {
      const ok = await waitUntilEnabled(el);
      if (!ok) continue;
    }

    let consumed = false;


    /* ========= CHECKBOX ========= */
      if (el.type === "checkbox") {

        const val = normalize(value);

        const shouldCheck =
          val === "yes" ||
          val === "true" ||
          val === "1" ||
          val === "checked" ||
          val === "on";

        if (el.checked !== shouldCheck) {
          const labelEl = el.closest("label") || el.labels?.[0];
          if (labelEl) {
            universalClick(labelEl);
          } else {
            el.checked = shouldCheck;
            el.dispatchEvent(new Event("input",  { bubbles: true }));
            el.dispatchEvent(new Event("change", { bubbles: true }));
            el.click();
          }
        }

        consumed = true;
      }



    /* ========= 1️⃣ READONLY (FAKE DROPDOWN) ========= */
    if (el.tagName === "INPUT" && el.readOnly) {
      await fillFakeDropdown(el, value);
      consumed = true;
    }

    /* ========= 2️⃣ RADIO ========= */
    else if (el.type === "radio") {
      if (fillRadio(value)) {
        consumed = true;
      }
    }

    /* ========= 3️⃣ SELECT ========= */
    else if (el.tagName === "SELECT") {
      const opt = pickOption([...el.options], value);

      if (opt) {
        el.value = opt.value;
        el.dispatchEvent(new Event("change", { bubbles: true }));
        recordAction({ type: "dropdown", value: `${fieldLabelOf(el)} → ${opt.text.trim().slice(0, 30)}`, status: "success" });
      } else {
        recordAction({ type: "dropdown", value: `${fieldLabelOf(el)} = ${value}`, status: "failed", reason: "no_option" });
      }

      consumed = true; // 🔑 ALWAYS consume (match or not)
    }

    /* ========= 4️⃣ TEXT / TEXTAREA ========= */
    else {
      el.focus();
      nativeSet(el, value);
      el.blur();
      consumed = true;
    }

    if (consumed) {
      if (!repeatMode) index++;
      usedNames[fieldKey] = valueIndex;
    }
  }
}

function angularSafeClick(el) {
  // Kept for backward compat — delegates to universalClick
  return universalClick(el);
}


function findButtonByText(text, cheap = false) {
  // Support "buttonName 2nd" / "buttonName 3rd" → pick Nth match
  const ordinalMatch = text.match(/^(.+?)\s+(\d+)(?:st|nd|rd|th)\s*$/i);
  const searchText = ordinalMatch ? ordinalMatch[1].trim() : text;
  const pickIndex = ordinalMatch ? parseInt(ordinalMatch[2], 10) - 1 : 0;

  const target = normalize(searchText);

  // For short dialog words (ok, yes, no, cancel, confirm, close, done) —
  // search inside visible dialog/modal containers FIRST to avoid matching
  // nav menus, headers, or other page elements with the same short word.
  const isDialogWord = /^(ok|okay|yes|no|cancel|close|done)$/.test(target);
  // For "continue" — if the TTD instruction modal is open, click its button directly
  if (target === "continue") {
    const modalBtn = document.querySelector(".instruction_continue-btn___TZEU");
    if (modalBtn && modalBtn.offsetParent) return modalBtn;
    // Also check for any visible dialog Continue button
    const dialogSelectors = ["[role='dialog']","[class*='dialog']","[class*='Dialog']","[class*='modal']","[class*='Modal']","[class*='popup']","[class*='DialogBox']"];
    for (const sel of dialogSelectors) {
      const containers = [...document.querySelectorAll(sel)].filter(el => el.offsetParent);
      for (const container of containers) {
        const btn = [...container.querySelectorAll("button")].find(b => b.offsetParent && normalize(b.innerText || "").includes("continue"));
        if (btn) return btn;
      }
    }
  }
  if (isDialogWord) {
    const dialogSelectors = [
      "[role='dialog']", "[class*='dialog']", "[class*='Dialog']",
      "[class*='modal']", "[class*='Modal']", "[class*='popup']",
      "[class*='Popup']", "[class*='DialogBox']", "[class*='alert']"
    ];
    for (const sel of dialogSelectors) {
      const containers = [...document.querySelectorAll(sel)]
        .filter(el => el.offsetParent);
      for (const container of containers) {
        const btn = [...container.querySelectorAll("button, input[type=button], input[type=submit]")]
          .find(b => b.offsetParent && (normalize(b.innerText || b.value || "").includes(target)));
        if (btn) return btn;
      }
    }
  }

  // 1️⃣ Standard button/link elements — for short words, only match buttons not nav/menu items
  const NAV_SELECTOR = "nav, header, [class*='header'], [class*='nav'], [class*='menu'], [class*='sub-header'], [class*='topbar'], [class*='navbar']";
  const standardMatches = [...document.querySelectorAll(
    "button, input[type=button], input[type=submit], [role='button']" +
    (isDialogWord ? "" : ", a")
  )].filter(btn => {
    // Always skip nav/header/menu elements — prevents eBooks and other nav items being clicked
    if (btn.closest(NAV_SELECTOR)) return false;
    const label =
      btn.innerText ||
      btn.value ||
      btn.getAttribute("aria-label") ||
      [...btn.querySelectorAll("span")].map(s => s.innerText).join(" ");
    return normalize(label).includes(target) || looseTextMatch(label, searchText);
  });

  if (standardMatches[pickIndex]) return standardMatches[pickIndex];
  if (standardMatches[0]) return standardMatches[0];

  // cheap mode: only real buttons/links. The card/div scan below calls getComputedStyle on every
  // div/span on the page — content scripts share the page's main thread, so doing that every poll
  // can slow the very page we are waiting on.
  if (cheap) return null;

  // 2️⃣ Clickable cards / divs (cursor:pointer elements with matching text)
  // Handles slot cards, tab panels, custom UI cards etc.
  // Always skips nav/header/menu elements to prevent accidental nav clicks.
  const clickableMatches = [...document.querySelectorAll("div, span, td, article, section")]
    .filter(el => {
      if (!el.getBoundingClientRect().width) return false;          // not visible
      if (el.querySelectorAll("div, p, span").length > 20) return false; // skip large containers
      if (el.closest(NAV_SELECTOR)) return false;                   // never click nav elements

      const isClickable =
        getComputedStyle(el).cursor === "pointer" ||
        el.getAttribute("onclick") ||
        el.getAttribute("tabindex") !== null;

      if (!isClickable) return false;

      return normalize(el.innerText || "").includes(target) || looseTextMatch(el.innerText || "", searchText);
    });

  return clickableMatches[pickIndex] || clickableMatches[0] || null;
}

// Waits for a button to appear (page/JS may render it late). Accepts one text or a list;
// tries all texts on every poll so a fallback ("continue") doesn't add a second full wait.
async function findButtonByTextWithWait(texts, timeout = 5000) {
  const list = Array.isArray(texts) ? texts : [texts];
  const end = Date.now() + timeout;
  for (let i = 0; ; i++) {
    const full = (i % 7 === 0);            // full (card/div) scan on 1st poll, then about once a second
    for (const t of list) {
      const btn = findButtonByText(t, !full);
      if (btn) return btn;
    }
    if (Date.now() >= end) return null;
    await sleep(150);
  }
}



function findFileInputByLabel(labelText) {
  const target = normalize(labelText);

  const label = [...document.querySelectorAll("label")]
    .find(l => normalize(l.innerText).includes(target));

  if (label) {
    const id = label.getAttribute("for");
    if (id) return document.getElementById(id);
  }

  return [...document.querySelectorAll('input[type="file"]')]
    .find(inp =>
      normalize(inp.closest("div")?.innerText).includes(target)
    );
}






async function uploadFile(input, filePath) {
  const res = await fetch(filePath);
  const blob = await res.blob();

  const name = filePath.split("/").pop();
  const file = new File([blob], name, { type: blob.type });

  const dt = new DataTransfer();
  dt.items.add(file);

  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
}


function logAction(msg, data) {
  const time = new Date().toLocaleTimeString();
  if (data !== undefined) {
    console.log(`🧪 [${time}] ${msg}`, data);
  } else {
    console.log(`🧪 [${time}] ${msg}`);
  }
}

function getPageSignature() {
  return (
    location.href +
    "|" +
    document.body.innerText.slice(0, 500)
  );
}

async function clickWithVerification(btn, label, type = "click") {
  if (!btn) {
    logAction(`❌ Button "${label}" NOT FOUND`);
    return false;
  }

  logAction(`▶️ [ACTION] Click "${label}"`);

  const enabled = await waitBtnEnabled(btn);
  if (!enabled) {
    __clickFailReason = "disabled";
    logAction(`❌ Button "${label}" disabled — click skipped`);
    recordAction({ type, value: (btn.innerText || btn.value || label || "").trim().slice(0, 30), status: "failed", reason: "disabled" });
    return false;
  }
  logAction("✅ Button enabled");

  const before = getPageSignature();

  console.log(`⏱ clicking "${label}" ${Math.round(performance.now())}ms after page start`);
  highlightElement(btn);
  await sleep(80);   // was 300 — just enough for the highlight to be visible
  universalClick(btn);
  logAction("🖱️ Click dispatched");
  // Written right away: a successful click usually navigates away, so nothing after this point may run
  recordAction({ type, value: (btn.innerText || btn.value || label || "").trim().slice(0, 30), status: "success",
                 detail: `${(performance.now() / 1000).toFixed(1)}s after page start` });

  await sleep(500);

  const after = getPageSignature();

  if (before !== after) {
    logAction(`✅ Button "${label}" action SUCCESS (page changed)`);
    return true;
  } else {
    logAction(`❌ Button "${label}" action FAILED (no page change)`);
    __clickFailReason = "no_page_change";
    recordAction({ type, value: (btn.innerText || btn.value || label || "").trim().slice(0, 30), status: "failed", reason: "no_page_change" });
    return false;
  }
}


function normalizeButtonText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, "")
    .replace(/[^\x20-\x7E]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}


function detectIconButtons() {
  const icons = [];

  document.querySelectorAll("img, svg, i, span, div").forEach(el => {
    // skip invisible
    if (!el.offsetParent) return;

    // skip extension UI
    if (el.closest("#ttd-panel, #extension-root, .popup, .sidebar")) return;

    // 🔑 clickable element may be parent
    const clickable =
      getComputedStyle(el).cursor === "pointer"
        ? el
        : el.closest('[style*="cursor: pointer"], button, [role="button"]');

    if (!clickable) return;

    const rect = clickable.getBoundingClientRect();
    if (rect.width > 120 || rect.height > 120) return;

    const name =
      el.alt ||
      clickable.getAttribute("aria-label") ||
      clickable.title ||
      el.title ||
      el.className ||
      clickable.className ||
      "";

    const cleanName = normalizeButtonText(name || "");
    if (!cleanName) return;

    icons.push({
      el: clickable,
      text: cleanName
    });
  });

  return icons;
}


function clickIconButton(keyword) {
  const normalizeLocal = s =>
    String(s || "")
      .toLowerCase()
      .replace(/\*/g, "")
      .replace(/[\s\W_]+/g, "");

  const match = keyword.match(/(.+?)\[(\d+)\]$/);
  const name = match ? match[1] : keyword;
  const index = match ? parseInt(match[2], 10) - 1 : 0;

  const target = normalizeLocal(name);

  const icons = detectIconButtons()
    .filter(({ text }) => normalizeLocal(text).includes(target));

  if (!icons[index]) {
    console.log(`❌ Icon "${keyword}" not found`);
    return false;
  }

  const el = icons[index].el;

  el.scrollIntoView({ block: "center" });
  el.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true }));
  el.dispatchEvent(new PointerEvent("pointerup", { bubbles: true }));
  el.click();

  console.log(`✅ Icon "${keyword}" clicked`);
  return true;
}


async function fillInOrderSafe(values) {

  const fields = [...document.querySelectorAll("input, textarea, select")]
    .filter(el =>
      el.type !== "hidden" &&
      el.type !== "submit" &&
      el.type !== "button" &&
      el.type !== "file"
    );

  let index = 0;

  for (const el of fields) {

    const value = values[index];
    if (value === undefined) break;

    if (el.disabled) {
      const ok = await waitUntilEnabled(el, 3000);
      if (!ok) { index++; continue; }
    }

    // CHECKBOX
    if (el.type === "checkbox") {
      const v = normalize(value);
      const check = v === "yes" || v === "true" || v === "1" || v === "checked" || v === "on";
      if (el.checked !== check) {
        const labelEl = el.closest("label") || el.labels?.[0];
        if (labelEl) {
          universalClick(labelEl);
        } else {
          el.checked = check;
          el.dispatchEvent(new Event("input",  { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          el.click();
        }
      }
      index++;
      continue;
    }

    // RADIO
    if (el.type === "radio") {
      fillRadio(value);
      index++;
      continue;
    }

    // READONLY FAKE DROPDOWN
    if (el.readOnly) {
      await fillFakeDropdown(el, value);
      index++;
      continue;
    }

    // NATIVE SELECT
    if (el.tagName === "SELECT") {
      const opt = pickOption([...el.options], value);
      if (opt) {
        el.value = opt.value;
        el.dispatchEvent(new Event("change", { bubbles: true }));
        recordAction({ type: "dropdown", value: `${fieldLabelOf(el)} → ${opt.text.trim().slice(0, 30)}`, status: "success" });
      } else {
        recordAction({ type: "dropdown", value: `${fieldLabelOf(el)} = ${value}`, status: "failed", reason: "no_option" });
      }
      index++;
      continue;
    }

    // TEXT / TEXTAREA — use nativeSet for React/Vue/Angular
    el.focus();
    nativeSet(el, value);
    el.blur();
    index++;
  }
}


async function uploadSmart(cmdValue) {
  const text = cmdValue.trim();

  // ===============================
  // 1️⃣ Label-based library upload
  // ===============================
  if (text.includes("=")) {
    const [, filename] = text.split("=").map(s => s.trim());
    if (!filename) return false;

    const ok = await uploadImageByName(filename);
    return ok;
  }

  // ===============================
  // 2️⃣ Simple filename upload
  // ===============================
  const ok = await uploadImageByName(text);
  if (ok) return true;

  // ===============================
  // 3️⃣ OPTIONAL legacy fallback
  // (disable if you never want dialogs)
  // ===============================
  /*
  const input = findFileInput();
  if (!input) return false;

  await uploadFile(input, text);
  return true;
  */

  console.warn("❌ Image not found in library:", text);
  return false;
}


function isNewProfileReady() {
  const inputs = [...document.querySelectorAll("input, select, textarea")]
    .filter(el =>
      el.type !== "hidden" &&
      el.type !== "button" &&
      el.type !== "submit" &&
      el.type !== "file"
    );

  // if MOST fields are empty → new profile
  const emptyCount = inputs.filter(el => !el.value || el.value.trim() === "").length;

  return emptyCount >= Math.max(3, inputs.length * 0.6);
}


/* ================= ROW PROGRESS UI ================= */

function showRowProgress(current, total) {
  let box = document.getElementById("__rowProgress");

  if (!box) {
    box = document.createElement("div");
    box.id = "__rowProgress";
    box.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      background: #1e1e1e;
      color: #fff;
      padding: 8px 14px;
      border-radius: 20px;
      font-size: 13px;
      font-family: system-ui, sans-serif;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(box);
  }

  box.textContent = `🔁 Filling Row ${current} / ${total}`;
}

function hideRowProgress() {
  document.getElementById("__rowProgress")?.remove();
}

function isLabelMode(values) {
  return (
    Array.isArray(values) &&
    values.length > 0 &&
    typeof values[0] === "object" &&
    values[0] !== null &&
    values[0].label !== undefined &&
    values[0].value !== undefined
  );
}



/* =========================================================
   WAIT FOR CALENDAR
   Polls until clickable <td> date cells appear on the page.
   Used automatically before every "date" command.
   ========================================================= */
async function waitForCalendar(timeout = 8000) {
  const start = Date.now();
  console.log("⏳ Waiting for calendar to appear...");

  while (Date.now() - start < timeout) {
    const clickableTds = [...document.querySelectorAll("td")]
      .filter(td => {
        const style = td.getAttribute("style") || "";
        const computed = getComputedStyle(td).pointerEvents;
        return (
          (style.includes("pointer-events: auto") || computed === "auto") &&
          td.innerText.trim().match(/^\d+$/) &&
          td.getBoundingClientRect().width > 0
        );
      });

    if (clickableTds.length > 0) {
      console.log(`✅ Calendar ready — ${clickableTds.length} available dates found`);
      return true;
    }

    await sleep(100);
  }

  console.warn("⚠️ waitForCalendar: timed out, no clickable dates found");
  return false;
}


/* =========================================================
   CALENDAR DATE SELECTOR
   Handles date pickers built as <td> grids (no input fields)
   Supports:
     date 07/04/2026   or   date 07-04-2026  → specific date (DD/MM/YYYY)
     date April 7      or   date 7 April     → month + day
     date available    → first clickable date on the calendar
     date available 2  → 2nd clickable date
   ========================================================= */
// Day number shown in a calendar cell: first line of its text, leading zero ignored ("07" → "7",
// "21\n₹500" → "21"). Returns "" for containers (a cell that itself holds other cells).
function calDayText(td) {
  if (td.querySelector("td")) return "";
  const first = (td.innerText || "").trim().split(/\s*\n\s*/)[0].trim();
  return /^\d{1,2}$/.test(first) ? String(parseInt(first, 10)) : first;
}

// Does this cell look unavailable (greyed / booked / past)?
// Note: already-selected cells (purple/active) are NOT disabled — they are valid
function calCellLooksDisabled(td) {
  // if the cell is already selected/active → it is available, not disabled
  if (/selected|active|current|highlight/i.test(String(td.className || ""))) return false;
  // TTD uses pointer-events:none on BOTH disabled AND filling-fast cells —
  // so pointer-events check is unreliable. Only use aria-disabled and class names.
  // Grey "Slot Not Available" cells have class names containing "slot" or "not" or "available"
  // but NOT green/yellow/blue availability indicators.
  return td.getAttribute("aria-disabled") === "true" ||
         td.hasAttribute("disabled") ||
         /disabled|unavailable|booked|sold|inactive|past/i.test(String(td.className || ""));
}

// Is this cell already the selected date?
function calCellIsSelected(td) {
  return /selected|active|current|highlight/i.test(String(td.className || "")) ||
         td.getAttribute("aria-selected") === "true" ||
         td.getAttribute("aria-current") === "date";
}

async function selectCalendarDate(value) {
  if (!value) return false;

  const v = value.trim();

  // Log the outcome (shows in the popup's "Recent actions") with a specific reason
  const dateFail = (reason, detail) => {
    recordAction({ type: "date", value: v, status: "failed", reason, detail });
    return false;
  };
  const dateOk = (shown) => {
    recordAction({ type: "date", value: shown || v, status: "success" });
    return true;
  };

  // ── Mode 1: "available" or "available N" ──
  // Click the Nth date that has pointer-events:auto (not disabled/booked)
  const availableMatch = v.match(/^available\s*(\d+)?$/i);
  if (availableMatch) {
    const nthIndex = parseInt(availableMatch[1] || "1", 10) - 1;

    const allTds = [...document.querySelectorAll("td")]
      .filter(td => {
        const style = td.getAttribute("style") || "";
        const computed = getComputedStyle(td).pointerEvents;
        return (
          (style.includes("pointer-events: auto") || computed === "auto") &&
          td.innerText.trim().match(/^\d+$/) &&
          td.getBoundingClientRect().width > 0
        );
      });
    // "auto" is the browser default for every cell, so also skip cells that look greyed/booked/past;
    // if that leaves nothing, fall back to the old behaviour (all cells).
    const enabledTds = allTds.filter(td => !calCellLooksDisabled(td));
    const availableTds = enabledTds.length ? enabledTds : allTds;

    const target = availableTds[nthIndex];
    if (target) {
      target.scrollIntoView({ block: "center" });
      universalClick(target);
      console.log("✅ date available clicked:", target.innerText.trim(), "| id:", target.id);
      return dateOk(`${v} → day ${target.innerText.trim()}`);
    }
    console.warn("❌ date: no available date found at index", nthIndex + 1);
    return dateFail("no_available", `${allTds.length} day cells on page, wanted #${nthIndex + 1}`);
  }

  // ── Parse the date value into day + month name ──
  let day = null;
  let monthName = null;

  const MONTHS = {
    jan: "January", feb: "February", mar: "March",    apr: "April",
    may: "May",     jun: "June",     jul: "July",      aug: "August",
    sep: "September", oct: "October", nov: "November", dec: "December"
  };

  // Format: DD/MM/YYYY or DD-MM-YYYY  (e.g. 07/04/2026)
  const numericDate = v.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (numericDate) {
    day = parseInt(numericDate[1], 10);
    const monthNum = parseInt(numericDate[2], 10);
    const monthEntry = Object.entries(MONTHS)[monthNum - 1];
    monthName = monthEntry ? monthEntry[1] : null;
  }

  // Format: "April 7" or "7 April" or "Apr 7"
  if (!day) {
    const textDate = v.match(/^([a-zA-Z]+)\s+(\d{1,2})$/) ||
                     v.match(/^(\d{1,2})\s+([a-zA-Z]+)$/);
    if (textDate) {
      const part1 = textDate[1], part2 = textDate[2];
      if (isNaN(part1)) {
        // "April 7"
        const key = part1.toLowerCase().slice(0, 3);
        monthName = MONTHS[key] || part1;
        day = parseInt(part2, 10);
      } else {
        // "7 April"
        day = parseInt(part1, 10);
        const key = part2.toLowerCase().slice(0, 3);
        monthName = MONTHS[key] || part2;
      }
    }
  }

  if (!day) {
    console.warn("❌ date: could not parse date value:", v);
    return dateFail("unparsed", "use DD/MM/YYYY, 'April 7' or 'available'");
  }

  // ── Find the correct month calendar section ──
  // Look for a header div/element containing the month name (e.g. "April 2026")
  let calendarSection = null;

  if (monthName) {
    const mLower = monthName.toLowerCase();
    const MONTH_RE = /(january|february|march|april|may|june|july|august|september|october|november|december)/i;

    // A month header is SHORT text like "April 2026". Big containers also "contain" the month name,
    // and the old code picked the outermost one first — which scoped the search to several months.
    const isMonthHeader = (el) => {
      const txt = (el.innerText || "").trim();
      return txt.length > 0 && txt.length <= 40 && /\d{4}/.test(txt) && MONTH_RE.test(txt);
    };
    const HDR_SEL = "div, h1, h2, h3, th, td, span";

    let headers = [...document.querySelectorAll(HDR_SEL)]
      .filter(el =>
        el.getBoundingClientRect().width > 0 &&
        isMonthHeader(el) &&
        el.innerText.trim().toLowerCase().includes(mLower)
      );

    // Unusual layout (long header text): fall back to the original, looser match
    if (!headers.length) {
      headers = [...document.querySelectorAll(HDR_SEL)]
        .filter(el =>
          el.getBoundingClientRect().width > 0 &&
          el.innerText.trim().toLowerCase().includes(mLower) &&
          el.innerText.trim().match(/\d{4}/)
        );
    }

    // Keep only the INNERMOST matches: a wrapper that merely contains "April 2026" somewhere inside
    // is not the header (this was the bug — the wrapper came first and scoped the search to all months)
    headers = headers.filter(el => !headers.some(o => o !== el && el.contains(o)));

    for (const header of headers) {
      // (a) header directly followed by its own grid:  <h3>April 2026</h3><table>…</table>
      const sib = header.nextElementSibling;
      if (sib && !isMonthHeader(sib) && (sib.matches("table") || sib.querySelector("td"))) {
        calendarSection = sib;
        break;
      }

      // (b) walk up to the container holding this header and its <td> cells, but stop at the first
      //     container that ALSO holds a different month's header
      let node = header.parentElement;
      let firstWithTd = null;
      for (let d = 0; d < 6 && node; d++) {
        if (node.querySelector("td")) {
          firstWithTd = firstWithTd || node;
          const months = new Set(
            [...node.querySelectorAll(HDR_SEL)].filter(isMonthHeader)
              .map(e => e.innerText.trim().toLowerCase())
          );
          if (months.size <= 1) { calendarSection = node; break; }
        }
        node = node.parentElement;
      }
      if (!calendarSection && firstWithTd) calendarSection = firstWithTd;   // original behaviour
      if (calendarSection) break;
    }
  }

  // ── Find the matching <td> with the day number ──
  const searchScope = calendarSection || document;
  const dayStr = String(day);

  const visibleTds = [...searchScope.querySelectorAll("td")]
    .filter(td => td.getBoundingClientRect().width > 0);
  const dayCells = visibleTds.filter(td => calDayText(td) === dayStr);

  const candidates = dayCells.filter(td => {
    // Must be clickable (pointer-events not none)
    const style = td.getAttribute("style") || "";
    const computed = getComputedStyle(td).pointerEvents;
    return style.includes("pointer-events: auto") || computed === "auto";
  });

  // Prefer a cell that does not look greyed/booked/past
  const enabled = candidates.filter(td => !calCellLooksDisabled(td));
  const target = enabled[0] || candidates[0] || dayCells[0];   // last one = old "fallback" (no pointer-events filter)

  if (!target) {
    const anyNumericTd = [...document.querySelectorAll("td")].some(td => /^\d{1,2}$/.test(calDayText(td)));
    const scopeInfo = `${monthName ? `month "${monthName}" ${calendarSection ? "section found" : "header NOT found (searched whole page)"}` : "no month in value"}; ${visibleTds.length} visible <td> in scope`;
    console.warn("❌ date: day", dayStr, "not found in", monthName || "any month", "|", scopeInfo);
    if (!anyNumericTd) {
      return dateFail("no_calendar", "no <td> day cells on the page — calendar may not be table-based, or has not loaded");
    }
    return dateFail("no_day_cells", `day ${dayStr} not on calendar; ${scopeInfo}`);
  }

  // If the cell is already selected (e.g. purple/active from a previous fill run) → skip click, treat as success
  if (calCellIsSelected(target)) {
    console.log("✅ date already selected:", dayStr, monthName || "", "— skipping click");
    return dateOk(v + " (already selected)");
  }

  target.scrollIntoView({ block: "center" });
  universalClick(target);

  if (!enabled[0] && calCellLooksDisabled(target)) {
    console.warn("⚠️ date: clicked", dayStr, "but the cell looks unavailable:", target.className || target.getAttribute("style") || "");
    return dateFail("day_disabled", `day ${dayStr} clicked but cell looks unavailable (class="${String(target.className || "").slice(0, 40)}")`);
  }

  console.log("✅ date clicked:", dayStr, monthName || "", "| id:", target.id, candidates.length ? "" : "(fallback: no pointer-events match)");
  return dateOk(v);
}


/* =========================================================
   PICKSLOT — choose a time slot shown on the page (cards / buttons / radios / a <select>)
   pickslot between 11:00 AM and 06:00 PM      → earliest available slot inside the window
   pickslot 11:00 AM - 06:00 PM latest         → latest one instead
   Waits up to ~6 s for the slots to appear (they often render after the date is picked).
   ========================================================= */
function collectSlotElements() {
  const SEL = "button, a, li, label, td, [role='button'], [role='option'], [role='radio'], [role='tab'], [tabindex], div, span";
  const CLICKABLE_TAGS = /^(BUTTON|A|LI|LABEL|TD)$/;
  const all = [...document.querySelectorAll(SEL)].filter(el => {
    const text = (el.innerText || "").trim();
    if (!text || text.length > 60 || firstClockIn(text) === null) return false;      // cheap checks first
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    // generic div/span only count when they behave like a button — avoids header clocks / "last updated" text
    return CLICKABLE_TAGS.test(el.tagName) ||
           /button|option|radio|tab/i.test(el.getAttribute("role") || "") ||
           el.hasAttribute("tabindex") || el.hasAttribute("onclick") ||
           getComputedStyle(el).cursor === "pointer";
  });
  // innermost only: a <ul> holding several slots must not stand in for them
  const out = all.filter(el => !all.some(o => o !== el && el.contains(o)))
                 .map(el => ({ el, text: (el.innerText || "").trim() }));

  // radio buttons (slot times are often radios): text comes from their label / sibling; a hidden
  // custom radio is clicked through its label. Availability follows the RADIO's disabled state.
  document.querySelectorAll('input[type="radio"]').forEach(r => {
    const text = radioText(r);
    if (!text || text.length > 60 || firstClockIn(text) === null) return;
    const labelEl = r.labels?.[0] || r.closest("label");
    const visible = r.offsetParent !== null && r.getBoundingClientRect().width > 0;
    const clickEl = (labelEl && !visible) ? labelEl : r;
    const dup = out.find(o => o.el === clickEl || o.el === labelEl || (labelEl && labelEl.contains(o.el)) || o.el.contains?.(r));
    if (dup) { dup.radio = r; dup.el = clickEl; return; }               // same option already found as text
    out.push({ el: clickEl, text, radio: r });
  });
  return out;
}

async function pickSlotOnPage(value, timeout = 6000) {
  const spec = parseTimeRangeSpec(value);
  if (!spec) {
    console.warn("❌ pickslot: could not read the time range:", value);
    recordAction({ type: "pickslot", value, status: "failed", reason: "unparsed",
                   detail: "use e.g.  pickslot between 11:00 AM and 06:00 PM" });
    return false;
  }

  const end = Date.now() + timeout;
  let found = "no time slots found on the page";

  while (true) {
    // 1) native <select> with time options
    for (const sel of document.querySelectorAll("select")) {
      const r = sel.getBoundingClientRect();
      if (!r.width && !r.height) continue;
      const opt = pickSlotInRange([...sel.options], spec, o => o.text);
      if (opt) {
        sel.value = opt.value;
        sel.dispatchEvent(new Event("input",  { bubbles: true }));
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        console.log("✅ pickslot (select):", opt.text.trim());
        recordAction({ type: "pickslot", value: opt.text.trim().slice(0, 30), status: "success" });
        return true;
      }
    }

    // 2) cards / buttons / radio labels
    const cands = collectSlotElements();
    const hit = pickSlotInRange(cands, spec, c => c.text);
    if (hit) {
      hit.el.scrollIntoView?.({ block: "center" });
      if (hit.radio) await clickRadio(hit.radio); else universalClick(hit.el);
      console.log("✅ pickslot:", hit.text);
      recordAction({ type: "pickslot", value: hit.text.replace(/\s+/g, " ").slice(0, 30), status: "success" });
      await sleep(250);
      return true;
    }
    found = describeSlotsFound(cands, c => c.text);

    if (Date.now() >= end) break;
    await new Promise(r => setTimeout(r, 150));
  }

  console.warn("❌ pickslot: no available slot inside the range |", found);
  recordAction({ type: "pickslot", value, status: "failed", reason: "no_slot_in_range", detail: found });
  return false;
}

/* =========================================================
   SEGMENT-AWARE READINESS
   A page that only needs a button clicked (e.g. "Pay now") often has no form
   fields at all — waitForPageReady would then burn its whole 15s timeout waiting
   for one. For such pure-click segments, wait for the button instead.
   ========================================================= */
async function waitForSegmentReady(commands, groups, timeout = 15000) {
  const CLICKY = ["click", "add", "next", "submit"];
  const cmds = commands || [];
  // NOTE: later `===` pages with no data of their own INHERIT page 1's data (see popup.js), so the
  // presence of data says nothing here. What matters is what the segment does: only clicks/waits and
  // no explicit `fill` → it never needs form fields, so don't wait for any.
  const pureClicks =
    cmds.some(c => CLICKY.includes(c.type) || c.type === "pickslot") &&
    cmds.every(c => CLICKY.includes(c.type) || c.type === "wait" || c.type === "pickslot" || c.type === "anysite");

  if (pureClicks) {
    const first = cmds.find(c => CLICKY.includes(c.type) || c.type === "pickslot");
    if (first.type === "pickslot") return true;      // pickslot waits for its own slots — no field wait

    const texts = first.type === "next"   ? ["next", "continue"]
                : first.type === "submit" ? ["submit", "save"]
                : [first.value];
    console.log(`⏳ Click-only page — waiting for button: ${texts.join(" / ")} (not for form fields)`);
    const btn = await findButtonByTextWithWait(texts, timeout);
    console.log(btn ? "✅ Button present — page ready" : "⚠️ Button not found within timeout — proceeding anyway");
    return !!btn;
  }
  return waitForPageReady(timeout);
}

/* =========================================================
   WAIT FOR PAGE READY
   Waits until the page has at least one visible form field
   and the DOM has stabilized. Used by background continuation.
   ========================================================= */
async function waitForPageReady(timeout = 15000) {
  const start = Date.now();
  let lastHTML = "";
  let stableCount = 0;

  console.log("⏳ Waiting for page to be ready...");

  while (Date.now() - start < timeout) {
    const fields = document.querySelectorAll(
      "input:not([type=hidden]):not([type=submit]):not([type=button]), select, textarea"
    );

    const currentHTML = document.body?.innerHTML?.slice(0, 1000) || "";
    const isStable = currentHTML === lastHTML;
    lastHTML = currentHTML;

    if (fields.length > 0 && isStable) {
      stableCount++;
      if (stableCount >= 2) {
        console.log(`✅ Page ready — ${fields.length} fields found`);
        return true;
      }
    } else {
      stableCount = 0;
    }

    await sleep(100);   // was 200
  }

  console.warn("⚠️ Page ready timeout — proceeding anyway");
  return false;
}


async function runWorkflow(commands = []) {
  window.__OM_FILL_RUNNING = true;
  window.__OM_FILL_STOP = false;

  // 🔥 SMART COMMAND NORMALIZER
  function normalizeCommands(cmds) {

    const hasFill = cmds.some(c => c.type === "fill");

    if (hasFill) return cmds;

    // find last section index
    const lastSectionIndex = cmds
      .map(c => c.type)
      .lastIndexOf("section");

    if (lastSectionIndex !== -1) {
      // insert fill AFTER last section
      cmds.splice(lastSectionIndex + 1, 0, { type: "fill" });
    } else {
      // no section → put at start
      cmds.unshift({ type: "fill" });
    }

    return cmds;
  }

  commands = normalizeCommands(commands);

  console.log("FULL COMMANDS ARRAY:", JSON.stringify(commands, null, 2));



  console.log("🧩 WORKFLOW COMMANDS:", commands);
  if (!Array.isArray(commands) || !commands.length) return;


  const hasUpload = commands.some(c => c.type === "upload");

  /* =====================================================
     0️⃣ HARD RESET workflow state (VERY IMPORTANT)
     ===================================================== */
  window.__workflowState.processedCount = 0;
  window.__workflowState.totalRows = 0;

  let activeRowRange = null;

  /* =====================================================
     1️⃣ Detect row command ONCE
     ===================================================== */
  for (const cmd of commands) {
    // Check stop flag before every command — stops cleanly between steps
    if (window.__OM_FILL_STOP) {
      window.__OM_FILL_STOP = false;
      window.__OM_FILL_RUNNING = false;
      recordAction({ type: "click", value: "⏹ stopped by user", status: "stopped" });
      chrome.runtime.sendMessage({ type: "OM_FILL_STOPPED" }, () => void chrome.runtime.lastError);
      return;
    }
    if (cmd.type === "row") {
      const { start, end } = cmd.value;
      const max = window.__workflowGroups.length - 1;

      if (start < 0 || start > max) {
        console.warn(`❌ Row ${start + 1} not found`);
        activeRowRange = null;
      } else {
        activeRowRange = {
          start,
          end: Math.min(end ?? start, max)
        };
        console.log(
          `📌 Using rows ${start + 1} → ${Math.min((end ?? start) + 1, max + 1)}`
        );
      }
      break; // 🔥 only first row command matters
    }
  }

  /* =====================================================
     2️⃣ Decide rows EXACTLY ONCE
     ===================================================== */
  let rowsToUse;

  if (activeRowRange) {
    rowsToUse = window.__workflowGroups.slice(
      activeRowRange.start,
      activeRowRange.end + 1
    );
  } else if (
    window.__selectedRowIndex !== null &&
    window.__workflowGroups[window.__selectedRowIndex]
  ) {
    rowsToUse = [window.__workflowGroups[window.__selectedRowIndex]];
  } else if (window.__repeatMode) {
    // Repeat ON: cycle through profiles one at a time
    // Each Fill run uses the next profile, wrapping around
    const groups = window.__workflowGroups;
    if (groups.length > 1) {
      // Multiple profiles: advance index each run
      const idx = window.__repeatProfileIndex % groups.length;
      rowsToUse = [groups[idx]];
      window.__repeatProfileIndex = (idx + 1) % groups.length;
      console.log(`🔁 Repeat: using profile ${idx + 1}/${groups.length}`);
      // Notify popup to highlight the used pill
      try {
        chrome.runtime.sendMessage({ type: "REPEAT_PROFILE_USED", index: idx });
      } catch(e) {}
    } else {
      // Single profile: reuse same data (original repeat behavior)
      rowsToUse = groups;
    }
  } else {
    rowsToUse = [window.__workflowGroups[0]];
    window.__repeatProfileIndex = 0; // reset when not repeating
  }

  /* =====================================================
     3️⃣ Init progress (ONCE)
     ===================================================== */
  window.__workflowState.totalRows = rowsToUse.length;

  /* =====================================================
     4️⃣ Execute ROW BY ROW
     ===================================================== */
  for (let i = 0; i < rowsToUse.length; i++) {
    const values = rowsToUse[i];

    // ✅ increment EXACTLY once per row
    window.__workflowState.processedCount = i + 1;

    showRowProgress(
      window.__workflowState.processedCount,
      window.__workflowState.totalRows
    );

    for (const cmd of commands) {






           if (cmd.type === "fill") {

              if (isLabelMode(values)) {
                console.log("🏷 Label Mode ON");
                await fillByLabelSafe(values);
              } else {
                console.log("📌 Order Mode ON");
                await fillInOrderSafe(values);
              }


              document.activeElement?.blur();
              await sleep(20);
              continue;
            }


               if (cmd.type === "section") {

                const target = cmd.value.trim().toLowerCase();
                let found = null;

                // 🔁 Wait up to 5 seconds for section to render
                for (let t = 0; t < 25; t++) {

                  const candidates = [...document.querySelectorAll("*")]
                    .filter(e =>
                      e.offsetParent &&
                      e.innerText &&
                      e.innerText.trim().toLowerCase() === target
                    );

                  if (candidates.length) {
                    found = candidates[0];
                    break;
                  }

                  await sleep(200);
                }

                if (!found) {
                  console.log("❌ Section not found:", cmd.value);
                  continue;
                }

                // 🔥 Find the REAL clickable container
                let clickable =
                  found.closest("button") ||
                  found.closest("[role='button']") ||
                  found.closest("[class*='css']") ||
                  found.parentElement;

                if (!clickable) clickable = found;

                universalClick(clickable);
                console.log("✅ Section clicked:", cmd.value);

                // 🔁 Wait until tab becomes active (optional smart wait)
                await sleep(300);

                continue;
              }





      if (cmd.type === "icon") {
        if (!hasUpload) {
          clickIconButton(cmd.value);
          await sleep(150);
        }
        continue;
      }

      if (cmd.type === "upload") {
        await uploadSmart(cmd.value);
        await sleep(150);
        continue;
      }

      if (cmd.type === "click" || cmd.type === "add") {
        const _t0 = performance.now();
        // Support "click .className" → find by CSS selector directly
        let btn;
        if (/^\./.test((cmd.value || "").trim())) {
          const sel = cmd.value.trim();
          const end = Date.now() + 5000;
          while (Date.now() < end) {
            const el = document.querySelector(sel);
            if (el && el.offsetParent) { btn = el; break; }
            await sleep(100);
          }
        } else {
          btn = await findButtonByTextWithWait(cmd.value);
        }
        if (!btn) {
          console.warn(`❌ click target "${cmd.value}" never appeared`);
          recordAction({ type: cmd.type, value: cmd.value, status: "failed", reason: "not_found" });
          continue;
        }
        const _tFound = performance.now();
        const enabled = await waitBtnEnabled(btn);
        console.log(`⏱ "${cmd.value}": found in ${Math.round(_tFound - _t0)}ms, ${enabled ? "enabled" : "STILL DISABLED"} after ${Math.round(performance.now() - _t0)}ms`);
        if (!enabled) {
          console.warn(`❌ "${cmd.value}" disabled — click skipped`);
          recordAction({ type: cmd.type, value: cmd.value, status: "failed", reason: "disabled" });
          continue;
        }
        console.log(`⏱ clicking "${cmd.value}" ${Math.round(performance.now())}ms after page start`);
        highlightElement(btn);
        universalClick(btn);
        recordAction({ type: cmd.type, value: cmd.value, status: "success",
                       detail: `${(performance.now() / 1000).toFixed(1)}s after page start` });
        markPageChanging();
        await sleep(250);
        continue;
      }

      if (cmd.type === "next") {
        const btn = await findButtonByTextWithWait(["next", "continue"]);
        if (!btn) {
          console.warn("❌ next/continue button never appeared");
          recordAction({ type: "next", status: "failed", reason: "not_found" });
          continue;
        }
        await clickWithVerification(btn, "Next / Continue", "next");
        continue;
      }

      if (cmd.type === "submit") {
        const btn = await findButtonByTextWithWait(["submit", "save"]);
        if (!btn) {
          console.warn("❌ submit/save button never appeared");
          recordAction({ type: "submit", status: "failed", reason: "not_found" });
          continue;
        }
        await clickWithVerification(btn, "Submit / Save", "submit");
        continue;
      }

      if (cmd.type === "wait") {
        // handle both "wait 200" and legacy "wait200" (already normalized in popup, but safe fallback)
        const ms = parseInt(String(cmd.value).replace(/\D/g, "") || "500", 10);
        await sleep(isNaN(ms) ? 500 : ms);
        continue;
      }

      /* checkall — tick every visible unchecked checkbox on the page.
         checkall            → tick all, no dialog handling
         checkall 5          → tick at most 5
         checkall with ok    → tick one → wait for OK dialog → click it → repeat */
      if (cmd.type === "checkall") {
        const withOk = /with\s*ok/i.test(cmd.value || "");
        const limitStr = (cmd.value || "").replace(/with[\s]*ok/gi, "").trim();
        const limit = limitStr ? parseInt(limitStr, 10) : 9999;
        const NAV = "nav, header, li, [class*='header'], [class*='nav'], [class*='menu'], [class*='sub-header']";

        function getUnchecked() {
          return [...document.querySelectorAll("input[type='checkbox']")]
            .filter(cb => {
              if (cb.checked || cb.disabled) return false;
              if (cb.closest(NAV)) return false;
              // use getBoundingClientRect instead of offsetParent —
              // offsetParent is null inside scrollable containers
              const r = cb.getBoundingClientRect();
              return r.width > 0 || r.height > 0 || cb.getClientRects().length > 0;
            });
        }

        async function doTick(cb) {
          const lbl = cb.closest("label") || cb.parentElement?.querySelector("label");
          const target = lbl || cb;
          target.click();
          await sleep(150);
          if (!cb.checked) {
            target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
            await sleep(100);
          }
          if (!cb.checked) {
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
            if (setter) {
              setter.call(cb, true);
              cb.dispatchEvent(new Event("change", { bubbles: true }));
              cb.dispatchEvent(new Event("input", { bubbles: true }));
            }
            await sleep(80);
          }
        }

        async function waitOk() {
          const end = Date.now() + 4000;
          while (Date.now() < end) {
            const ok = document.querySelector(".DialogBox_btn__Kq0LL") ||
              [...document.querySelectorAll("button")].find(b => b.offsetParent &&
                /^(ok|okay|done|close)$/i.test(b.textContent.trim()) &&
                !b.closest(NAV));
            if (ok) { universalClick(ok); await sleep(300); return true; }
            await sleep(80);
          }
          return false;
        }

        let ticked = 0;

        if (withOk) {
          let safety = 20;
          while (safety-- > 0) {
            const boxes = getUnchecked();
            if (!boxes.length) { console.log("☑️ checkall with ok: done, ticked=" + ticked); break; }
            await doTick(boxes[0]);
            ticked++;
            console.log("☑️ checkall with ok: ticked " + ticked);
            await waitOk();
          }
        } else {
          const boxes = [...document.querySelectorAll("input[type='checkbox']")]
            .filter(cb => cb.offsetParent && !cb.disabled && !cb.closest(NAV))
            .slice(0, limit);
          for (const cb of boxes) {
            if (cb.checked) { console.log("☑️ already checked — skip"); continue; }
            await doTick(cb);
            ticked++;
            console.log("☑️ ticked " + ticked + "/" + boxes.length);
          }
        }

        const status = (withOk || ticked > 0) ? "success" : "failed";
        recordAction({ type: "checkall", value: String(ticked), status,
                       detail: ticked + " checkbox(es) ticked" });
        continue;
      }

      if (cmd.type === "waitpage") {
        // Explicit: wait until form fields appear on the page (up to 20 seconds)
        const maxMs = parseInt(String(cmd.value).replace(/\D/g, "") || "20000", 10);
        await waitForPageReady(isNaN(maxMs) ? 20000 : maxMs);
        continue;
      }

      if (cmd.type === "pickslot") {
        await pickSlotOnPage(cmd.value);
        markPageChanging();
        continue;
      }

      if (cmd.type === "date") {
        // Auto-wait for calendar to appear before clicking
        await waitForCalendar(5000);
        const dateOk = await selectCalendarDate(cmd.value);
        if (!dateOk) {
          // Date not available or not found — stop the fill immediately
          // so the wrong date is never used for booking
          console.warn(`❌ date "${cmd.value}" failed — stopping fill to prevent wrong date booking`);
          window.__OM_FILL_STOP = true;
          chrome.runtime.sendMessage({ type: "OM_FILL_STOPPED" }, () => void chrome.runtime.lastError);
          return;
        }
        markPageChanging();
        await sleep(60);
        continue;
      }

      if (cmd.type === "waitcalendar") {
        const ms = parseInt(String(cmd.value || "").replace(/\D/g, "") || "10000", 10);
        await waitForCalendar(isNaN(ms) ? 10000 : ms);
        continue;
      }

      // ── BACK ──
      if (cmd.type === "back") {
        const btn =
          findButtonByText("back") ||
          findButtonByText("previous") ||
          findButtonByText("prev");
        if (btn) {
          universalClick(btn);
          await sleep(250);
        } else {
          history.back();
        }
        continue;
      }

      // ── SCROLL ── scroll to an element or by pixels
      if (cmd.type === "scroll") {
        const val = (cmd.value || "").trim().toLowerCase();
        if (val === "top") {
          window.scrollTo({ top: 0, behavior: "smooth" });
        } else if (val === "bottom") {
          window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
        } else if (/^-?\d+$/.test(val)) {
          window.scrollBy({ top: parseInt(val, 10), behavior: "smooth" });
        } else {
          // scroll to element by text
          const el = [...document.querySelectorAll("*")]
            .find(e => e.offsetParent && normalize(e.innerText || "").includes(normalize(val)));
          if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
        }
        await sleep(100);
        continue;
      }

      // ── PRESS ── fire keyboard event (Enter, Tab, Escape, ArrowDown etc)
      if (cmd.type === "press") {
        const keyMap = {
          enter: "Enter", tab: "Tab", escape: "Escape", esc: "Escape",
          arrowdown: "ArrowDown", arrowup: "ArrowUp",
          arrowleft: "ArrowLeft", arrowright: "ArrowRight",
          space: " ", backspace: "Backspace", delete: "Delete"
        };
        const key = keyMap[(cmd.value || "").trim().toLowerCase()] || cmd.value;
        const target = document.activeElement || document.body;
        target.dispatchEvent(new KeyboardEvent("keydown",  { key, bubbles: true, cancelable: true }));
        target.dispatchEvent(new KeyboardEvent("keypress", { key, bubbles: true, cancelable: true }));
        target.dispatchEvent(new KeyboardEvent("keyup",    { key, bubbles: true, cancelable: true }));
        await sleep(50);
        continue;
      }

      // ── HOVER ── mouseover an element to open hover menus/tooltips
      if (cmd.type === "hover") {
        const val = (cmd.value || "").trim();
        const el = [...document.querySelectorAll("*")]
          .filter(e => e.offsetParent)
          .find(e => normalize(e.innerText || "").includes(normalize(val)) ||
                     normalize(e.getAttribute("aria-label") || "").includes(normalize(val)));
        if (el) {
          el.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
          el.dispatchEvent(new MouseEvent("mouseover",  { bubbles: true }));
          console.log("✅ hover:", val);
          await sleep(150);
        } else {
          console.warn("❌ hover: not found:", val);
        }
        continue;
      }

      // ── GOTO ── navigate to a URL
      if (cmd.type === "goto") {
        const url = (cmd.value || "").trim();
        if (url) {
          window.location.href = url.startsWith("http") ? url : "https://" + url;
          await sleep(500);
        }
        continue;
      }

      // ── TYPE ── type text char by char (for sites that block paste)
      if (cmd.type === "type") {
        const el = document.activeElement;
        if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) {
          const text = String(cmd.value || "");
          for (const char of text) {
            el.dispatchEvent(new KeyboardEvent("keydown",  { key: char, bubbles: true }));
            el.dispatchEvent(new KeyboardEvent("keypress", { key: char, bubbles: true }));
            nativeSet(el, el.value + char);
            el.dispatchEvent(new KeyboardEvent("keyup",    { key: char, bubbles: true }));
            await sleep(15);
          }
        }
        continue;
      }

      /* if — conditional command
         Syntax:  if <condition> → <action>
         Conditions:
           checkbox checked       → true if ANY visible checkbox is checked
           checkbox unchecked     → true if ANY visible checkbox is unchecked
           button disabled <text> → true if that button is disabled
           button enabled <text>  → true if that button is enabled
           field empty <label>    → true if that field has no value
           field filled <label>   → true if that field already has a value
         Actions (after →):
           skip                   → skip this step, continue to next command
           checkall               → run checkall
           click <text>           → click that button
           fill                   → run fill
           stop                   → stop the workflow
         Example:
           if checkbox unchecked → checkall
           if button disabled Continue → skip
           if button enabled Continue → click Continue
      */
      if (cmd.type === "if") {
        const raw = (cmd.value || "").trim();
        const arrowIdx = raw.search(/→|->/);
        if (arrowIdx < 0) { console.warn("⚠️ if: missing → arrow"); continue; }
        const condStr = raw.slice(0, arrowIdx).trim().toLowerCase();
        const actionStr = raw.slice(arrowIdx + 1).replace(/^[→>]\s*/, "").trim();
        let condResult = false;

        if (condStr === "checkbox checked") {
          condResult = [...document.querySelectorAll("input[type='checkbox']")]
            .some(cb => cb.offsetParent && cb.checked && !cb.disabled &&
              !cb.closest("nav, header, li, [class*='header'], [class*='nav'], [class*='menu']"));
        } else if (condStr === "checkbox unchecked") {
          condResult = [...document.querySelectorAll("input[type='checkbox']")]
            .some(cb => cb.offsetParent && !cb.checked && !cb.disabled &&
              !cb.closest("nav, header, li, [class*='header'], [class*='nav'], [class*='menu']"));
        } else if (condStr.startsWith("button disabled")) {
          const btnText = condStr.replace("button disabled", "").trim();
          const btn = btnText ? findButtonByText(btnText, true) : document.querySelector("button[disabled]");
          condResult = btn ? isBtnDisabled(btn) : false;
        } else if (condStr.startsWith("button enabled")) {
          const btnText = condStr.replace("button enabled", "").trim();
          const btn = btnText ? findButtonByText(btnText, true) : null;
          condResult = btn ? !isBtnDisabled(btn) : false;
        } else if (condStr.startsWith("field empty")) {
          const label = condStr.replace("field empty", "").trim();
          const el = label ? findFieldByLabel(label) : null;
          condResult = el ? !(el.value || "").trim() : false;
        } else if (condStr.startsWith("field filled")) {
          const label = condStr.replace("field filled", "").trim();
          const el = label ? findFieldByLabel(label) : null;
          condResult = el ? !!(el.value || "").trim() : false;
        }

        console.log(`🔀 if [${condStr}] → ${condResult ? "TRUE" : "FALSE"} → ${condResult ? actionStr : "skip"}`);
        if (!condResult) { continue; }   // condition false → skip the action

        // execute the action
        const act = actionStr.toLowerCase().trim();
        if (act === "skip") { continue; }
        if (act === "stop") { window.__OM_FILL_STOP = true; continue; }
        if (act === "fill") { commands.splice(commands.indexOf(cmd) + 1, 0, { type: "fill", value: "" }); continue; }
        if (act === "checkall") {
          const ifNAV = "nav, header, li, [class*='header'], [class*='nav'], [class*='menu'], [class*='sub-header']";
          const boxes = [...document.querySelectorAll("input[type='checkbox']")]
            .filter(cb => {
              if (cb.checked || cb.disabled || cb.closest(ifNAV)) return false;
              const r = cb.getBoundingClientRect();
              return r.width > 0 || r.height > 0 || cb.getClientRects().length > 0;
            });
          for (const cb of boxes) {
            const lbl = cb.closest("label") || cb.parentElement?.querySelector("label");
            const tgt = lbl || cb;
            tgt.click(); await sleep(150);
            if (!cb.checked) {
              tgt.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
              await sleep(100);
            }
            if (!cb.checked) {
              const s2 = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
              if (s2) { s2.call(cb, true); cb.dispatchEvent(new Event("change", { bubbles: true })); }
            }
          }
          recordAction({ type: "checkall", value: String(boxes.length), status: boxes.length > 0 ? "success" : "skipped" });
        } else if (act.startsWith("click ")) {
          const btnText = actionStr.slice(6).trim();
          const btn2 = await findButtonByTextWithWait(btnText);
          if (btn2 && !isBtnDisabled(btn2)) { universalClick(btn2); recordAction({ type: "click", value: btnText, status: "success" }); await sleep(250); }
          else recordAction({ type: "click", value: btnText, status: btn2 ? "failed" : "not found", reason: btn2 ? "disabled" : "not found" });
        }
        continue;
      }

      if (cmd.type === "select") {
        // if already selected → skip
        const alreadySel = [...document.querySelectorAll("input[type='radio']")]
          .find(r => r.offsetParent && r.checked &&
            normalize(r.value || r.closest("label")?.innerText || "").includes(normalize(cmd.value)));
        if (alreadySel) {
          console.log(`⏭️ select "${cmd.value}" — already selected, skipping`);
          recordAction({ type: "select", value: cmd.value, status: "skipped", reason: "already selected" });
          continue;
        }
        const target = (cmd.value || "").trim().toLowerCase();
        if (!target) continue;

        // 1️⃣ Native radio button
        const radio = [...document.querySelectorAll('input[type="radio"]')]
          .find(r =>
            normalize(r.value).includes(target) ||
            normalize(r.closest("label")?.innerText || "").includes(target) ||
            normalize(r.nextElementSibling?.innerText || "").includes(target) ||
            looseTextMatch(r.value, cmd.value) ||
            looseTextMatch(r.closest("label")?.innerText || "", cmd.value) ||
            looseTextMatch(r.nextElementSibling?.innerText || "", cmd.value)
          );
        if (radio) {
          radio.click();
          radio.dispatchEvent(new Event("change", { bubbles: true }));
          recordAction({ type: "select", value: cmd.value, status: "success" });
          await sleep(150);
          continue;
        }

        // 2️⃣ Native <select> option
        const nativeSelect = [...document.querySelectorAll("select")]
          .find(s => s.offsetParent && pickOption([...s.options], cmd.value));
        if (nativeSelect) {
          const opt = pickOption([...nativeSelect.options], cmd.value);
          if (opt) {
            nativeSelect.value = opt.value;
            nativeSelect.dispatchEvent(new Event("change", { bubbles: true }));
            recordAction({ type: "select", value: `${fieldLabelOf(nativeSelect)} → ${opt.text.trim().slice(0, 30)}`, status: "success" });
            await sleep(100);
            continue;
          }
        }

        // 3️⃣ Custom tab / card / styled element
        //    Score: own-text match >> full-text exact >> partial (penalise containers)
        const allEls = [...document.querySelectorAll(
          "button, [role='tab'], [role='option'], [role='radio'], " +
          "li, label, a, span, div"
        )].filter(e => e.offsetParent !== null);

        let best = null, bestScore = -1;

        for (const e of allEls) {
          const ownText = [...e.childNodes]
            .filter(n => n.nodeType === Node.TEXT_NODE)
            .map(n => n.textContent.trim()).join(" ").toLowerCase().trim();

          const fullText = normalize(e.innerText || "");
          let score = -1;

          if (ownText && (ownText.includes(target) || looseTextMatch(ownText, cmd.value))) {
            score = (ownText === target || looseNorm(ownText) === looseNorm(cmd.value)) ? 100 : 80;
          } else if (fullText === target || looseNorm(fullText) === looseNorm(cmd.value)) {
            score = 70;
          } else if (fullText.includes(target) || looseTextMatch(fullText, cmd.value)) {
            const kids = e.querySelectorAll("*").length;
            score = Math.max(1, 50 - kids * 2);
          }

          if (score > bestScore) { bestScore = score; best = e; }
        }

        if (best && bestScore >= 0) {
          universalClick(best);
          console.log("✅ select:", best.tagName, "|", (best.innerText || "").slice(0, 40).trim());
          recordAction({ type: "select", value: cmd.value, status: "success" });
          await sleep(150);
        } else {
          console.warn("❌ select: not found:", target);
          recordAction({ type: "select", value: cmd.value, status: "failed", reason: "not_found" });
        }
        continue;
      }
    }
  }

  hideRowProgress();
  console.log("✅ Workflow completed");
}




chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "GET_FIELD_LABELS") return;

  const labels = [];

  document.querySelectorAll("input, select, textarea").forEach(el => {
    if (
      el.type === "hidden" ||
      el.type === "submit" ||
      el.type === "button" ||
      el.type === "file"
    ) return;

    let text = "";

    if (el.labels && el.labels.length) {
      text = el.labels[0].innerText;
    } else if (el.placeholder) {
      text = el.placeholder;
    } else {
      text = el.name || el.id;
    }

    text = text?.trim();
    if (text && !labels.includes(text)) {
      labels.push(text.replace(/\s+/g, " "));
    }
  });

  sendResponse(labels);
  return true;
});

window.detectIconButtons = detectIconButtons;
window.clickIconButton = clickIconButton;


/* =========================================================
   PAGE SCANNER — detects all interactive elements and
   generates a ready-to-use command template
   ========================================================= */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "SCAN_PAGE") return;

  const result = {
    url: location.href,
    fields: [],
    buttons: [],
    hasCalendar: false,
    hasFileInputs: false,
    hasRadios: [],
    hasCheckboxes: [],
    hasNativeSelects: [],
    hasFakeDropdowns: [],
    hasSlotCards: [],
    generatedCommand: ""
  };

  // ── 1. FIELDS ──
  const fieldEls = [...document.querySelectorAll("input, textarea, select")]
    .filter(el =>
      el.type !== "hidden" &&
      el.type !== "submit" &&
      el.type !== "button" &&
      el.type !== "file" &&
      el.type !== "radio" &&
      el.type !== "checkbox" &&
      el.offsetParent !== null
    );

  fieldEls.forEach(el => {
    // Build label using all detection methods
    const candidates = [];

    // label attr, aria-label, placeholder, name, id
    ["label","aria-label","placeholder","name","id"].forEach(attr => {
      const v = el.getAttribute(attr);
      if (v && v.trim()) candidates.push(v.trim());
    });

    // associated label
    const realLabel = el.labels?.[0]?.innerText?.trim();
    if (realLabel) candidates.push(realLabel);

    // legend
    const legend = el.closest("fieldset")?.querySelector("legend")?.innerText?.trim();
    if (legend) candidates.push(legend);

    // sibling label (before or after)
    const parent = el.parentElement;
    for (let sib of [parent?.previousElementSibling, parent?.nextElementSibling]) {
      if (sib && !sib.querySelector("input,select,textarea")) {
        const t = (sib.innerText || "").trim();
        if (t.length > 1 && t.length < 80) candidates.push(t);
      }
    }

    // ancestor text
    let node = el.parentElement;
    for (let d = 0; d < 4 && node; d++) {
      const ownText = [...node.childNodes]
        .filter(n => n.nodeType === Node.TEXT_NODE)
        .map(n => n.textContent.trim()).filter(Boolean).join(" ");
      if (ownText.length > 1 && ownText.length < 80) { candidates.push(ownText); break; }
      node = node.parentElement;
    }

    const bestLabel = candidates[0] || el.name || el.id || "?";
    const cleanLabel = bestLabel.replace(/\s+/g, " ").replace(/[*]/g, "").trim();

    result.fields.push({
      label:     cleanLabel,
      type:      el.tagName === "SELECT" ? "select" : (el.readOnly ? "dropdown" : el.type || "text"),
      value:     el.value || "",
      name:      el.name || "",
      isDisabled: el.disabled,
      isReadOnly: el.readOnly
    });
  });

  // ── 2. BUTTONS ──
  const buttonEls = [...document.querySelectorAll(
    "button, [role='button'], input[type='submit'], input[type='button'], a[href]"
  )].filter(el => el.offsetParent !== null);

  const seenBtns = new Set();
  buttonEls.forEach(el => {
    const text = (el.innerText || el.value || el.getAttribute("aria-label") || "").trim();
    const clean = text.replace(/\s+/g, " ").slice(0, 60);
    if (clean && !seenBtns.has(clean.toLowerCase())) {
      seenBtns.add(clean.toLowerCase());
      result.buttons.push(clean);
    }
  });

  // Also find cursor:pointer divs (slot cards)
  const slotCards = [...document.querySelectorAll("div, span")]
    .filter(el => {
      if (!el.offsetParent) return false;
      const style = getComputedStyle(el);
      if (style.cursor !== "pointer") return false;
      const rect = el.getBoundingClientRect();
      if (rect.width < 40 || rect.height < 20) return false;
      const text = (el.innerText || "").trim();
      return text.length > 2 && text.length < 80 && !el.querySelector("button, a");
    });

  slotCards.forEach(el => {
    const text = (el.innerText || "").trim().replace(/\s+/g, " ").slice(0, 60);
    if (text && !seenBtns.has(text.toLowerCase())) {
      seenBtns.add(text.toLowerCase());
      result.hasSlotCards.push(text);
    }
  });

  // ── 3. CALENDAR ──
  result.hasCalendar = document.querySelectorAll("td").length > 7 &&
    [...document.querySelectorAll("td")].some(td => {
      const s = getComputedStyle(td);
      return s.cursor === "pointer" || td.onclick;
    });

  // ── 4. FILE INPUTS ──
  result.hasFileInputs = document.querySelectorAll("input[type='file']").length > 0;

  // ── 5. RADIOS ──
  [...document.querySelectorAll("input[type='radio']")]
    .filter(el => el.offsetParent)
    .forEach(el => {
      const label = el.labels?.[0]?.innerText?.trim() ||
                    el.nextElementSibling?.innerText?.trim() ||
                    el.value || "";
      if (label) result.hasRadios.push(label);
    });

  // ── 6. CHECKBOXES ──
  [...document.querySelectorAll("input[type='checkbox']")]
    .filter(el => el.offsetParent)
    .forEach(el => {
      const label = el.labels?.[0]?.innerText?.trim() ||
                    el.closest("label")?.innerText?.replace(el.value,"")?.trim() || "";
      if (label) result.hasCheckboxes.push(label.slice(0, 60));
    });

  // ── 7. NATIVE SELECTS ──
  [...document.querySelectorAll("select")]
    .filter(el => el.offsetParent)
    .forEach(el => {
      const label = el.labels?.[0]?.innerText?.trim() ||
                    el.getAttribute("aria-label") || el.name || "";
      const opts = [...el.options].map(o => o.text.trim()).filter(Boolean);
      result.hasNativeSelects.push({ label, options: opts.slice(0, 6) });
    });

  // ── 8. GENERATE COMMAND ──
  const lines = [];

  if (result.hasCalendar) {
    lines.push("date DD/MM/YYYY");
  }

  if (result.fields.length > 0) {
    lines.push("fill");
  }

  // Suggest select for radios
  result.hasRadios.slice(0, 3).forEach(r => {
    lines.push(`select ${r}  ← choose one option`);
  });

  // Suggest click for buttons
  result.buttons.slice(0, 4).forEach(btn => {
    if (btn.length > 1) lines.push(`click ${btn}`);
  });

  // Slot cards
  result.hasSlotCards.slice(0, 3).forEach(card => {
    lines.push(`click ${card}  ← slot card`);
  });

  lines.push("---");

  // Field data
  result.fields.forEach(f => {
    if (f.isDisabled) return; // skip disabled
    const label = f.label;
    if (f.type === "dropdown" || f.type === "select") {
      lines.push(`${label}, `);
    } else if (f.type === "file") {
      lines.push(`upload filename.jpg  ← for "${label}"`);
    } else {
      lines.push(`${label}, `);
    }
  });

  // Checkboxes
  result.hasCheckboxes.forEach(c => {
    lines.push(`${c.slice(0,40)}, yes`);
  });

  result.generatedCommand = lines.join("\n");

  sendResponse(result);
  return true;
});

}

