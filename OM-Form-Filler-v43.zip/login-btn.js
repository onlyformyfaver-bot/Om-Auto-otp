/* Popup "🔐 Login" button (new): pick a person → the TTD tab logs in (Log In → mobile → Get OTP → relay OTP → Login) */
document.addEventListener("DOMContentLoaded", () => {
  const $ = (id) => document.getElementById(id);
  const HOST = "ttdevasthanams.ap.gov.in";
  const panel = $("ttdLoginPanel"), list = $("ttdLoginList"), msg = $("ttdLoginMsg");
  if (!$("ttdLoginBtn") || !panel) return;
  const say = (t, c) => { msg.textContent = t; msg.style.color = c || "#f9e2af"; };

  async function ttdTab() {
    const tabs = await chrome.tabs.query({ url: ["https://" + HOST + "/*", "http://" + HOST + "/*"] });
    if (!tabs.length) return null;
    return tabs.find(t => t.active) || tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  }

  async function go(person) {
    const tab = await ttdTab();
    if (!tab) { say("Open the TTD website first (any page), then tap Login again."); return; }
    if (/curtain/i.test(tab.url)) { say("TTD tab is on the curtain / queue page — wait until it lets you through."); return; }
    try {
      await chrome.tabs.update(tab.id, { active: true });          // show the TTD page so you can watch it log in
      const res = await chrome.tabs.sendMessage(tab.id, { type: "OM_LOGIN_START", person });
      if (res?.already) say("Already logged in to TTD.", "#a6e3a1");
      else { say(`Logging in as ${person.name}… watch the TTD tab.`, "#a6e3a1"); setTimeout(() => window.close(), 300); }
    } catch (e) {
      say("The TTD page isn't ready for the extension — reload the TTD tab once, then tap Login again.\n(" + e.message + ")", "#f38ba8");
    }
  }

  $("ttdLoginBtn").addEventListener("click", async () => {
    const { omOtpRelay: cfg = {} } = await chrome.storage.local.get("omOtpRelay");
    const people = String(cfg.mobiles || "").split("\n").map(l => {
      const m = l.match(/^(.*?)[,\s]+(\+?91)?\s*(\d{10})\s*$/);
      return m ? { name: m[1].trim() || m[3].slice(-4), mobile: m[3] } : null;
    }).filter(Boolean);
    list.innerHTML = ""; say("");
    panel.style.display = "block";
    document.body.classList.add("db-open");
    if (!people.length) {
      say("No mobiles saved yet.\nDirect Book → 🔐 Login OTP relay → Login mobiles: one per line, e.g.\nLakshmi, 9876543210");
      return;
    }
    if (!cfg.enabled || !cfg.url || !cfg.key) say("Note: OTP relay is off, so the OTP won't be filled automatically — type it or tap the keyboard's \"from messages\" suggestion.");
    people.forEach(p => {
      const b = document.createElement("button");
      b.textContent = `${p.name}  ••${p.mobile.slice(-4)}`;
      b.style.cssText = "padding:12px;border:none;border-radius:8px;background:#a6e3a1;color:#1e1e2e;font-weight:700;font-size:15px;text-align:left;";
      b.addEventListener("click", () => go(p));
      list.appendChild(b);
    });
  });
  $("ttdLoginClose").addEventListener("click", () => { panel.style.display = "none"; document.body.classList.remove("db-open"); });
});
