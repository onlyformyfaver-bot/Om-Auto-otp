/* =========================================================
   TTD LOGIN OTP AUTO-FILL (new module)
   Verified login flow (api log, 04 Oct 2026):
     POST /api/sdn/rest/v1/initiate_login_after_checks          body: mobile_no=<10 digits>   → OTP valid 360 s
     POST /api/sdn/rest/v1/session/complete/using_mobileno_n_otp body: mobile_no, rk, otp, channel=web
   When the site has just asked TTD to send an OTP, this asks your OTP relay (via background.js)
   for the newest OTP for that mobile, types it into the OTP box and presses Verify.
   Mobile + time come from the api log that api-capture.js keeps in sessionStorage.
   ========================================================= */
(() => {
  if (window.__OM_OTP_AUTOFILL) return;
  window.__OM_OTP_AUTOFILL = true;
  const TAG = "[OM-OTP]";
  let busyFor = null;        // set while the relay loop runs (one loop at a time)
  const used = new Set();    // "<attempt ts>:<otp>" already filled — a NEW OTP is always filled again
  let pressedValue = "";     // box value we last pressed Login for

  function lastLoginRequest() {
    let log = [];
    try { log = JSON.parse(sessionStorage.getItem("__OM_API_LOG") || "[]"); } catch (e) {}
    let init = null, completedAfter = false;
    for (const x of log) {
      const u = x.url || "";
      // Get OTP, and any resend-OTP call, starts a new attempt (mobile kept from the last one if the call has none)
      if (x.status === 200 && (/\/initiate_login_after_checks/.test(u) || (/\/api\/sdn\//.test(u) && /otp|resend/i.test(u) && !/session\/complete/.test(u)))) {
        const m = /mobile_no=(\d{10})/.exec(x.body || "");
        const mobile = m ? m[1] : init?.mobile;
        if (mobile) { init = { mobile, ts: Date.parse(x.t) || Date.now() }; completedAfter = false; }
      }
      if (/\/session\/complete\/using_mobileno_n_otp/.test(x.url || "") && /"is_valid":true/.test(x.response || "")) completedAfter = true;
    }
    if (!init || completedAfter) return null;
    if (Date.now() - init.ts > 360000) return null;           // TTD OTP is valid for 6 minutes
    return init;
  }

  const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !el.disabled; };
  function otpBoxes(mobile) {
    const one = [...document.querySelectorAll('input[autocomplete="one-time-code"], input[name*="otp" i], input[id*="otp" i], input[placeholder*="otp" i], input[aria-label*="otp" i]')]
      .filter(visible).filter(el => !(el.maxLength === 1));
    if (one.length) return { single: one[0] };
    const singles = [...document.querySelectorAll('input[maxlength="1"]')].filter(visible);
    if (singles.length >= 4) return { multi: singles };
    // Fallback: a short numeric box that isn't the mobile field (TTD's OTP box may carry no "otp" label)
    const numeric = [...document.querySelectorAll("input")].filter(visible).filter(el => {
      if (/hidden|checkbox|radio|submit|button|email/i.test(el.type)) return false;
      if (mobile && el.value.replace(/\D/g, "").endsWith(mobile.slice(-4))) return false;
      const ml = el.maxLength;
      const short = ml >= 4 && ml <= 8;
      const num = /tel|number/i.test(el.type) || /numeric|decimal/i.test(el.inputMode || el.getAttribute("inputmode") || "");
      return short || (num && ml !== 10);
    });
    if (numeric.length) return { single: numeric[numeric.length - 1] };
    return null;
  }

  // Small on-page status chip, so it's visible on the phone without DevTools
  function chip(text, color) {
    let el = document.getElementById("om-otp-chip");
    if (!el) {
      el = document.createElement("div");
      el.id = "om-otp-chip";
      el.style.cssText = "position:fixed;left:50%;transform:translateX(-50%);top:calc(8px + env(safe-area-inset-top,0px));z-index:2147483647;padding:6px 12px;border-radius:999px;font:12px/1.3 sans-serif;color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.3);max-width:90vw;";
      document.documentElement.appendChild(el);
    }
    el.style.background = color || "#1e1e2e";
    el.textContent = "🔐 " + text;
    clearTimeout(el.__t);
    el.__t = setTimeout(() => el.remove(), 15000);
    console.log(TAG, text);
  }

  function setVal(el, v) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    el.focus();
    setter.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function fill(boxes, otp) {
    if (boxes.single) setVal(boxes.single, otp);
    else boxes.multi.slice(0, otp.length).forEach((el, i) => setVal(el, otp[i]));
  }

  function verifyButton(near) {
    const scope = near.closest("form") || document;
    return [...scope.querySelectorAll('button, input[type="submit"], [role="button"]')]
      .filter(visible)
      .find(b => /verify|login|log in|submit|proceed|continue/i.test(b.textContent || b.value || ""));
  }

  // Fill an OTP unless this exact OTP was already filled for this attempt; then press Login
  async function useOtp(req, otp, how) {
    const key = req.ts + ":" + otp;
    if (used.has(key)) return false;
    let b = otpBoxes(req.mobile);
    for (let i = 0; !b && i < 10; i++) { await sleep(500); b = otpBoxes(req.mobile); }
    if (!b) { chip(`OTP ${otp} received — OTP box not found, type it in`, "#b45309"); return false; }
    used.add(key);
    fill(b, otp);
    pressedValue = otp;
    document.getElementById("om-paste-otp")?.remove();
    if (await pressLogin(b)) chip(`OTP filled (${how}) and Login pressed`, "#15803d");
    else chip(`OTP filled (${how}) — press Login`, "#15803d");
    return true;
  }

  // Relay: keeps asking until login completes or the OTP window ends, so a resent OTP is filled too
  async function tick() {
    const req = lastLoginRequest();
    if (!req || busyFor) return;
    busyFor = true;
    const masked = req.mobile.replace(/\d(?=\d{4})/g, "•");
    chip(`Waiting for OTP for ${masked}…`);
    let lastErr = "", gotAny = false, cur = req;
    try {
      while ((cur = lastLoginRequest()) && cur.mobile === req.mobile) {
        let res;
        try { res = await chrome.runtime.sendMessage({ type: "OM_OTP_GET", mobile: cur.mobile, since: cur.ts - 5000 }); }
        catch (e) { chip("Extension was reloaded — refresh this TTD page", "#b91c1c"); return; }
        if (res?.disabled) { await sleep(3000); continue; }        // relay off: clipboard / keyboard paths still work
        if (res?.otp && /^\d{4,8}$/.test(res.otp)) { gotAny = (await useOtp(cur, res.otp, "relay")) || gotAny; }
        else if (res?.error && res.error !== lastErr) {
          lastErr = res.error;
          const hint = /401/.test(res.error) ? "wrong key" : /404/.test(res.error) ? "Worker has no /otp route — deploy the new Worker" : /fetch|network/i.test(res.error) ? "can't reach relay URL" : "";
          chip(`Relay error: ${res.error}${hint ? " — " + hint : ""}`, "#b91c1c");
        }
        await sleep(2000);
      }
    } finally { busyFor = null; }
  }

  // ── Login form: one-tap mobile fill from your saved list ("Name, 10-digit mobile" per line) ──
  function mobileBox() {
    return [...document.querySelectorAll("input")].filter(visible).find(el => {
      if (/hidden|checkbox|radio|submit|button|email|password/i.test(el.type)) return false;
      const hint = `${el.name} ${el.id} ${el.placeholder} ${el.getAttribute("aria-label") || ""}`;
      return /mobile|phone/i.test(hint) || el.maxLength === 10 || (el.type === "tel" && !(el.maxLength >= 1 && el.maxLength <= 8));
    }) || [...document.querySelectorAll("input")].filter(visible).find(el =>          // TTD: box sits under "Registered mobile number"
      !(el.maxLength >= 1 && el.maxLength <= 8) && /registered mobile/i.test(el.parentElement?.parentElement?.textContent || ""));
  }
  function sendOtpButton(near) {
    const scope = near.closest("form") || document;
    return [...scope.querySelectorAll('button, input[type="submit"], [role="button"]')]
      .filter(visible).find(b => /send otp|get otp|generate otp|request otp|login|continue|proceed|submit/i.test(b.textContent || b.value || ""));
  }
  let pickerFor = null;
  async function loginPicker() {
    if (lastLoginRequest() || busyFor) return;               // OTP step already running
    const box = mobileBox();
    const bar = document.getElementById("om-mobile-picker");
    if (!box || box.value.replace(/\D/g, "").length === 10) { if (bar) bar.remove(); pickerFor = null; return; }
    if (bar && pickerFor === box) return;
    let cfg = {};
    try { cfg = (await chrome.storage.local.get("omOtpRelay")).omOtpRelay || {}; } catch (e) { return; }
    const people = String(cfg.mobiles || "").split("\n").map(l => {
      const m = l.match(/^(.*?)[,\s]+(\+?91)?\s*(\d{10})\s*$/);
      return m ? { name: m[1].trim() || m[3].slice(-4), mobile: m[3] } : null;
    }).filter(Boolean);
    if (!people.length) return;
    if (bar) bar.remove();
    pickerFor = box;
    const wrap = document.createElement("div");
    wrap.id = "om-mobile-picker";
    wrap.style.cssText = "position:fixed;left:8px;right:8px;top:calc(44px + env(safe-area-inset-top,0px));z-index:2147483647;display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:8px;border-radius:12px;background:rgba(30,30,46,.95);font:13px sans-serif;";
    const lab = document.createElement("span"); lab.textContent = "🔐 Login as:"; lab.style.cssText = "color:#cdd6f4;align-self:center;"; wrap.appendChild(lab);
    people.forEach(p => {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = `${p.name} ••${p.mobile.slice(-4)}`;
      b.style.cssText = "padding:8px 12px;border:none;border-radius:999px;background:#a6e3a1;color:#1e1e2e;font-weight:700;";
      b.addEventListener("click", async () => {
        const target = mobileBox() || box;
        setVal(target, p.mobile);
        wrap.remove();
        chip(`Mobile filled for ${p.name}`, "#15803d");
        if (cfg.autoSend) {
          await new Promise(r => setTimeout(r, 400));
          const s = sendOtpButton(target);
          if (s && !s.disabled) { s.click(); chip(`Send OTP pressed for ${p.name} — waiting for OTP…`); }
          else chip(`Mobile filled for ${p.name} — tap Send OTP`, "#b45309");
        }
      });
      wrap.appendChild(b);
    });
    const x = document.createElement("button"); x.type = "button"; x.textContent = "✕";
    x.style.cssText = "padding:8px 10px;border:none;border-radius:999px;background:#45475a;color:#cdd6f4;";
    x.addEventListener("click", () => { wrap.remove(); });
    wrap.appendChild(x);
    document.documentElement.appendChild(wrap);
  }

  // ── Separate "🔐 Login with OTP" button: Log In → mobile → Get OTP → (relay) OTP → Login ──
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const loggedIn = () => /(?:^|;\s*)authtoken=[^;\s]+/.test(document.cookie);
  function peopleFrom(cfg) {
    return String(cfg.mobiles || "").split("\n").map(l => {
      const m = l.match(/^(.*?)[,\s]+(\+?91)?\s*(\d{10})\s*$/);
      return m ? { name: m[1].trim() || m[3].slice(-4), mobile: m[3] } : null;
    }).filter(Boolean);
  }
  function headerLogIn() {                       // the site's "Log In" link (top bar), not the dialog title
    return [...document.querySelectorAll('a, button, [role="button"], li, div, span')]
      .filter(visible)
      .filter(e => /^\s*log\s*in\s*$/i.test(e.textContent || "") && !e.closest("#om-login-btn, #om-mobile-picker, h1, h2, h3, h4, h5, h6"))
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)[0];
  }
  function getOtpButton(near) {
    const all = [...document.querySelectorAll('button, input[type="submit"], [role="button"]')].filter(visible);
    return all.find(b => /get otp|send otp|generate otp|request otp/i.test(b.textContent || b.value || "")) || sendOtpButton(near);
  }
  let loginRunning = false;
  async function startLogin(p) {
    if (loginRunning) return;
    loginRunning = true;
    document.getElementById("om-mobile-picker")?.remove();
    try {
      let box = mobileBox();
      if (!box) {
        const link = headerLogIn();
        if (!link) { chip("Log In button not found on this page", "#b91c1c"); return; }
        link.click();
        for (let i = 0; !box && i < 30; i++) { await sleep(200); box = mobileBox(); }
        if (!box) { chip("Mobile box didn't appear — tap Log In, then try again", "#b91c1c"); return; }
      }
      setVal(box, p.mobile);
      chip(`Mobile filled for ${p.name}`);
      let btn = null;
      for (let i = 0; i < 15; i++) { btn = getOtpButton(box); if (btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") break; await sleep(200); }
      if (!btn || btn.disabled) { chip(`Mobile filled for ${p.name} — tap Get OTP`, "#b45309"); return; }
      btn.click();
      chip(`Get OTP pressed for ${p.name} — waiting for OTP…`);   // tick() takes over once TTD confirms the OTP was sent
    } finally { loginRunning = false; }
  }
  async function loginButton() {
    const el = document.getElementById("om-login-btn");
    let cfg = {};
    try { cfg = (await chrome.storage.local.get("omOtpRelay")).omOtpRelay || {}; } catch (e) { return; }
    const people = peopleFrom(cfg);
    const show = people.length && !loggedIn() && !lastLoginRequest() && !busyFor;
    if (!show) { if (el) el.remove(); return; }
    if (el) return;
    const b = document.createElement("button");
    b.id = "om-login-btn"; b.type = "button";
    b.textContent = "🔐 Login with OTP";
    b.style.cssText = "position:fixed;right:12px;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:2147483646;padding:8px 14px;border:none;border-radius:999px;background:#6d28d9;color:#fff;font:700 13px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.3);";
    b.addEventListener("click", () => {
      if (people.length === 1) { startLogin(people[0]); return; }
      document.getElementById("om-mobile-picker")?.remove();
      const wrap = document.createElement("div");
      wrap.id = "om-mobile-picker";
      wrap.style.cssText = "position:fixed;left:8px;right:8px;top:calc(48px + env(safe-area-inset-top,0px));z-index:2147483647;display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:8px;border-radius:12px;background:rgba(30,30,46,.95);font:13px sans-serif;";
      const lab = document.createElement("span"); lab.textContent = "🔐 Login as:"; lab.style.cssText = "color:#cdd6f4;align-self:center;"; wrap.appendChild(lab);
      people.forEach(p => {
        const pb = document.createElement("button"); pb.type = "button";
        pb.textContent = `${p.name} ••${p.mobile.slice(-4)}`;
        pb.style.cssText = "padding:8px 12px;border:none;border-radius:999px;background:#a6e3a1;color:#1e1e2e;font-weight:700;";
        pb.addEventListener("click", () => startLogin(p));
        wrap.appendChild(pb);
      });
      const x = document.createElement("button"); x.type = "button"; x.textContent = "✕";
      x.style.cssText = "padding:8px 10px;border:none;border-radius:999px;background:#45475a;color:#cdd6f4;";
      x.addEventListener("click", () => wrap.remove());
      wrap.appendChild(x);
      document.documentElement.appendChild(wrap);
    });
    document.documentElement.appendChild(b);
  }

  // Popup "🔐 Login" button asks this page to start the login
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type !== "OM_LOGIN_START") return;
    if (loggedIn()) { chip("Already logged in to TTD", "#15803d"); sendResponse({ ok: true, already: true }); return; }
    startLogin(msg.person);
    sendResponse({ ok: true });
  });

  // ── OTP from this phone's SMS (not via relay): "📋 Paste OTP" button + auto-Login once all boxes are filled ──
  function otpFilledValue(b) {
    if (!b) return "";
    return b.single ? b.single.value.replace(/\D/g, "") : b.multi.map(el => el.value).join("").replace(/\D/g, "");
  }
  async function pressLogin(b) {
    await sleep(300);
    const btn = verifyButton(b.single || b.multi[0]);
    if (btn && !btn.disabled) { btn.click(); return true; }
    return false;
  }
  const otpIn = (text) => (/(?:^|\D)(\d{6})(?!\d)/.exec(text || "") || /(?:^|\D)(\d{4,8})(?!\d)/.exec(text || ""))?.[1];

  function pasteButton(req) {
    if (document.getElementById("om-paste-otp")) return;
    const b = document.createElement("button");
    b.id = "om-paste-otp"; b.type = "button";
    b.textContent = "📋 Paste OTP";
    b.style.cssText = "position:fixed;right:12px;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:2147483647;padding:10px 16px;border:none;border-radius:999px;background:#15803d;color:#fff;font:700 14px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.3);";
    b.addEventListener("click", async () => {
      let text = "";
      try { text = await navigator.clipboard.readText(); } catch (e) {}
      const otp = otpIn(text);
      if (!otp) { chip("No OTP in the clipboard — tap the keyboard's \"from messages\" suggestion instead", "#b45309"); return; }
      clip.last = text;
      const cur = lastLoginRequest() || req;
      used.delete(cur.ts + ":" + otp);                   // a tap always fills, even the same code again
      await useOtp(cur, otp, "clipboard");
    });
    document.documentElement.appendChild(b);
  }

  // Auto-paste: OM SMS OTP copies the OTP to the clipboard. Once Kiwi may read it (first tap on 📋 → Allow),
  // every NEW OTP copied after Get OTP / Resend is filled by itself.
  const clip = { ts: null, last: null, busy: false };
  async function clipboardWatch(req) {
    if (clip.busy || !document.hasFocus()) return;
    clip.busy = true;
    try {
      let text;
      try { text = await navigator.clipboard.readText(); } catch (e) { return; }    // not allowed yet → 📋 button
      if (clip.ts !== req.ts) {                       // new attempt: ignore what was copied before it…
        const first = clip.ts === null;
        clip.ts = req.ts;
        if (first || text === clip.last) { clip.last = text; return; }
      }                                               // …but if a new code is already there (fast SMS), use it
      if (text === clip.last) return;
      clip.last = text;
      const otp = otpIn(text);
      if (otp) await useOtp(req, otp, "clipboard");
    } finally { clip.busy = false; }
  }

  function manualOtpWatch() {
    const req = lastLoginRequest();
    if (!req) { document.getElementById("om-paste-otp")?.remove(); return; }
    const boxes = otpBoxes(req.mobile);
    if (!boxes) return;
    const v = otpFilledValue(boxes);
    const need = boxes.single ? (boxes.single.maxLength > 0 && boxes.single.maxLength <= 8 ? boxes.single.maxLength : 6) : boxes.multi.length;
    if (v.length < need) { pasteButton(req); pressedValue = pressedValue === v ? pressedValue : ""; }
    else document.getElementById("om-paste-otp")?.remove();
    clipboardWatch(req);
    // Typed, or filled by the keyboard's "from messages" suggestion → press Login (once per value)
    if (v.length >= need && v !== pressedValue) {
      pressedValue = v;
      pressLogin(boxes).then(ok => ok && chip("Login pressed", "#15803d"));
    }
  }

  setInterval(() => {
    loginButton().catch(() => {});
    try { manualOtpWatch(); } catch (e) {}
    tick().catch(e => console.log(TAG, e.message));
    loginPicker().catch(e => console.log(TAG, "picker", e.message));
  }, 1000);
})();
