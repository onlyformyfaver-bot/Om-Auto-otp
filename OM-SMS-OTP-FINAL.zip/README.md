# OM SMS OTP — Full package

Three parts. Use the app for your own and helpers' phones; use the share page
for one-time helpers who cannot install anything.

## 1. app-project  (the Android app)
Full-featured OTP app.
Features:
- Catches OTPs from SMS and from app notifications (WhatsApp, email, bank, UPI).
- Smart on-device detection: scores each number, rejects amounts / account nos /
  years / phone nos; understands Hindi, Telugu, Tamil, Kannada, Malayalam,
  Bengali, Gujarati, Punjabi, Odia keywords and Indian-script digits.
- Auto-copy, notification with Copy / Fill / Bubble buttons.
- Floating draggable overlay bubble on top of any app (tap = copy, Fill = auto-fill).
- Auto-fill OTP boxes, including split one-digit boxes.
- Encrypted history with sender + source app + time, search, auto-delete.
- Per-sender control: Full action / Save only / Stop-Ignore.
- Forward OTP: on the phone that receives the OTP, forwards only matching
  (e.g. TTD) OTPs by SMS to your number — zero taps, good for elderly helpers.
- Google scan safe mode: hides bubble + pauses auto-fill in Google Lens,
  Circle to Search, Camera, Photos. No internet permission.

Build (from phone):
1. New PRIVATE GitHub repo. Upload the contents of `app-project` (keep the
   `.github` folder and the structure). Or upload the zip and let Actions unzip.
2. Actions tab -> run the build -> download the APK artifact.
3. Install: pause Play Protect (Play Store -> profile -> Play Protect -> gear ->
   turn off scanning), install, turn scanning back on.
4. Open app -> Settings -> grant every permission. If a toggle is greyed out:
   App info -> three dots -> Allow restricted settings.
5. Tap "Send test OTP" to verify.

Forward OTP setup (on the OTHER phone that gets the TTD OTP):
- Settings: grant SMS + notifications, turn on Notification access.
- Forward OTP section: turn on, enter YOUR number, keep "Only when it contains"
  as `TTD, Tirumala` (add the exact TTD sender name if a real OTP is missed).
- Tap "Send test forward" to verify.

## 2 + 3. share-page  (no-install helper link)
For helpers who will not install the app. Telegram-only, nothing secret in the page.

- `om-otp-relay-worker.js` — Cloudflare Worker that holds your Telegram bot token.
  Create a Worker at dash.cloudflare.com (Compute -> Workers & Pages ->
  Start with Hello World), paste this code, fill TELEGRAM_TOKEN + TELEGRAM_CHATID,
  Deploy. Open the worker URL in a browser: it should say "OM OTP relay is running".
- `otp-share.html` — the helper page. RELAY_URL is already set to your worker.
  Host on GitHub Pages (repo Settings -> Pages -> main / root).
  Share the github.io link. Add `?name=Lakshmi` to greet a helper and tag the OTP.

IMPORTANT: a web page can never read someone's SMS. The helper taps the
keyboard "Copy code" chip, then the button. The app's Forward OTP is the only
zero-tap route.

SECURITY: keep the bot token only inside the Worker. If it is ever shown
anywhere else, revoke it in @BotFather (/revoke) and paste the new one.
