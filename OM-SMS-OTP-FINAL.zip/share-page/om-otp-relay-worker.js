/* =====================================================================
   OM OTP relay — Cloudflare Worker
   This code lives on YOUR Cloudflare account, never in the public page.
   Fill the 2 lines below, then Deploy.
   ===================================================================== */
const TELEGRAM_TOKEN  = "PUT_YOUR_BOT_TOKEN_HERE";   // from @BotFather
const TELEGRAM_CHATID = "PUT_YOUR_CHAT_ID_HERE";     // from @userinfobot

// Optional: lock the relay to your page only. Leave "*" to allow any page.
// Example: "https://yourname.github.io"
const ALLOW_ORIGIN = "*";

export default {
  async fetch(request) {
    const cors = {
      "Access-Control-Allow-Origin": ALLOW_ORIGIN,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST")
      return new Response("OM OTP relay is running", { headers: cors });

    let body;
    try { body = await request.json(); }
    catch (e) { return json({ ok: false, error: "bad_request" }, cors); }

    const otp  = String(body.otp  || "").replace(/\D/g, "").slice(0, 8);
    const name = String(body.name || "Helper").replace(/[\r\n]/g, " ").slice(0, 40);
    if (otp.length < 4) return json({ ok: false, error: "no_otp" }, cors);

    const text = "TTD OTP: " + otp + "\nFrom: " + name;
    try {
      const tg = await fetch(
        "https://api.telegram.org/bot" + TELEGRAM_TOKEN + "/sendMessage",
        { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: TELEGRAM_CHATID, text }) }
      );
      const data = await tg.json();
      return json({ ok: !!data.ok }, cors);
    } catch (e) {
      return json({ ok: false, error: "telegram_failed" }, cors);
    }
  }
};

function json(obj, cors) {
  return new Response(JSON.stringify(obj), {
    headers: { ...cors, "Content-Type": "application/json" }
  });
}
