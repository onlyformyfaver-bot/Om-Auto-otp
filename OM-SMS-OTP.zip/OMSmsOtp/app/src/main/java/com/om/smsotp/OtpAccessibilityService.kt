package com.om.smsotp

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class OtpAccessibilityService : AccessibilityService() {

    private val OTP_WORDS = listOf(
        "otp", "one time", "one-time", "verification", "verify", "passcode", "security code",
        "enter code", "sms code", "2fa", "ओटीपी", "सत्यापन", "कोड"
    )
    private val NOT_OTP = listOf(
        "pincode", "pin code", "postal", "zip", "coupon", "promo", "referral", "captcha",
        "mobile", "phone", "aadhaar", "aadhar", "amount", "cvv", "card number", "search"
    )

    override fun onServiceConnected() { AppState.a11y = this }
    override fun onDestroy() { if (AppState.a11y === this) AppState.a11y = null; super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            pkg != packageName && pkg != "com.android.systemui" && !isKeyboard(pkg)
        ) {
            AppState.foregroundPkg = pkg
            OverlayManager.onForeground(this, pkg)
        }
        val prefs = Prefs(this)
        if (!prefs.autoFill || pkg == packageName) return
        if (prefs.googleSafe && AppState.isGoogleScan(pkg)) return   // never touch Google Lens / Circle to Search
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
            e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) tryFill(auto = true)
    }

    private fun isKeyboard(pkg: String): Boolean {
        val ime = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return ime.startsWith("$pkg/")
    }

    /**
     * auto = true: only fills a field that looks like an OTP box, once per OTP.
     * auto = false (Fill button): fills the focused box with the given code.
     */
    fun tryFill(auto: Boolean = true, forced: String? = null): Boolean {
        val prefs = Prefs(this)
        val code = forced ?: AppState.freshCode(prefs.fillWindowMin) ?: return false
        if (prefs.googleSafe && AppState.isGoogleScan(AppState.foregroundPkg)) return false
        val root = rootInActiveWindow ?: return false

        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
        if (target == null) target = findOtpField(root, 0)
        if (target == null) return false
        if (auto) {
            if (!looksLikeOtp(target)) return false
            val existing = target.text?.toString().orEmpty().filter { it.isDigit() }
            if (existing.isNotEmpty()) return false
        }
        val ok = fill(target, code)
        if (ok && auto) AppState.pendingCode = null
        return ok
    }

    private fun describe(n: AccessibilityNodeInfo): String = listOfNotNull(
        n.hintText, n.viewIdResourceName, n.contentDescription, n.text
    ).joinToString(" ").lowercase()

    private fun nearbyText(n: AccessibilityNodeInfo?, depth: Int, budget: IntArray = intArrayOf(40)): String {
        if (n == null || depth < 0 || budget[0]-- <= 0) return ""
        val sb = StringBuilder(describe(n))
        for (i in 0 until n.childCount) sb.append(' ').append(nearbyText(n.getChild(i), depth - 1, budget))
        return sb.toString()
    }

    private fun looksLikeOtp(n: AccessibilityNodeInfo): Boolean {
        val own = describe(n)
        if (NOT_OTP.any { own.contains(it) }) return false
        if (OTP_WORDS.any { own.contains(it) } || own.contains("code")) return true
        val numeric = (n.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER
        val shortBox = n.maxTextLength == 1 || n.maxTextLength in 4..8
        if (!numeric && !shortBox) return false
        val around = nearbyText(n.parent?.parent ?: n.parent, 3)
        return OTP_WORDS.any { around.contains(it) } && NOT_OTP.none { around.contains(it) }
    }

    private fun findOtpField(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        if (n.isEditable && looksLikeOtp(n)) return n
        for (i in 0 until n.childCount) findOtpField(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    private fun collectEditable(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth < 0) return
        if (n.isEditable) out += n
        for (i in 0 until n.childCount) collectEditable(n.getChild(i), out, depth - 1)
    }

    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun fill(target: AccessibilityNodeInfo, code: String): Boolean {
        // Split boxes: one digit per box (common in banking / UPI apps and websites)
        val boxes = ArrayList<AccessibilityNodeInfo>()
        collectEditable(target.parent?.parent ?: target.parent, boxes, 3)
        val singles = boxes.filter { it.maxTextLength == 1 }
        val split = when {
            target.maxTextLength == 1 && singles.size >= 4 -> singles
            boxes.size == code.length && boxes.size >= 4 && target.maxTextLength !in 4..8 -> boxes
            else -> null
        }
        if (split != null) {
            code.forEachIndexed { i, ch -> if (i < split.size) setText(split[i], ch.toString()) }
            return true
        }
        if (setText(target, code)) return true
        // Fallback: clipboard paste
        OtpProcessor.copy(this, code)
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }
}
