package com.om.smsotp

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** What to do for each SMS sender / app. */
object Mode {
    const val FULL = 0       // save + copy + bubble + notification + auto-fill
    const val SAVE_ONLY = 1  // only keep in history, no action
    const val IGNORE = 2     // do nothing at all
    val options = listOf("Full action" to FULL, "Save only" to SAVE_ONLY, "Stop / Ignore" to IGNORE)
}

class Prefs(ctx: Context) {
    private val p: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("om_otp", Context.MODE_PRIVATE)

    private fun boolPref(def: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = p.getBoolean(property.name, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            p.edit().putBoolean(property.name, value).apply()
        }
    }

    private fun intPref(def: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = p.getInt(property.name, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            p.edit().putInt(property.name, value).apply()
        }
    }

    private fun strPref(def: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = p.getString(property.name, def) ?: def
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            p.edit().putString(property.name, value).apply()
        }
    }

    var shareBaseUrl by strPref("https://onlyformyfaver-bot.github.io/Om-Auto-otp/otp-share.html")
    var forwardOn by boolPref(false)
    var forwardTo by strPref("")
    var forwardMatch by strPref("TTD, Tirumala")
    var autoCopy by boolPref(true)
    var overlay by boolPref(true)
    var autoFill by boolPref(true)
    var notify by boolPref(true)
    var googleSafe by boolPref(true)
    var overlaySeconds by intPref(60)   // 0 = stay until closed
    var retentionDays by intPref(30)    // 0 = keep forever
    var fillWindowMin by intPref(5)
    var defaultMode by intPref(Mode.FULL)
    var overlayX by intPref(24)
    var overlayY by intPref(140)

    fun getMode(key: String) = p.getInt("mode:$key", defaultMode)
    fun setMode(key: String, m: Int) = p.edit().putInt("mode:$key", m).apply()

    fun addKnown(key: String, name: String) {
        val s = HashSet(p.getStringSet("known", emptySet()) ?: emptySet())
        s.removeAll { it.substringBefore('\u0001') == key }
        s += "$key\u0001$name"
        p.edit().putStringSet("known", s).apply()
    }

    fun known(): List<Pair<String, String>> =
        (p.getStringSet("known", emptySet()) ?: emptySet())
            .map { it.substringBefore('\u0001') to it.substringAfter('\u0001') }
            .sortedBy { it.second.lowercase() }
}
