package com.om.smsotp

import kotlin.math.abs

/** On-device OTP detection: scores every number instead of grabbing the first one. */
object OtpExtractor {
    private val KEYWORDS = listOf(
        "otp", "one time password", "one-time password", "verification code", "verification", "verify",
        "code", "passcode", "pass code", "pin", "2fa", "security code", "login", "auth", "token", "password",
        // Hindi + other Indian languages
        "ओटीपी", "कोड", "सत्यापन", "पासवर्ड", "वन टाइम",
        "ఓటీపీ", "కోడ్", "ஓடிபி", "குறியீடு", "ಒಟಿಪಿ", "ಕೋಡ್", "ഒടിപി", "കോഡ്",
        "ওটিপি", "কোড", "ઓટીપી", "કોડ", "ਓਟੀਪੀ", "ਕੋਡ", "ଓଟିପି", "ओटीपी क्रमांक"
    )
    private val NEG_BEFORE = listOf(
        "rs", "inr", "₹", "amt", "amount", "a/c", "ac ", "acct", "account", "bal", "balance",
        "card", "ref", "txn", "order", "call", "ph", "mob", "tel", "id ", "upi"
    )
    private val CAND = Regex("(?<![\\d₹.,])(?<!\\d-)(\\d{3}[ -]\\d{3}|\\d{4,8})(?![\\d.,]|-\\d)")
    private val ONLY_CODE = Regex("^\\d{4,8}$")
    private val TIME_AFTER = Regex("^\\s*(/|:\\d|hrs|hours|am\\b|pm\\b|mins?\\b)")

    /** Converts Devanagari, Bengali, Tamil… digits to 0-9. */
    fun normalizeDigits(s: String): String = buildString(s.length) {
        for (ch in s) {
            if (Character.isDigit(ch) && ch !in '0'..'9') append(Character.getNumericValue(ch)) else append(ch)
        }
    }

    fun extract(raw: String, requireKeyword: Boolean = true): String? {
        val text = normalizeDigits(raw)
        val lower = text.lowercase()
        val kwPos = ArrayList<Int>()
        for (k in KEYWORDS) {
            var i = lower.indexOf(k)
            while (i >= 0) { kwPos += i; i = lower.indexOf(k, i + 1) }
        }
        if (requireKeyword && kwPos.isEmpty()) return null
        val trimmed = text.trim()
        if (!requireKeyword && ONLY_CODE.matches(trimmed)) return trimmed

        var best: String? = null
        var bestScore = Int.MIN_VALUE
        for (m in CAND.findAll(text)) {
            val code = m.value.replace(" ", "").replace("-", "")
            var score = 0
            val d = kwPos.minOfOrNull { abs(it - m.range.first) } ?: 999
            score += when { d <= 30 -> 6; d <= 60 -> 4; d <= 120 -> 2; else -> 0 }
            score += when (code.length) { 6 -> 3; 4 -> 2; else -> 1 }
            if (code.length == 4 && code.toInt() in 1900..2099) score -= 3
            val before = lower.substring(maxOf(0, m.range.first - 12), m.range.first)
            if (NEG_BEFORE.any { before.contains(it) }) score -= 7
            if (before.endsWith("x") || before.endsWith("*")) score -= 7          // masked a/c XX1234
            val after = lower.substring(m.range.last + 1, minOf(lower.length, m.range.last + 25))
            if (after.trimStart().startsWith("is your") || after.trimStart().startsWith("is the")) score += 3
            if (TIME_AFTER.containsMatchIn(after)) score -= 4
            if (score > bestScore) { bestScore = score; best = code }
        }
        return if (bestScore >= (if (requireKeyword) 3 else 1)) best else null
    }
}
